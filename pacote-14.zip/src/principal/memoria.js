// @ts-check
// A memória do Tick: quanto cada conta e o resto ocupam, a anotação no registro e a guarda que recarrega, uma por
// vez, a conta cuja página passou do limite. A página do jogo cresce ao longo do dia; recarregar devolve a
// memória, e o script de Auto Compra volta para a mesma hunt sozinho.
const { app } = require('electron');
const logica = require('../logica');
const { ctx, usar } = require('./contexto');

const { anotar, registrarErro, recarregarConta } = usar('anotar', 'registrarErro', 'recarregarConta');

const CONFERIR_MS = 5 * 60_000;
let ultimaGeral = 0;

/** MB de um processo: a memória só dele (privada) no Windows; fora dele, o conjunto de trabalho. */
const mbDe = (m) => Math.round((m.memory.privateBytes ?? m.memory.workingSetSize) / 1024);

/** Quanto cada conta ocupa, o processo de vídeo e o resto do Tick, em MB. */
function memoriaDetalhada() {
  const metricas = app.getAppMetrics();
  /** @type {Record<number, number | null>} */
  const contas = {};
  const pidsContas = new Set();
  for (const c of ctx.contas) {
    const pid = c.view.webContents.getOSProcessId();
    const m = metricas.find((x) => x.pid === pid);
    contas[c.n] = m ? mbDe(m) : null;
    if (m) pidsContas.add(pid);
  }
  const video = metricas.filter((m) => m.type === 'GPU').reduce((t, m) => t + mbDe(m), 0);
  const total = metricas.reduce((t, m) => t + mbDe(m), 0);
  const somaContas = Object.values(contas).reduce((t, v) => (t ?? 0) + (v ?? 0), 0) ?? 0;
  return { contas, video, tick: total - somaContas - video, total };
}

/** A linha do registro a cada 30 minutos: o total e quanto é de cada conta. */
function resumoDaMemoria() {
  const m = memoriaDetalhada();
  const porConta = Object.entries(m.contas).map(([n, mb]) => `${n}=${mb ?? '?'}`).join(' ');
  return `${ctx.contas.length} contas abertas, ${m.total} MB de memória (contas ${porConta || 'nenhuma'}; vídeo ${m.video}; resto do Tick ${m.tick})`;
}

/** A pessoa está mexendo nesta conta agora: a janela tem o foco e a conta está na tela ou com o foco. */
function emUso(conta) {
  const janela = ctx.janela;
  if (!janela || janela.isDestroyed() || !janela.isFocused() || !janela.isVisible()) return false;
  return ctx.focada === conta || conta.view.webContents.isFocused();
}

/** A triagem do Depot não pode ser interrompida pela recarga. */
async function ocupada(conta) {
  try {
    return !!(await conta.view.webContents.executeJavaScript('!!(window.__tickDepot && window.__tickDepot.situacao().rodando)'));
  } catch {
    return false;
  }
}

async function conferirMemoria() {
  const regra = ctx.layout.memoria;
  if (!regra?.guarda) return;
  const { contas: mb } = memoriaDetalhada();
  const agora = Date.now();
  const n = logica.contaParaAliviar(ctx.contas.map((c) => ({
    n: c.n, mb: mb[c.n], conectada: c.status.ws === 'conectada', emUso: emUso(c), ultimaRecarga: c.ultimaRecargaMemoria,
  })), regra, agora, ultimaGeral);
  const conta = ctx.contas.find((c) => c.n === n);
  if (!conta || await ocupada(conta)) return;
  ultimaGeral = agora;
  conta.ultimaRecargaMemoria = agora;
  anotar(`memória: conta ${conta.n} recarregada para devolver memória (${mb[conta.n]} MB, limite ${regra.limiteMB} MB)`);
  recarregarConta(conta);
}

function iniciarGuardaDeMemoria() {
  setInterval(() => { conferirMemoria().catch((e) => registrarErro('guarda de memória', e)); }, CONFERIR_MS);
}

module.exports = { memoriaDetalhada, resumoDaMemoria, iniciarGuardaDeMemoria, conferirMemoria };
