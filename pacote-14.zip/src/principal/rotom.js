// @ts-check
// A janela do Rotom Sniper: no topo, o seletor de conta (uma tela do Tick); embaixo, o cockpit da extensão na
// sessão da conta escolhida. Cada conta tem o seu cockpit, criado na primeira vez e guardado ao trocar, para não
// perder o que estava aberto nele. Uma janela só para todas as contas.
const { BaseWindow, WebContentsView, ipcMain } = require('electron');
const path = require('node:path');
const { ctx, usar } = require('./contexto');
const { ICONE, ID_ROTOM, PASTA_SRC } = require('./constantes');

const { abrirNoNavegador, registrarErro, anotar, nomeDe, ordenadas } = usar('abrirNoNavegador', 'registrarErro', 'anotar', 'nomeDe', 'ordenadas');

const ALTURA_TOPO = 48;

/** @type {import('electron').BaseWindow | null} */
let janela = null;
/** @type {import('electron').WebContentsView | null} */
let topo = null;
/** @type {Map<number, import('electron').WebContentsView>} conta → cockpit dela */
const cockpits = new Map();
let mostrada = null; // o número da conta cujo cockpit está na tela

const temRotom = (c) => !!c?.extIds?.[ID_ROTOM];
const aberta = () => !!janela && !janela.isDestroyed();

function dispor() {
  if (!aberta() || !janela || !topo) return;
  const { width, height } = janela.getContentBounds();
  topo.setBounds({ x: 0, y: 0, width, height: ALTURA_TOPO });
  for (const [n, v] of cockpits) {
    v.setVisible(n === mostrada);
    v.setBounds({ x: 0, y: ALTURA_TOPO, width, height: Math.max(0, height - ALTURA_TOPO) });
  }
}

/** As contas ligadas, na ordem da barra lateral, com o que o seletor precisa saber de cada uma. */
const listaDeContas = () => ordenadas().map((c) => ({
  n: c.n, nome: nomeDe(c), tem: temRotom(c), conectada: c.status.ws === 'conectada',
}));

function avisarTopo() {
  if (topo && !topo.webContents.isDestroyed()) topo.webContents.send('tick:rotom', { contas: listaDeContas(), mostrada });
}

/** Põe na tela o cockpit da conta `n`, criando-o na primeira vez. */
function escolher(n) {
  const conta = ctx.contas.find((c) => c.n === Number(n));
  if (!aberta() || !janela) return;
  if (!conta || !temRotom(conta)) {
    mostrada = null;
    dispor();
    return avisarTopo();
  }
  if (!cockpits.has(conta.n)) {
    const v = new WebContentsView({ webPreferences: { session: conta.ses, backgroundThrottling: false } });
    v.webContents.setWindowOpenHandler(({ url }) => {
      abrirNoNavegador(url);
      return { action: 'deny' };
    });
    v.webContents.loadURL(`chrome-extension://${conta.extIds[ID_ROTOM]}/cockpit.html`).catch((e) => registrarErro('cockpit do Rotom Sniper', e));
    janela.contentView.addChildView(v);
    cockpits.set(conta.n, v);
  }
  mostrada = conta.n;
  janela.setTitle(`Rotom Sniper — ${nomeDe(conta)}`);
  dispor();
  cockpits.get(conta.n)?.webContents.focus();
  avisarTopo();
}

/** Abre (ou traz para a frente) a janela, já na conta pedida; sem pedido, na que está na tela ou na primeira com a extensão. */
function abrirRotom(conta = null) {
  const alvo = (temRotom(conta) && conta) || (temRotom(ctx.focada) && ctx.focada) || ordenadas().find(temRotom) || null;
  if (aberta() && janela) {
    janela.show();
    janela.focus();
    if (alvo) escolher(alvo.n);
    return;
  }
  janela = new BaseWindow({ width: 1180, height: 820, minWidth: 640, minHeight: 420, title: 'Rotom Sniper', icon: ICONE, backgroundColor: '#171a2b' });
  topo = new WebContentsView({ webPreferences: { preload: path.join(PASTA_SRC, 'preload-ui.js') } });
  topo.webContents.loadFile(path.join(PASTA_SRC, 'rotom.html')).catch((e) => registrarErro('janela do Rotom Sniper', e));
  janela.contentView.addChildView(topo);
  janela.on('resize', dispor);
  janela.on('closed', () => {
    for (const v of cockpits.values()) { if (!v.webContents.isDestroyed()) v.webContents.close(); }
    cockpits.clear();
    if (topo && !topo.webContents.isDestroyed()) topo.webContents.close();
    janela = null;
    topo = null;
    mostrada = null;
  });
  // O topo pede a lista quando termina de carregar; aí já vai a conta escolhida.
  mostrada = alvo?.n ?? null;
  dispor();
  if (alvo) escolher(alvo.n);
  anotar(`Rotom Sniper: janela aberta${alvo ? ` na conta ${alvo.n}` : ''}`);
}

/** A conta saiu (desligada, ou a extensão foi tirada dela): o cockpit dela sai junto. */
function fecharCockpitDaConta(conta) {
  const v = cockpits.get(conta.n);
  if (v) {
    janela?.contentView.removeChildView(v);
    if (!v.webContents.isDestroyed()) v.webContents.close();
    cockpits.delete(conta.n);
  }
  if (mostrada === conta.n) {
    mostrada = null;
    janela?.setTitle('Rotom Sniper');
  }
  dispor();
  avisarTopo();
}

ipcMain.handle('tick:rotom-estado', () => ({ contas: listaDeContas(), mostrada }));
ipcMain.handle('tick:rotom-escolher', (_ev, n) => { escolher(n); return { contas: listaDeContas(), mostrada }; });

/** Para o diagnóstico: o que a janela mostra agora. */
const estadoRotom = () => ({ aberta: aberta(), mostrada, cockpits: [...cockpits.keys()], url: mostrada != null ? cockpits.get(mostrada)?.webContents.getURL() ?? null : null });

module.exports = { abrirRotom, fecharCockpitDaConta, avisarTopoRotom: avisarTopo, escolherContaRotom: escolher, estadoRotom };
