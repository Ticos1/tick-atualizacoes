// O topo da janela do Rotom Sniper: escolher de qual conta é o cockpit mostrado embaixo.
const conta = document.getElementById('conta');
const aviso = document.getElementById('aviso');

function pintar({ contas, mostrada }) {
  conta.replaceChildren(...contas.map((c) => {
    const o = document.createElement('option');
    o.value = String(c.n);
    o.textContent = c.tem ? c.nome : `${c.nome} (sem Rotom Sniper)`;
    o.disabled = !c.tem;
    o.selected = c.n === mostrada;
    return o;
  }));
  conta.disabled = !contas.some((c) => c.tem);
  const atual = contas.find((c) => c.n === mostrada);
  if (!contas.length) aviso.textContent = 'Nenhuma conta ligada agora.';
  else if (!contas.some((c) => c.tem)) aviso.textContent = 'Nenhuma conta ligada tem o Rotom Sniper. Ative em Configurações → Extensões por conta.';
  else if (!atual) aviso.textContent = 'Escolha uma conta.';
  else aviso.textContent = atual.conectada ? '' : 'Esta conta não está conectada ao jogo agora.';
}

conta.addEventListener('change', async () => pintar(await window.tick.rotomEscolher(Number(conta.value))));
window.tick.aoRotom(pintar);
window.tick.rotomEstado().then(pintar);
