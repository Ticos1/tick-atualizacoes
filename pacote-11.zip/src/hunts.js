const $ = (id) => document.getElementById(id);
const fmt = (v) => (Number.isFinite(v) ? Math.round(v).toLocaleString('pt-BR') : '—');
const RARIDADE = { comum: 'Comum', incomum: 'Incomum', rara: 'Rara', mitica: 'Mítica', lendaria: 'Lendária' };

function cartao(rotulo, valor, destaque = false) {
  const el = document.createElement('div');
  el.className = `cartao${destaque ? ' destaque' : ''}`;
  const s = document.createElement('small');
  s.textContent = rotulo;
  const b = document.createElement('b');
  b.textContent = valor;
  el.append(s, b);
  return el;
}

function celula(texto, sub) {
  const td = document.createElement('td');
  td.textContent = texto;
  if (sub) {
    const s = document.createElement('small');
    s.textContent = ` ${sub}`;
    td.append(s);
  }
  return td;
}

function pintar(r) {
  const nomeDe = (slug) => r.linhas.find((l) => l.slug === slug)?.nome ?? slug ?? '—';
  const mudou = r.escolhaNova && r.escolhaAtual && r.escolhaNova !== r.escolhaAtual;
  const bike = r.bike?.raridade ? `${RARIDADE[r.bike.raridade] ?? r.bike.raridade}, passo ×${String(Math.round(r.bike.fator * 100) / 100).replace('.', ',')}` : 'nenhuma, a pé';
  $('resumo').replaceChildren(
    cartao('Melhor hunt hoje', nomeDe(r.escolhaAtual)),
    cartao(mudou ? 'Com camadas escolheria outra' : 'Com camadas', nomeDe(r.escolhaNova), mudou),
    cartao('Pokémon em campo', `${r.pokemon?.nome ?? '—'}${r.pokemon?.aoe ? ' · com AoE' : ' · sem AoE'}`),
    cartao('Bicicleta', bike),
    cartao('Hunts com levas medidas', String(r.huntsMedidas)),
  );
  $('resumo').hidden = false;
  const corpo = $('tabela').tBodies[0];
  corpo.replaceChildren(...r.linhas.map((l) => {
    const tr = document.createElement('tr');
    tr.classList.toggle('atual', l.slug === r.huntAtual);
    tr.classList.toggle('escolha-hoje', l.slug === r.escolhaAtual);
    tr.classList.toggle('escolha-nova', l.slug === r.escolhaNova);
    const alvos = l.alvos ? `${String(Math.round(l.alvos.valor * 10) / 10).replace('.', ',')}` : '—';
    const fonte = l.alvos ? { medido: 'medido', bando: 'pelo bando', 'extensão': 'da extensão' }[l.alvos.fonte] ?? '' : 'sem AoE';
    tr.append(
      celula(l.nome),
      celula(fmt(l.base)),
      celula(fmt(l.atual)),
      celula(fmt(l.novo), l.medida ? 'medido' : ''),
      celula(alvos, fonte),
    );
    return tr;
  }));
  $('tabela').hidden = false;
  const hora = new Date(r.em).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  $('status').className = 'fraco';
  $('status').textContent = `Valores em ${r.unidade}, lidos às ${hora}.${r.ritmoReal ? '' : ' A opção "pelo ritmo real" está desligada nesta conta, então "Hoje" é igual ao /hunt.'}${mudou ? ' Com as camadas, a escolha seria outra: confira por alguns dias antes de deixar decidir.' : ''}`;
}

async function carregarContas() {
  const lista = await window.tick.huntContas();
  const antes = $('conta').value;
  $('conta').replaceChildren(...lista.map((c) => {
    const o = document.createElement('option');
    o.value = String(c.n);
    o.textContent = c.nome;
    return o;
  }));
  if (lista.some((c) => String(c.n) === antes)) $('conta').value = antes;
  $('analisar').disabled = !lista.length;
  if (!lista.length) $('status').textContent = 'Nenhuma conta conectada agora.';
}

$('analisar').addEventListener('click', async () => {
  const n = Number($('conta').value);
  $('analisar').disabled = true;
  $('status').className = 'fraco';
  $('status').textContent = 'Lendo o ranking da extensão /hunt nessa conta…';
  try {
    pintar(await window.tick.huntAnalisar(n));
  } catch (e) {
    $('status').className = 'erro';
    $('status').textContent = `Não deu: ${String(e?.message ?? e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')}`;
  } finally {
    $('analisar').disabled = false;
  }
});

window.tick.aoEstado(() => carregarContas());
