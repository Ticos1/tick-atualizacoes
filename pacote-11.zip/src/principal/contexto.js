// @ts-check
// O contexto do processo principal: o main.js e os módulos de src/principal põem aqui as funções e o estado
// que os outros usam. Quem usa uma função alheia a pega na hora da chamada (usar), então a ordem em que os
// módulos carregam não importa; e conferir(), no início do app, acusa qualquer nome que tenha ficado sem dono.

/** @type {Record<string, any>} */
const ctx = {};
const pedidos = new Set();

/**
 * Funções de outros módulos, buscadas no contexto só quando chamadas.
 * @param {...string} nomes
 * @returns {Record<string, (...args: any[]) => any>}
 */
function usar(...nomes) {
  for (const n of nomes) pedidos.add(n);
  return Object.fromEntries(nomes.map((n) => [n, (...args) => ctx[n](...args)]));
}

/**
 * Estado que os outros leem (e, com `set`, trocam): ctx.nome sempre vale o atual.
 * @param {Record<string, (() => any) | { get: () => any, set: (v: any) => void }>} campos
 */
function expor(campos) {
  for (const [nome, c] of Object.entries(campos)) {
    const desc = typeof c === 'function' ? { get: c } : c;
    Object.defineProperty(ctx, nome, { ...desc, configurable: true, enumerable: true });
  }
}

/** Toda função pedida por algum módulo precisa existir no contexto. */
function conferir() {
  const faltam = [...pedidos].filter((n) => typeof ctx[n] !== 'function');
  if (faltam.length) throw new Error(`o Tick ficou sem: ${faltam.join(', ')}`);
}

module.exports = { ctx, usar, expor, conferir };
