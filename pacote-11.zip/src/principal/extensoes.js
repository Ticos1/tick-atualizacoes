// Extensões por conta: catálogo, escolhas, download da Chrome Web Store e atualização.
const { dialog } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const logica = require('../logica');
const crx = require('../crx');
const { ctx, usar } = require('./contexto');
const { PASTA_EXT, LIGADAS_POR_PADRAO, EDICAO_AMIGO, dadosTeste, TESTE_APP, ID_SCRIPT, ID_ROTOM, CONFLITOS } = require('./constantes');

const { dados, registrarErro, gravarSeguro, anotar, recarregarConta, registrar, publicar, nomeDoNumero, nomeDe } = usar('dados', 'registrarErro', 'gravarSeguro', 'anotar', 'recarregarConta', 'registrar', 'publicar', 'nomeDoNumero', 'nomeDe');

// ---------------------------------------------------------------- extensões por conta
// As que vêm com o Tick ficam em vendor/; as adicionadas pela pessoa, nos dados do app.
const pastaAdicionadas = () => dados('extensoes');
const arquivoEscolhas = () => dados('extensoes.json');

function lerManifesto(pasta) {
  return JSON.parse(fs.readFileSync(path.join(pasta, 'manifest.json'), 'utf8').replace(/^\uFEFF/, ''));
}

function catalogo() {
  const lista = [];
  const entrar = (novo) => {
    // A mesma extensão nas duas pastas (a de fábrica e a baixada da loja): vale a versão mais nova.
    const i = lista.findIndex((x) => x.id === novo.id);
    if (i < 0) lista.push(novo);
    else if (logica.compararVersoes(novo.versao, lista[i].versao) > 0) lista[i] = novo;
  };
  for (const raiz of [PASTA_EXT, pastaAdicionadas()]) {
    if (!fs.existsSync(raiz)) continue;
    for (const d of fs.readdirSync(raiz, { withFileTypes: true })) {
      if (!d.isDirectory()) continue;
      const pasta = path.join(raiz, d.name);
      try {
        const m = lerManifesto(pasta);
        entrar({ id: d.name, nome: m.name.startsWith('__MSG_') ? d.name : m.name, versao: m.version, pasta });
      } catch (e) { registrarErro(`extensão ${d.name}`, e); }
    }
  }
  return lista;
}

function lerEscolhas() {
  try { return JSON.parse(fs.readFileSync(arquivoEscolhas(), 'utf8')); } catch { return {}; }
}

function estaAtiva(n, id) {
  return lerEscolhas()[n]?.[id] ?? LIGADAS_POR_PADRAO.has(id);
}

function salvarEscolha(n, id, ativa) {
  const e = lerEscolhas();
  e[n] = { ...e[n], [id]: ativa };
  gravarSeguro(arquivoEscolhas(), JSON.stringify(e, null, 2));
}

// A edição para outras pessoas não leva as extensões de terceiros: cada PC baixa da Chrome Web Store, o canal
// oficial dos autores. Falhou? O Tick abre mesmo assim, e tenta de novo na próxima vez.
async function baixarExtensoesDaLoja() {
  const faltando = Object.entries(crx.DA_LOJA).filter(([id]) => !catalogo().some((x) => x.id === id));
  if (!EDICAO_AMIGO || !faltando.length) return;
  fs.mkdirSync(pastaAdicionadas(), { recursive: true });
  const falhas = [];
  for (const [id, daLoja] of faltando) {
    try {
      const r = await fetch(crx.urlDaLoja(daLoja, process.versions.chrome), { signal: AbortSignal.timeout(30_000) });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      crx.instalarCrx(Buffer.from(await r.arrayBuffer()), path.join(pastaAdicionadas(), id), daLoja);
      anotar(`extensão ${id} baixada da Chrome Web Store: ${lerManifesto(path.join(pastaAdicionadas(), id)).version}`);
    } catch (e) {
      registrarErro(`baixar extensão ${id}`, e);
      falhas.push(id);
    }
  }
  if (falhas.length) {
    dialog.showMessageBox({
      type: 'warning', title: 'Tick', message: 'Não consegui baixar todas as extensões.',
      detail: `Faltou: ${falhas.join(', ')}. O Tick segue sem elas. Confira a internet e abra o Tick de novo.`,
    });
  }
}

// A /hunt muda junto com o jogo, e a Melhor hunt decide pelo ranking dela. Só no Tick da casa.
const ATUALIZAR_SOZINHAS = ['hunt'];
const CHECAR_EXTENSOES_MS = 6 * 60 * 60_000;
const ENTRE_RECARGAS_MS = 5_000; // uma conta de cada vez

async function pedirNaLoja(url) {
  const r = await fetch(url, { signal: AbortSignal.timeout(30_000) });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r;
}

async function atualizarExtensao(id) {
  const atual = catalogo().find((x) => x.id === id);
  const daLoja = crx.DA_LOJA[id];
  const nova = crx.versaoDaResposta(await (await pedirNaLoja(crx.urlDaChecagem(daLoja, process.versions.chrome))).text());
  if (!nova || (atual && logica.compararVersoes(nova, atual.versao) <= 0)) return;
  const pacote = Buffer.from(await (await pedirNaLoja(crx.urlDaLoja(daLoja, process.versions.chrome))).arrayBuffer());
  crx.conferirAssinaturaCrx3(pacote, daLoja); // antes de tirar a versão em uso das contas
  // A extensão carregada guarda o manifesto antigo: sai das contas antes de os arquivos mudarem.
  const emUso = ctx.contas.filter((c) => c.extIds[id]);
  for (const c of emUso) {
    c.ses.extensions.removeExtension(c.extIds[id]);
    delete c.extIds[id];
  }
  try {
    fs.mkdirSync(pastaAdicionadas(), { recursive: true });
    crx.instalarCrx(pacote, path.join(pastaAdicionadas(), id), daLoja);
    anotar(`extensão ${id}: ${atual?.versao ?? 'nenhuma'} → ${nova}`);
  } finally {
    // Deu certo ou não, cada conta volta com a extensão que estiver na lista agora.
    for (const c of emUso) {
      if (!ctx.contas.includes(c)) continue;
      try {
        await carregarExtensao(c, catalogo().find((x) => x.id === id));
        recarregarConta(c);
      } catch (e) { registrarErro(`conta ${c.n}: extensão ${id}`, e); }
      await new Promise((ok) => setTimeout(ok, ENTRE_RECARGAS_MS));
    }
  }
}

async function atualizarExtensoes() {
  for (const id of ATUALIZAR_SOZINHAS) {
    try { await atualizarExtensao(id); } catch (e) { registrarErro(`atualizar extensão ${id}`, e); }
  }
}

function iniciarAtualizacaoDeExtensoes() {
  if (EDICAO_AMIGO || dadosTeste || TESTE_APP) return;
  setTimeout(atualizarExtensoes, 60_000);
  setInterval(atualizarExtensoes, CHECAR_EXTENSOES_MS);
}

async function carregarExtensao(conta, item) {
  // Ao religar uma conta, a sessão ainda pode ter a extensão carregada: reaproveita.
  const ja = conta.ses.extensions.getAllExtensions().find((x) => path.resolve(x.path) === path.resolve(item.pasta));
  const ext = ja ?? await conta.ses.extensions.loadExtension(item.pasta);
  conta.extIds[item.id] = ext.id;
  registrar(`conta ${conta.n}: extensão "${ext.name}" ${ext.version} carregada`);
}

async function aplicarExtensao(conta, id, ativa) {
  if (id !== ID_SCRIPT) {
    if (ativa) {
      await carregarExtensao(conta, catalogo().find((x) => x.id === id));
    } else if (conta.extIds[id]) {
      conta.ses.extensions.removeExtension(conta.extIds[id]);
      delete conta.extIds[id];
      if (id === ID_ROTOM && conta.cockpit && !conta.cockpit.isDestroyed()) conta.cockpit.close();
    }
  } else if (!ativa) {
    conta.menu = [];
  }
  salvarEscolha(conta.n, id, ativa);
  registrar(`conta ${conta.n}: ${id} ${ativa ? 'ativada' : 'desativada'}`);
}

/** Vale para conta ligada ou desligada; a desligada só guarda a escolha para quando abrir. */
async function definirExtensao(n, id, ativa) {
  const conta = ctx.contas.find((c) => c.n === n);
  const aplicar = (qual, valor) => (conta ? aplicarExtensao(conta, qual, valor) : salvarEscolha(n, qual, valor));
  if (ativa) {
    for (const outra of CONFLITOS[id] ?? []) {
      if (estaAtiva(n, outra)) await aplicar(outra, false);
    }
  }
  await aplicar(id, ativa);
  publicar();
  if (conta) recarregarConta(conta); // extensão só entra ou sai da página numa carga nova
}

function avisoAutoHunt(n) {
  dialog.showMessageBox(ctx.janela, {
    type: 'info', title: 'Tick', message: `Auto Hunt ativada na ${nomeDoNumero(n)}`,
    detail: 'A /hunt foi desativada nesta conta, porque as duas não funcionam juntas.\n\n'
      + 'A Auto Hunt também troca de hunt e compra itens. Se for ligá-la no jogo, deixe "Auto Compra" e "Melhor hunt" desligadas, para não comprar nem trocar em dobro.',
  });
}

async function marcarNoMenu(conta, item, ativa) {
  await definirExtensao(conta.n, item.id, ativa);
  if (ativa && item.id === 'auto-hunt') avisoAutoHunt(conta.n);
}

// Copia a pasta para os dados do app, carrega e só então registra: pasta quebrada não entra na lista.
async function adicionarExtensao(conta, origem) {
  const manifesto = lerManifesto(origem);
  if (!manifesto.name || !manifesto.manifest_version) throw new Error('o manifest.json não tem nome ou versão');
  const id = manifesto.name.toLowerCase().normalize('NFD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'extensao';
  if (catalogo().some((x) => x.id === id) || id === ID_SCRIPT) throw new Error('essa extensão já está na lista');
  const destino = path.join(pastaAdicionadas(), id);
  fs.cpSync(origem, destino, { recursive: true, filter: (o) => path.basename(o) !== '_metadata' });
  try {
    await carregarExtensao(conta, { id, pasta: destino });
  } catch (e) {
    fs.rmSync(destino, { recursive: true, force: true });
    throw e;
  }
  salvarEscolha(conta.n, id, true);
  recarregarConta(conta);
  return manifesto.name;
}

async function escolherExtensao(conta) {
  const { canceled, filePaths } = await dialog.showOpenDialog(ctx.janela, {
    title: 'Escolha a pasta da extensão (a que tem o manifest.json)', properties: ['openDirectory'],
  });
  if (canceled) return;
  try {
    const manifesto = lerManifesto(filePaths[0]);
    const { response } = await dialog.showMessageBox(ctx.janela, {
      type: 'warning', title: 'Tick', buttons: ['Adicionar', 'Cancelar'], defaultId: 1, cancelId: 1,
      message: `Adicionar "${manifesto.name}" à ${nomeDe(conta)}?`,
      detail: 'A extensão vai poder agir na sua conta dentro do jogo. Use só extensões em que você confia.',
    });
    if (response !== 0) return;
    const nome = await adicionarExtensao(conta, filePaths[0]);
    dialog.showMessageBox(ctx.janela, { type: 'info', title: 'Tick', message: `"${nome}" ativada na ${nomeDe(conta)}.`, detail: 'Nas outras contas ela começa desativada.' });
  } catch (e) {
    registrarErro('adicionar extensão', e);
    dialog.showMessageBox(ctx.janela, { type: 'error', title: 'Tick', message: 'Não consegui adicionar a extensão.', detail: e.code === 'ENOENT' ? 'Essa pasta não tem um manifest.json.' : e.message });
  }
}

module.exports = { pastaAdicionadas, arquivoEscolhas, lerManifesto, catalogo, lerEscolhas, estaAtiva, salvarEscolha, baixarExtensoesDaLoja, pedirNaLoja, atualizarExtensao, atualizarExtensoes, iniciarAtualizacaoDeExtensoes, carregarExtensao, aplicarExtensao, definirExtensao, avisoAutoHunt, marcarNoMenu, adicionarExtensao, escolherExtensao };
