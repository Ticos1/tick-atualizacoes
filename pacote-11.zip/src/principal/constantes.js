// @ts-check
// Os valores fixos do processo principal do Tick: caminhos, limites e tempos.
const fs = require('node:fs');
const path = require('node:path');

// A pasta src/, onde ficam as telas do Tick e o main.js.
const PASTA_SRC = path.join(__dirname, '..');
const URL_JOGO = 'https://pokeidle.io/app';
// A cópia de trabalho do script, quando existe neste PC. Em outro PC vale a cópia que anda junto com o Tick.
const SCRIPT_TRABALHO = '';
const SCRIPT_JUNTO = path.join(PASTA_SRC, '..', 'vendor', 'pokeidle-autocompra.user.js');
const ASSISTENTE = 'http://127.0.0.1:5176/pokeidle';
const PASTA_EXT = path.join(PASTA_SRC, '..', 'vendor', 'extensions');
const ICONE = path.join(PASTA_SRC, '..', 'assets', 'tick.ico');
const ID_SCRIPT = 'autocompra';
const ID_ROTOM = 'rotom-sniper';
const LIGADAS_POR_PADRAO = new Set(['hunt', ID_ROTOM, ID_SCRIPT]);
// A Auto Hunt é baseada na /hunt: as duas mexem nas mesmas coisas da página, então só uma fica ativa.
const CONFLITOS = { hunt: ['auto-hunt'], 'auto-hunt': ['hunt'] };
const MAX_CONTAS = 4; // o limite permitido pelo jogo
const ALTURA_BARRA = 38;
const LARGURA_LATERAL = 60;
const PORTA_LOGIN = 5177;
const ESPERA_LOGIN_MS = 3 * 60_000;
const QUEDA_AVISO_MS = 60_000;      // uma queda só vira aviso se durar isto (o F5 e a reconexão do jogo são normais)
const NOCAUTE_INTERVALO_MS = 5 * 60_000; // no máximo um aviso de nocaute por conta neste intervalo
const TENTAR_DE_NOVO_MS = 30_000;   // sem internet: de quanto em quanto tempo tenta abrir o jogo
const TRAVADA_MS = 60_000;          // página sem responder por este tempo é reiniciada
const LIMITE_RECARGAS = 3;          // recargas por queda da página, dentro da janela abaixo; depois só avisa
const JANELA_RECARGAS_MS = 10 * 60_000;
const ESPERA_RESTAURAR_MS = 60_000; // devolver o login guardado: intervalo e tentativas, para não recarregar sem parar
const MAX_RESTAURAR = 3;
const GRAVAR_DADOS_MS = 30_000;     // o navegador grava o localStorage com atraso: isto reduz a perda num encerramento à força
const REGISTRO_MAX_BYTES = 1_000_000;
const PASSO_ZOOM = 0.1;
// O painel do modo economia foi feito para a tela inteira e corta o que não cabe. Em uma célula baixa, ele
// passa a rolar: o conteúdo mantém uma altura mínima, e em janela alta nada muda.
const CSS_ECONOMIA = `
  html.modo-economia .eco-painel { overflow-y: auto !important; }
  html.modo-economia .eco-corpo { flex: 1 0 620px !important; }
`;
const LARGURAS = [['Estreita', 0.75], ['Normal', 1], ['Larga', 1.5], ['Muito larga', 2]];
const MODOS = [['auto', 'Automático (2×2 com 4 contas)'], ['colunas', 'Colunas'], ['2x2', '2×2']];
const DIAG = process.argv.includes('--diag');
const TESTE_APP = process.argv.includes('--teste-app');
const PASTA_DIAG = path.join(PASTA_SRC, '..', 'diag');

// Os testes rodam em dados à parte, sem tocar nas contas de verdade.
const dadosTeste = process.argv.find((a) => a.startsWith('--dados='));
// Fora do AppData de propósito: o Windows redireciona o AppData de quem é aberto por um app da Loja, como o
// Claude Desktop. Lá, o Tick aberto pelo atalho e o aberto pelo Claude enxergariam contas diferentes.
// Empacotado, os dados ficam fora de dist/, que é apagada a cada novo pacote.
// A edição para outras pessoas pode ser aberta de qualquer pasta: os dados ficam no AppData de quem usa.
const EDICAO_AMIGO = fs.existsSync(path.join(PASTA_SRC, '..', 'amigo.json'));

module.exports = {
  PASTA_SRC,
  URL_JOGO,
  SCRIPT_TRABALHO,
  SCRIPT_JUNTO,
  ASSISTENTE,
  PASTA_EXT,
  ICONE,
  ID_SCRIPT,
  ID_ROTOM,
  LIGADAS_POR_PADRAO,
  CONFLITOS,
  MAX_CONTAS,
  ALTURA_BARRA,
  LARGURA_LATERAL,
  PORTA_LOGIN,
  ESPERA_LOGIN_MS,
  QUEDA_AVISO_MS,
  NOCAUTE_INTERVALO_MS,
  TENTAR_DE_NOVO_MS,
  TRAVADA_MS,
  LIMITE_RECARGAS,
  JANELA_RECARGAS_MS,
  ESPERA_RESTAURAR_MS,
  MAX_RESTAURAR,
  GRAVAR_DADOS_MS,
  REGISTRO_MAX_BYTES,
  PASSO_ZOOM,
  CSS_ECONOMIA,
  LARGURAS,
  MODOS,
  DIAG,
  TESTE_APP,
  PASTA_DIAG,
  dadosTeste,
  EDICAO_AMIGO,
};
