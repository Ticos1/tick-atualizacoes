// A janela de configurações e a da Melhor hunt em camadas.
const { app, ipcMain, shell, BrowserWindow } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const logica = require('../logica');
const { lerScript } = require('../script-partes');
const { ctx, usar, expor } = require('./contexto');
const { MODOS, MAX_CONTAS, LARGURAS, ID_SCRIPT, SCRIPT_TRABALHO, ICONE, PASTA_SRC } = require('./constantes');

const { comWindows, nomeDoNumero, situacaoDe, zoomDe, catalogo, estaAtiva, ultimosErros, definirComWindows, salvarLayout, definirModo, abrirConta, fecharConta, definirMudo, definirZoom, dispor, definirApelido, definirExtensao, avisoAutoHunt, arquivoRegistro, gravarSeguro, dados, registrarErro, nomeDe } = usar('comWindows', 'nomeDoNumero', 'situacaoDe', 'zoomDe', 'catalogo', 'estaAtiva', 'ultimosErros', 'definirComWindows', 'salvarLayout', 'definirModo', 'abrirConta', 'fecharConta', 'definirMudo', 'definirZoom', 'dispor', 'definirApelido', 'definirExtensao', 'avisoAutoHunt', 'arquivoRegistro', 'gravarSeguro', 'dados', 'registrarErro', 'nomeDe');

let janelaConfig = null;
let janelaHunts = null;
expor({ janelaConfig: () => janelaConfig, janelaHunts: () => janelaHunts });

// ---------------------------------------------------------------- configurações
function versaoDoScript() {
  try { return lerScript(ctx.USERSCRIPT).match(/^\/\/ @version\s+(\S+)/m)?.[1] ?? '?'; } catch { return 'não encontrado'; }
}

function memoriaPorConta() {
  const metricas = app.getAppMetrics();
  return Object.fromEntries(ctx.contas.map((c) => {
    const pid = c.view.webContents.getOSProcessId();
    const m = metricas.find((x) => x.pid === pid);
    return [c.n, m ? Math.round(m.memory.workingSetSize / 1024) : null];
  }));
}

function montarConfig() {
  const memoria = memoriaPorConta();
  const slots = logica.ordenar(ctx.layout.slots, ctx.layout.ordem);
  return {
    geral: { comWindows: comWindows(), xSai: ctx.layout.xSai, modo: ctx.layout.modo },
    modos: MODOS,
    avisos: ctx.layout.avisos,
    contas: slots.map((n) => {
      const c = ctx.contas.find((x) => x.n === n);
      return {
        n, nome: nomeDoNumero(n), apelido: ctx.layout.apelidos[n] ?? '', ligada: !!c, situacao: c ? situacaoDe(c) : 'desligada',
        mudo: !!ctx.layout.mudas[n], zoom: zoomDe(n), peso: ctx.layout.pesos[n] ?? 1, memoria: memoria[n] ?? null,
      };
    }),
    podeAdicionar: logica.proximaConta(ctx.layout.slots, MAX_CONTAS) != null,
    larguras: LARGURAS,
    zoomMin: logica.ZOOM_MIN,
    zoomMax: logica.ZOOM_MAX,
    extensoes: [
      { id: ID_SCRIPT, nome: 'Auto Compra', versao: versaoDoScript() },
      ...catalogo().map(({ id, nome, versao }) => ({ id, nome, versao })),
    ].map((x) => ({ ...x, ativas: Object.fromEntries(slots.map((n) => [n, estaAtiva(n, x.id)])) })),
    versoes: { tick: app.getVersion(), electron: process.versions.electron, chromium: process.versions.chrome, script: versaoDoScript(), origemScript: ctx.USERSCRIPT === SCRIPT_TRABALHO ? 'cópia de trabalho' : 'cópia junto do Tick' },
    erros: ultimosErros(),
    cofre: ctx.cofreDisponivel,
  };
}

ipcMain.handle('tick:config', montarConfig);
ipcMain.handle('tick:memoria', memoriaPorConta);

ipcMain.handle('tick:config-definir', async (_ev, chave, n, valor) => {
  const conta = ctx.contas.find((c) => c.n === n);
  if (chave === 'comWindows') definirComWindows(!!valor);
  else if (chave === 'xSai') { ctx.layout.xSai = !!valor; salvarLayout(); }
  else if (chave === 'modo') definirModo(valor);
  else if (chave === 'aviso' && n in ctx.layout.avisos) { ctx.layout.avisos[n] = !!valor; salvarLayout(); }
  else if (chave === 'adicionar') await abrirConta();
  else if (chave === 'ligada') { if (valor && !conta) await abrirConta(n); else if (!valor && conta) fecharConta(conta); }
  else if (chave === 'mudo' && conta) definirMudo(conta, !!valor);
  else if (chave === 'mudo') { ctx.layout.mudas[n] = !!valor; salvarLayout(); }
  else if (chave === 'zoom' && conta) definirZoom(conta, valor);
  else if (chave === 'zoom') { ctx.layout.zooms[n] = logica.limitarZoom(valor); salvarLayout(); }
  else if (chave === 'peso' && LARGURAS.some(([, p]) => p === valor)) { ctx.layout.pesos[n] = valor; salvarLayout(); dispor(); }
  else if (chave === 'nome') definirApelido(n, valor);
  else if (chave === 'extensao') {
    const [id, ativa] = valor;
    await definirExtensao(n, id, ativa);
    if (ativa && id === 'auto-hunt') avisoAutoHunt(n);
  } else if (chave === 'abrir-registro') {
    if (!fs.existsSync(arquivoRegistro())) gravarSeguro(arquivoRegistro(), '');
    shell.openPath(arquivoRegistro());
  } else if (chave === 'abrir-dados') shell.openPath(dados());
  return montarConfig();
});

// ---------------------------------------------------------------- melhor hunt em camadas
// Só compara: a conta lê o ranking da extensão /hunt e devolve as camadas; quem troca de hunt é a Melhor hunt.
function abrirHunts() {
  if (janelaHunts && !janelaHunts.isDestroyed()) { janelaHunts.show(); return janelaHunts.focus(); }
  janelaHunts = new BrowserWindow({
    width: 820, height: 640, minWidth: 560, minHeight: 400, title: 'Melhor hunt em camadas', autoHideMenuBar: true, icon: ICONE, backgroundColor: '#171a2b',
    webPreferences: { preload: path.join(PASTA_SRC, 'preload-ui.js') },
  });
  janelaHunts.loadFile(path.join(PASTA_SRC, 'hunts.html')).catch((e) => registrarErro('melhor hunt em camadas', e));
}

ipcMain.handle('tick:hunt-contas', () => ctx.contas
  .filter((c) => c.status.ws === 'conectada')
  .map((c) => ({ n: c.n, nome: nomeDe(c) })));

ipcMain.handle('tick:hunt-analisar', async (_ev, n) => {
  const conta = ctx.contas.find((c) => c.n === Number(n));
  if (!conta || conta.status.ws !== 'conectada') throw new Error('essa conta não está conectada');
  return conta.view.webContents.executeJavaScript(
    "window.__tickHunt ? window.__tickHunt.analisar() : Promise.reject(new Error('o script de Auto Compra ainda não carregou nesta conta'))",
    true,
  );
});

function abrirConfig() {
  if (janelaConfig && !janelaConfig.isDestroyed()) { janelaConfig.show(); return janelaConfig.focus(); }
  janelaConfig = new BrowserWindow({
    width: 780, height: 680, minWidth: 560, minHeight: 420, title: 'Configurações do Tick', autoHideMenuBar: true, icon: ICONE, backgroundColor: '#15131c',
    webPreferences: { preload: path.join(PASTA_SRC, 'preload-ui.js') },
  });
  janelaConfig.loadFile(path.join(PASTA_SRC, 'config.html')).catch((e) => registrarErro('configurações', e));
}

module.exports = { versaoDoScript, memoriaPorConta, montarConfig, abrirHunts, abrirConfig };
