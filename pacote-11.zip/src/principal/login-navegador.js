// Login vindo do navegador: a porta local que recebe a sessão do jogo.
const { dialog } = require('electron');
const http = require('node:http');
const logica = require('../logica');
const { ctx, usar, expor } = require('./contexto');
const { PORTA_LOGIN, ESPERA_LOGIN_MS, URL_JOGO } = require('./constantes');

const { publicar, registrarErro, registrar, nomeDe, guardarSessao } = usar('publicar', 'registrarErro', 'registrar', 'nomeDe', 'guardarSessao');

// ---------------------------------------------------------------- login vindo do Brave
// O Google recusa login dentro do Tick. Então o login é feito no Brave, e o script de lá manda a sessão
// do jogo para cá. A porta só fica aberta enquanto uma conta espera, e só em 127.0.0.1. O cabeçalho próprio
// obriga o navegador a pedir licença (CORS), que nunca é dada: um site qualquer não consegue enviar nada.
let recepcao = null;

function pararRecepcao() {
  if (!recepcao) return;
  clearTimeout(recepcao.timer);
  recepcao.servidor.close();
  recepcao.servidor.closeAllConnections();
  recepcao = null;
  publicar();
}

function receberLogin(conta, comAviso = true) {
  pararRecepcao();
  const servidor = http.createServer((req, res) => {
    const responder = (status, corpo) => {
      res.writeHead(status, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(corpo));
    };
    if (req.method !== 'POST' || req.url !== '/sessao' || req.headers['x-tick'] !== 'sessao' || !logica.hostDeLoginValido(req.headers.host, PORTA_LOGIN)) return responder(403, { erro: 'recusado' });
    let bruto = '';
    req.setEncoding('utf8');
    req.on('data', (p) => { bruto += p; if (bruto.length > 64_000) req.destroy(); });
    req.on('end', () => {
      let corpo;
      try {
        corpo = JSON.parse(bruto);
        if (typeof corpo.sessao !== 'string' || typeof JSON.parse(corpo.sessao) !== 'object') throw new Error();
      } catch { return responder(400, { erro: 'sessão inválida' }); }
      responder(200, { conta: conta.n });
      pararRecepcao();
      aplicarSessao(conta, corpo).catch((e) => registrarErro('login', e));
    });
  });
  servidor.on('error', (e) => {
    registrarErro('login', e.code);
    dialog.showMessageBox(ctx.janela, { type: 'error', title: 'Tick', message: `Não consegui abrir a porta ${PORTA_LOGIN} para receber o login.` });
    recepcao = null;
    publicar();
  });
  servidor.listen(PORTA_LOGIN, '127.0.0.1');
  recepcao = { servidor, conta, timer: setTimeout(pararRecepcao, ESPERA_LOGIN_MS) };
  registrar(`login: conta ${conta.n} esperando sessão`);
  publicar();
  if (comAviso) {
    dialog.showMessageBox(ctx.janela, {
      type: 'info', title: 'Tick', message: `${nomeDe(conta)} esperando o login (3 minutos)`,
      detail: 'No navegador, entre no PokeIdle com a conta desejada e aperte F5.\n\nDepois abra o menu do Tampermonkey e clique em "Enviar esta conta ao Tick".',
    });
  }
}

async function aplicarSessao(conta, { sessao, nick }) {
  const wc = conta.view.webContents;
  conta.restauracoes = 0;
  try { await wc.loadURL(URL_JOGO); } catch { /* o jogo pode redirecionar no meio da carga */ }
  await wc.executeJavaScript(`localStorage.setItem('sessao', ${JSON.stringify(sessao)});
    ${typeof nick === 'string' ? `localStorage.setItem('nick', ${JSON.stringify(nick)});` : ''}`);
  guardarSessao(conta.n, sessao);
  wc.reload();
  registrar(`login: sessão aplicada na conta ${conta.n}`);
  dialog.showMessageBox(ctx.janela, { type: 'info', title: 'Tick', message: `Login recebido na ${nomeDe(conta)}.` });
}

expor({ recepcao: () => recepcao });
module.exports = { pararRecepcao, receberLogin, aplicarSessao };
