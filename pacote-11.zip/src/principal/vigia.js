// O vigia que reabre o Tick quando ele cai ou trava, e o diagnóstico das quedas.
const { app } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { ctx, usar } = require('./contexto');
const { PASTA_SRC, DIAG, TESTE_APP } = require('./constantes');

const { dados, arquivoRegistro, registrarErro, anotar, avisar, gravarSeguro } = usar('dados', 'arquivoRegistro', 'registrarErro', 'anotar', 'avisar', 'gravarSeguro');

// ---------------------------------------------------------------- vigia
// Processo separado que reabre o app se ele cair ou travar. A marca em dados/ é o que separa uma queda de uma
// saída normal; o sinal de vida, a cada 30 s, é o que separa um Tick travado de um vivo. E o Tick confere o
// vigia a cada minuto: se ele parar, inicia outro.
const marcaVigia = () => dados('tick.rodando');
const SINAL_MS = 30_000;
const CONFERIR_VIGIA_MS = 60_000;
const FUNCIONANDO_MS = 30 * 60_000;

const processoVivo = (pid) => {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return e.code === 'EPERM';
  }
};

function lancarVigia() {
  const filho = spawn(process.execPath, [path.join(PASTA_SRC, 'vigia.js'), JSON.stringify({
    pid: process.pid,
    marca: marcaVigia(),
    sinal: dados('tick.vivo'),
    pidVigia: dados('vigia.pid'),
    ultimo: dados('vigia-ultimo.json'),
    registro: arquivoRegistro(),
    historico: dados('vigia.json'),
    exe: process.execPath,
    args: process.argv.slice(1),
  })], { detached: true, stdio: 'ignore', windowsHide: true, env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' } });
  filho.on('error', (e) => registrarErro('vigia', e));
  filho.unref();
}

/** O vigia que vigia este Tick ainda está de pé? */
function vigiaVivo() {
  try {
    const v = JSON.parse(fs.readFileSync(dados('vigia.pid'), 'utf8'));
    return v.tick === process.pid && processoVivo(v.pid);
  } catch {
    return false;
  }
}

/** Reaberto pelo vigia: conta o porquê, e um aviso no Windows. */
function contarReabertura() {
  let ultimo = null;
  try { ultimo = JSON.parse(fs.readFileSync(dados('vigia-ultimo.json'), 'utf8')); } catch { return; }
  try { fs.rmSync(dados('vigia-ultimo.json')); } catch { /* segue */ }
  if (!ultimo || Date.now() - ultimo.em > 60 * 60_000) return;
  const oque = ultimo.motivo === 'travou' ? 'travou e foi fechado' : 'fechou sozinho';
  const vezes = ultimo.quedas > 1 ? ` Foram ${ultimo.quedas} vezes na última meia hora: se continuar, rode o Diagnóstico do Tick.` : '';
  anotar(`reaberto pelo vigia: o Tick ${oque}`);
  avisar('queda', 'O Tick foi reaberto', `O Tick ${oque}, e o vigia abriu de novo.${vezes}`);
}

function iniciarVigia() {
  if (!app.isPackaged || DIAG || TESTE_APP || !app.hasSingleInstanceLock()) return;
  if (fs.existsSync(marcaVigia())) {
    anotar('[erro] a última saída do Tick não foi normal: queda, falta de energia ou encerramento à força');
    anotarArquivosDeQueda();
    contarReabertura();
  }
  gravarSeguro(marcaVigia(), String(process.pid));
  const sinal = () => { try { gravarSeguro(dados('tick.vivo'), JSON.stringify({ pid: process.pid, em: Date.now() })); } catch { /* tenta no próximo */ } };
  sinal();
  setInterval(sinal, SINAL_MS);
  lancarVigia();
  setInterval(() => {
    if (!app.hasSingleInstanceLock() || vigiaVivo()) return;
    anotar('[erro] o vigia parou — iniciando outro');
    lancarVigia();
  }, CONFERIR_VIGIA_MS);
}

// ---------------------------------------------------------------- diagnóstico de quedas
// Os arquivos de queda ficam só neste PC, em dados/Crashpad, e nunca são enviados: podem ter pedaços da memória
// do app, inclusive login. Só os 5 mais novos ficam.
function anotarArquivosDeQueda() {
  const pasta = path.join(app.getPath('crashDumps'), 'reports');
  let arquivos = [];
  try {
    arquivos = fs.readdirSync(pasta).filter((f) => f.endsWith('.dmp'))
      .map((f) => ({ f, em: fs.statSync(path.join(pasta, f)).mtimeMs })).sort((a, b) => b.em - a.em);
  } catch { return; }
  const desde = (() => { try { return fs.statSync(marcaVigia()).mtimeMs; } catch { return 0; } })();
  for (const a of arquivos.filter((x) => x.em >= desde)) anotar(`[erro] arquivo de queda guardado: ${a.f}, de ${new Date(a.em).toISOString()}`);
  for (const a of arquivos.slice(5)) { try { fs.rmSync(path.join(pasta, a.f)); } catch { /* segue */ } }
}

function iniciarDiagnosticoDeQuedas() {
  // Vídeo, rede e utilitários do Electron: quando um deles cai várias vezes, o app inteiro fecha sem aviso.
  app.on('child-process-gone', (_ev, d) => {
    if (d.reason === 'clean-exit') return;
    anotar(`[erro] processo ${d.type}${d.name ? ` (${d.name})` : ''} parou: ${d.reason}, código ${d.exitCode}`);
  });
  setInterval(() => {
    const mb = Math.round(app.getAppMetrics().reduce((t, m) => t + (m.memory?.workingSetSize ?? 0), 0) / 1024);
    anotar(`Tick funcionando: ${ctx.contas.length} contas abertas, ${mb} MB de memória`);
  }, FUNCIONANDO_MS);
  app.on('will-quit', () => anotar('saindo: saída normal'));
}

function apagarMarcaVigia() {
  try {
    if (fs.readFileSync(marcaVigia(), 'utf8').trim() === String(process.pid)) fs.rmSync(marcaVigia());
  } catch { /* sem marca: nada a fazer */ }
}

app.on('will-quit', apagarMarcaVigia);

module.exports = { marcaVigia, processoVivo, lancarVigia, vigiaVivo, contarReabertura, iniciarVigia, anotarArquivosDeQueda, iniciarDiagnosticoDeQuedas, apagarMarcaVigia };
