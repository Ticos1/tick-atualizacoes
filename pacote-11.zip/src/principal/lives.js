// A live em janela própria e o cockpit do Rotom Sniper.
const { BrowserWindow, Menu } = require('electron');
const logica = require('../logica');
const { usar, expor } = require('./contexto');
const { ICONE, ID_ROTOM } = require('./constantes');

const { limitarPermissoes, abrirNoNavegador, registrarErro, anotar, ordenadas, nomeDe } = usar('limitarPermissoes', 'abrirNoNavegador', 'registrarErro', 'anotar', 'ordenadas', 'nomeDe');

// ---------------------------------------------------------------- live em janela própria
// Os pontos do canal só caem para quem assiste com o vídeo rodando. Por isso é uma janela de verdade, uma só,
// com a conta da pessoa: sem som e, na Twitch, na menor qualidade. Nada aqui clica ou resgata nada sozinho.
let janelaLive = null;
let liveComSom = false;
const HOSTS_LIVE = /(^|\.)(twitch\.tv|kick\.com)$/;
const urlDaLive = (rede, id) => (rede === 'twitch' ? `https://www.twitch.tv/${encodeURIComponent(id)}` : `https://kick.com/${encodeURIComponent(id)}`);

function abrirLive(rede, id, nome) {
  const url = urlDaLive(rede, id);
  if (!janelaLive || janelaLive.isDestroyed()) {
    janelaLive = new BrowserWindow({
      width: 520, height: 340, minWidth: 320, minHeight: 200, title: 'Live', autoHideMenuBar: true, icon: ICONE, backgroundColor: '#000000',
      webPreferences: { partition: 'persist:lives', backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required' },
    });
    const wc = janelaLive.webContents;
    limitarPermissoes(wc.session);
    wc.setAudioMuted(!liveComSom);
    wc.setWindowOpenHandler(({ url: alvo }) => {
      abrirNoNavegador(alvo);
      return { action: 'deny' };
    });
    wc.on('will-navigate', (ev, alvo) => {
      let host = '';
      try { host = new URL(alvo).hostname; } catch { /* endereço inválido fica de fora */ }
      if (!HOSTS_LIVE.test(host)) { ev.preventDefault(); abrirNoNavegador(alvo); }
    });
    // A Twitch guarda a qualidade na própria página: na primeira carga, grava e recarrega uma vez.
    wc.on('did-finish-load', async () => {
      if (!wc.getURL().includes('twitch.tv')) return;
      const mudou = await wc.executeJavaScript(`(() => {
        const q = JSON.stringify({ default: '160p30' });
        if (localStorage.getItem('video-quality') === q) return false;
        localStorage.setItem('video-quality', q);
        return true;
      })()`).catch(() => false);
      if (mudou) wc.reload();
    });
    janelaLive.on('closed', () => { janelaLive = null; });
  }
  janelaLive.setTitle(`Live: ${nome}`);
  janelaLive.loadURL(url).catch((e) => registrarErro('live', e));
  janelaLive.show();
  anotar(`live aberta: ${rede}/${id}`);
}

function textoHoras(ms) {
  const min = Math.round(ms / 60_000);
  return min >= 60 ? `${Math.floor(min / 60)}h${String(min % 60).padStart(2, '0')}` : `${min} min`;
}

function menuLives() {
  const canais = new Map();
  const agora = Date.now();
  const situacao = [];
  for (const c of ordenadas()) {
    const horas = [];
    for (const [rede, rotulo] of [['twitch', 'Twitch'], ['kick', 'Kick']]) {
      const b = c.status[rede];
      if (!b) continue;
      for (const k of b.canais) if (k.aoVivo && k.ativo) canais.set(`${rede}/${k.id}`, { ...k, rede, rotulo });
      for (const [tipo, ate] of Object.entries(b.bonus)) if (Number(ate) > agora) horas.push(`${rotulo} ${tipo} ${textoHoras(Number(ate) - agora)}`);
    }
    const vinculos = ['twitch', 'kick'].filter((r) => c.status[r]?.vinculado).join(' e ');
    situacao.push({ label: `${nomeDe(c)}: ${horas.join(', ') || 'sem bônus'}${vinculos ? '' : ' (sem Twitch ou Kick vinculada)'}`, enabled: false });
  }
  const ordem = [...canais.values()].sort((a, b) => b.espectadores - a.espectadores).slice(0, 15);
  const aberta = janelaLive && !janelaLive.isDestroyed();
  return Menu.buildFromTemplate([
    { label: 'Lives oficiais com pontos, ao vivo', enabled: false },
    ...(ordem.length
      ? ordem.map((k) => ({ label: `${k.rotulo}: ${k.nome} (${logica.numeroCurto(k.espectadores)})`, click: () => abrirLive(k.rede, k.id, k.nome) }))
      : [{ label: 'Nenhuma agora, ou as contas ainda não conectaram', enabled: false }]),
    { type: 'separator' },
    { label: 'Som da live', type: 'checkbox', checked: liveComSom, click: (i) => { liveComSom = i.checked; if (aberta) janelaLive.webContents.setAudioMuted(!liveComSom); } },
    { label: 'Fechar a live', enabled: !!aberta, click: () => janelaLive.close() },
    { type: 'separator' },
    { label: 'Horas de bônus', enabled: false },
    ...situacao,
  ]);
}

function abrirCockpit(conta) {
  if (!conta.extIds[ID_ROTOM]) return;
  if (conta.cockpit && !conta.cockpit.isDestroyed()) return conta.cockpit.focus();
  conta.cockpit = new BrowserWindow({
    width: 1160, height: 760, title: `Rotom Sniper — ${nomeDe(conta)}`, autoHideMenuBar: true, icon: ICONE,
    webPreferences: { session: conta.ses, backgroundThrottling: false },
  });
  conta.cockpit.webContents.setWindowOpenHandler(({ url }) => {
    abrirNoNavegador(url);
    return { action: 'deny' };
  });
  conta.cockpit.loadURL(`chrome-extension://${conta.extIds[ID_ROTOM]}/cockpit.html`).catch((e) => registrarErro('cockpit', e));
}

expor({ janelaLive: () => janelaLive });
module.exports = { urlDaLive, abrirLive, textoHoras, menuLives, abrirCockpit };
