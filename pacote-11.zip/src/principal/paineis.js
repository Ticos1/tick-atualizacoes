// Os painéis abertos pela barra lateral: meta do PvP e Triar Depot.
const { dialog, Menu, BrowserWindow, ipcMain } = require('electron');
const path = require('node:path');
const logica = require('../logica');
const { ctx, usar, expor } = require('./contexto');
const { ICONE, PASTA_SRC } = require('./constantes');

const { registrarErro, salvarLayout, anotar, mostrar, ordenadas } = usar('registrarErro', 'salvarLayout', 'anotar', 'mostrar', 'ordenadas');

// ---------------------------------------------------------------- meta do PvP
// Uma conta só lê o ranking sozinha. Qual é fica nos dados do Tick (layout.contaMeta), nunca no código, que é
// público. A análise e o painel são do script, na página da conta; aqui só se escolhe a conta e se abre.
const contaDoMeta = () => ctx.contas.find((c) => ctx.layout.contaMeta && c.status.nick === ctx.layout.contaMeta);

function marcarColetorDoMeta(conta) {
  const sim = !!ctx.layout.contaMeta && conta.status.nick === ctx.layout.contaMeta;
  conta.view.webContents.executeJavaScript(sim ? "localStorage.setItem('tick.metaColetor', '1')" : "localStorage.removeItem('tick.metaColetor')")
    .catch((e) => registrarErro('meta do PvP', e));
}

function escolherContaMeta(depois) {
  const opcoes = ctx.contas.filter((c) => c.status.nick);
  if (!opcoes.length) {
    return dialog.showMessageBox(ctx.janela, { type: 'info', message: 'Entre em uma conta primeiro', detail: 'O meta do PvP é lido do ranking do jogo por uma das suas contas.' });
  }
  Menu.buildFromTemplate([
    { label: 'Qual conta analisa o meta a cada 6 h?', enabled: false },
    ...opcoes.map((c) => ({
      label: c.status.nick,
      type: 'radio',
      checked: c.status.nick === ctx.layout.contaMeta,
      click: () => {
        ctx.layout.contaMeta = c.status.nick;
        salvarLayout();
        for (const x of ctx.contas) marcarColetorDoMeta(x);
        anotar('meta do PvP: conta escolhida');
        depois?.();
      },
    })),
  ]).popup({ window: ctx.janela });
}

function abrirMeta() {
  // O clique esquerdo nunca abre o menu de escolha, que é do botão direito: sem conta escolhida, fica com a
  // que está em foco ou com a primeira conectada.
  if (!ctx.layout.contaMeta) {
    const pronta = (c) => c && c.status.ws === 'conectada' && c.status.nick;
    const padrao = pronta(ctx.focada) ? ctx.focada : logica.ordenar(ctx.contas.map((c) => c.n), ctx.layout.ordem).map((n) => ctx.contas.find((c) => c.n === n)).find(pronta);
    if (!padrao) {
      return dialog.showMessageBox(ctx.janela, { type: 'info', message: 'Entre em uma conta primeiro', detail: 'O meta do PvP é lido do ranking do jogo por uma das suas contas.' });
    }
    ctx.layout.contaMeta = padrao.status.nick;
    salvarLayout();
    for (const x of ctx.contas) marcarColetorDoMeta(x);
    anotar('meta do PvP: conta escolhida sozinha');
  }
  const conta = contaDoMeta();
  if (!conta || conta.status.ws !== 'conectada') {
    return dialog.showMessageBox(ctx.janela, {
      type: 'info',
      message: `${ctx.layout.contaMeta} não está conectada`,
      detail: 'Ligue essa conta, ou clique com o botão direito no botão do meta para escolher outra.',
    });
  }
  const item = (conta.menu ?? []).find((m) => m.nome.startsWith('🏆'));
  if (!item) {
    return dialog.showMessageBox(ctx.janela, { type: 'info', message: 'Auto Compra ainda não está pronto nessa conta', detail: 'Espere a conta terminar de carregar, ou ligue o script de Auto Compra nela.' });
  }
  mostrar(conta);
  conta.view.webContents.send('tick:menu-click', item.id);
}

// ---------------------------------------------------------------- triar depot
// O Depot é de cada conta e a triagem é do script, na página dela: a janela só pede a prévia, mostra as listas
// e repassa o "Confirmar". Nada é vendido nem guardado sem ele.
let janelaDepot = null;

function triarDepot() {
  const conectadas = ctx.contas.filter((c) => c.status.ws === 'conectada' && c.status.nick);
  if (!conectadas.length) {
    return dialog.showMessageBox(ctx.janela, { type: 'info', message: 'Entre em uma conta primeiro', detail: 'A triagem olha o Depot da conta que você escolher.' });
  }
  // Com uma conta na tela, a janela já abre nela.
  const preferida = ctx.focada && conectadas.includes(ctx.focada) ? ctx.focada : ordenadas().find((c) => conectadas.includes(c));
  if (janelaDepot && !janelaDepot.isDestroyed()) { janelaDepot.show(); return janelaDepot.focus(); }
  janelaDepot = new BrowserWindow({
    width: 860, height: 680, minWidth: 520, minHeight: 420, title: 'Triar Depot', autoHideMenuBar: true, icon: ICONE, backgroundColor: '#171a2b',
    webPreferences: { preload: path.join(PASTA_SRC, 'preload-ui.js') },
  });
  janelaDepot.loadFile(path.join(PASTA_SRC, 'depot.html'), { query: { n: String(preferida?.n ?? '') } }).catch((e) => registrarErro('triar depot', e));
  anotar(`triar depot: janela aberta${preferida ? ` na conta ${preferida.n}` : ''}`);
}

/** Roda uma chamada da ponte do Depot na página da conta. Só os nomes e valores conferidos aqui chegam lá. */
function naPonteDoDepot(n, chamada) {
  const conta = ctx.contas.find((c) => c.n === Number(n));
  if (!conta || conta.status.ws !== 'conectada') return Promise.reject(new Error('essa conta não está conectada'));
  return conta.view.webContents.executeJavaScript(
    `window.__tickDepot ? Promise.resolve().then(() => window.__tickDepot.${chamada}) : Promise.reject(new Error('o script de Auto Compra ainda não carregou nesta conta'))`,
    true,
  );
}

ipcMain.handle('tick:depot-previa', (_ev, n) => naPonteDoDepot(n, 'previa()'));
ipcMain.handle('tick:depot-situacao', (_ev, n) => naPonteDoDepot(n, 'situacao()'));
ipcMain.handle('tick:depot-parar', (_ev, n) => naPonteDoDepot(n, 'parar()'));
ipcMain.handle('tick:depot-confirmar', (_ev, n, token, manter) => {
  if (typeof token !== 'string' || !/^[a-z0-9]{4,40}$/.test(token)) throw new Error('prévia inválida');
  const ids = (Array.isArray(manter) ? manter : []).map(Number).filter((x) => Number.isInteger(x) && x > 0);
  anotar(`triar depot: confirmado na conta ${n}${ids.length ? `, ${ids.length} deixados de fora` : ''}`);
  return naPonteDoDepot(n, `confirmar(${JSON.stringify(token)}, ${JSON.stringify(ids)})`);
});

expor({ janelaDepot: () => janelaDepot });
module.exports = { contaDoMeta, marcarColetorDoMeta, escolherContaMeta, abrirMeta, triarDepot, naPonteDoDepot };
