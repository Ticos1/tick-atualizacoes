// Login lembrado: a cópia cifrada pelo Windows de cada sessão do jogo.
const { safeStorage, dialog } = require('electron');
const fs = require('node:fs');
const { ctx, usar, expor } = require('./contexto');
const { MAX_RESTAURAR, ESPERA_RESTAURAR_MS } = require('./constantes');

const { dados, gravarSeguro, registrarErro, nomeDe, recarregarConta, registrar, anotar } = usar('dados', 'gravarSeguro', 'registrarErro', 'nomeDe', 'recarregarConta', 'registrar', 'anotar');

// ---------------------------------------------------------------- login lembrado
// O jogo apaga a sessão salva em qualquer resposta ruim do servidor, até num erro passageiro. O Tick guarda
// uma cópia criptografada pelo Windows e a devolve quando ela some. Se o token venceu de verdade, o próprio
// jogo pede login de novo. A criptografia é assíncrona, mas a página pede a cópia de forma síncrona antes de
// carregar: por isso as sessões ficam abertas em memória, e o disco só tem a versão cifrada.
const arquivoSessoes = () => dados('sessoes.json');
const sessoes = new Map();
let cifradas = {};
let cofreDisponivel = false;
let filaCofre = Promise.resolve();

const gravarCofre = () => gravarSeguro(arquivoSessoes(), JSON.stringify(cifradas));

async function abrirCofre() {
  cofreDisponivel = await safeStorage.isAsyncEncryptionAvailable();
  if (!cofreDisponivel) return registrarErro('cofre', 'criptografia indisponível: o login não será lembrado');
  try { cifradas = JSON.parse(fs.readFileSync(arquivoSessoes(), 'utf8')); } catch { cifradas = {}; }
  let mudou = false;
  for (const [n, texto] of Object.entries(cifradas)) {
    try {
      const { result, shouldReEncrypt } = await safeStorage.decryptStringAsync(Buffer.from(texto, 'base64'));
      sessoes.set(Number(n), result);
      if (shouldReEncrypt) {
        cifradas[n] = (await safeStorage.encryptStringAsync(result)).toString('base64');
        mudou = true;
      }
    } catch (e) { registrarErro(`cofre conta ${n}`, e); }
  }
  if (mudou) gravarCofre();
}

function guardarSessao(n, sessao) {
  if (!cofreDisponivel || sessoes.get(n) === sessao) return filaCofre;
  try {
    const s = JSON.parse(sessao);
    if (!s?.nick || !s?.token) return filaCofre;
  } catch { return filaCofre; }
  sessoes.set(n, sessao);
  filaCofre = filaCofre.then(async () => {
    cifradas[n] = (await safeStorage.encryptStringAsync(sessao)).toString('base64');
    gravarCofre();
  }).catch((e) => registrarErro('cofre', e));
  return filaCofre;
}

function esquecerSessao(n) {
  sessoes.delete(n);
  filaCofre = filaCofre.then(() => {
    delete cifradas[n];
    gravarCofre();
  }).catch((e) => registrarErro('cofre', e));
  return filaCofre;
}

async function confirmarEsquecer(conta) {
  const { response } = await dialog.showMessageBox(ctx.janela, {
    type: 'question', title: 'Tick', buttons: ['Esquecer', 'Cancelar'], defaultId: 1, cancelId: 1,
    message: `Esquecer o login da ${nomeDe(conta)}?`, detail: 'A conta volta para a tela de login do jogo. Nada muda na sua conta.',
  });
  if (response !== 0) return;
  await esquecerSessao(conta.n);
  await conta.view.webContents.executeJavaScript(`localStorage.removeItem('sessao'); localStorage.removeItem('nick');`);
  conta.status = { ...conta.status, nick: undefined, nivel: undefined, ouro: undefined };
  recarregarConta(conta);
  registrar(`login: conta ${conta.n} esquecida`);
}

// A conta caiu na tela de login, mas há um login guardado: devolve e recarrega. O limite evita recarregar
// sem parar quando o login venceu de verdade; nesse caso, o jogo continua pedindo login.
function restaurarLogin(conta) {
  if (ctx.recepcao?.conta === conta || !sessoes.has(conta.n)) return;
  conta.restauracoes ??= 0;
  if (conta.restauracoes >= MAX_RESTAURAR) return;
  if (Date.now() - (conta.ultimaRestauracao ?? 0) < ESPERA_RESTAURAR_MS) return;
  conta.restauracoes++;
  conta.ultimaRestauracao = Date.now();
  anotar(`conta ${conta.n}: sem login na página, devolvendo o login guardado (${conta.restauracoes}/${MAX_RESTAURAR})`);
  recarregarConta(conta);
}

expor({ sessoes: () => sessoes, cofreDisponivel: () => cofreDisponivel });
module.exports = { arquivoSessoes, gravarCofre, abrirCofre, guardarSessao, esquecerSessao, confirmarEsquecer, restaurarLogin };
