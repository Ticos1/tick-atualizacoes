// Registro permanente do Tick (logs/tick.log) e gravação segura de arquivos.
const fs = require('node:fs');
const path = require('node:path');
const { usar } = require('./contexto');
const { DIAG, PASTA_DIAG, REGISTRO_MAX_BYTES } = require('./constantes');

const { dados } = usar('dados');

/** Grava em arquivo temporário e troca: uma queda no meio da gravação não corrompe o arquivo. */
function gravarSeguro(arquivo, conteudo) {
  fs.mkdirSync(path.dirname(arquivo), { recursive: true });
  fs.writeFileSync(`${arquivo}.tmp`, conteudo);
  fs.renameSync(`${arquivo}.tmp`, arquivo);
}

function registrar(txt) {
  if (!DIAG) return;
  fs.mkdirSync(PASTA_DIAG, { recursive: true });
  fs.appendFileSync(path.join(PASTA_DIAG, 'log.txt'), `${new Date().toISOString()} ${txt}\n`);
}

// ---------------------------------------------------------------- registro permanente
// Sempre ligado. Só guarda mensagens e, de URLs, origem e caminho: nunca sessão ou token.
const arquivoRegistro = () => dados('logs', 'tick.log');

function anotar(txt) {
  registrar(txt);
  try {
    fs.mkdirSync(path.dirname(arquivoRegistro()), { recursive: true });
    if (fs.existsSync(arquivoRegistro()) && fs.statSync(arquivoRegistro()).size > REGISTRO_MAX_BYTES) {
      fs.renameSync(arquivoRegistro(), `${arquivoRegistro()}.1`);
    }
    fs.appendFileSync(arquivoRegistro(), `${new Date().toISOString()} ${txt}\n`);
  } catch { /* sem registro, o app segue */ }
}

const registrarErro = (contexto, e) => anotar(`[erro] ${contexto}: ${e?.message ?? e}`);

function ultimosErros(quantos = 20) {
  try {
    return fs.readFileSync(arquivoRegistro(), 'utf8').trim().split('\n').filter((l) => l.includes('[erro]')).slice(-quantos).reverse();
  } catch { return []; }
}

module.exports = { gravarSeguro, registrar, arquivoRegistro, anotar, registrarErro, ultimosErros };
