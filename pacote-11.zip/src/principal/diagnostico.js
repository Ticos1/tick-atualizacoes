// Diagnóstico e testes do app (só com --diag e os --teste-*), em dados à parte.
const { safeStorage, session, app } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const logica = require('../logica');
const { ctx, usar } = require('./contexto');
const { PASTA_DIAG, MAX_CONTAS, TENTAR_DE_NOVO_MS, MAX_RESTAURAR } = require('./constantes');

const { naTelaDeErro, situacaoDe, registrar, ordenadas, abrirConta, definirModo, atualizarStatus, menuConta, menuScript, menuExtensoes, definirMudo, definirZoom, recarregarConta, fecharConta, definirExtensao, estaAtiva, gravarSeguro, arquivoSessoes, abrirCofre, guardarSessao, esquecerSessao, abrirConfig, memoriaPorConta, montarConfig, avisar, arquivoRegistro, mostrarJanela, anotar, definirModoJogo, menuLives, abrirLive, nomeDe } = usar('naTelaDeErro', 'situacaoDe', 'registrar', 'ordenadas', 'abrirConta', 'definirModo', 'atualizarStatus', 'menuConta', 'menuScript', 'menuExtensoes', 'definirMudo', 'definirZoom', 'recarregarConta', 'fecharConta', 'definirExtensao', 'estaAtiva', 'gravarSeguro', 'arquivoSessoes', 'abrirCofre', 'guardarSessao', 'esquecerSessao', 'abrirConfig', 'memoriaPorConta', 'montarConfig', 'avisar', 'arquivoRegistro', 'mostrarJanela', 'anotar', 'definirModoJogo', 'menuLives', 'abrirLive', 'nomeDe');

// ---------------------------------------------------------------- diagnóstico (só com --diag)
async function diagnosticar(conta) {
  if (!ctx.contas.includes(conta) || naTelaDeErro(conta.view.webContents)) return;
  try {
    const wc = conta.view.webContents;
    const pagina = await wc.executeJavaScript(`({
      url: location.origin + location.pathname,
      autoCompra: !!document.querySelector('#autocompra-painel'),
      huntElementos: document.querySelectorAll('[class*="pih"]').length,
      vazouPonte: '__tickGM' in window,
      temSessao: !!localStorage.getItem('sessao'),
    })`);
    fs.mkdirSync(PASTA_DIAG, { recursive: true });
    fs.writeFileSync(path.join(PASTA_DIAG, `conta-${conta.n}.json`), JSON.stringify({
      em: new Date().toISOString(), situacao: situacaoDe(conta), status: conta.status, pagina,
    }, null, 2));
    // Nunca fotografa páginas do Google: a tela de login mostra dados da pessoa.
    if (pagina.url.startsWith('https://pokeidle.io')) {
      fs.writeFileSync(path.join(PASTA_DIAG, `conta-${conta.n}.png`), (await wc.capturePage()).toPNG());
    }
  } catch (e) {
    registrar(`conta ${conta.n}: diagnóstico falhou: ${e.message}`);
  }
}

// Roda em dados à parte (--dados), com sessões falsas: nunca toca nas contas reais.
async function testarApp() {
  const espera = (ms) => new Promise((ok) => setTimeout(ok, ms));
  const log = (txt) => registrar(`teste ${txt}`);
  const foto = async (nome, vista) => {
    for (let t = 0; t < 4; t++) {
      try {
        fs.writeFileSync(path.join(PASTA_DIAG, nome), (await vista.webContents.capturePage()).toPNG());
        return;
      } catch { await espera(1_000); } // a captura falha enquanto a janela ainda está sendo desenhada
    }
    log(`foto ${nome}: não saiu`);
  };
  const areas = () => ordenadas().map((c) => { const b = c.view.getBounds(); return `c${c.n}=${c.view.getVisible() ? '' : 'oculta:'}${b.x},${b.y} ${b.width}x${b.height}`; }).join(' | ');
  const conta = (n) => ctx.contas.find((c) => c.n === n);
  while (ctx.contas.length < 4) await abrirConta();
  log(`abriu ${ctx.contas.length}; proxima=${logica.proximaConta(ctx.layout.slots, MAX_CONTAS)}`);
  await abrirConta();
  log(`pedir a 5ª: continua ${ctx.contas.length}`);
  await espera(9_000);
  log(`auto com 4: ${areas()}`);
  definirModo('colunas');
  log(`colunas: ${areas()}`);
  definirModo('2x2');
  log(`2x2: ${areas()}`);
  definirModo('auto');
  atualizarStatus(conta(1), { ws: 'conectada', temLogin: true, nick: 'Exemplo', nivel: 624, ouro: 76237 });
  log(`nome salvo: ${ctx.layout.nomes[1]}`);
  await espera(600);
  await foto('barra-grade.png', conta(1).barra);
  await foto('lateral-quatro.png', ctx.lateral);

  // Menus
  log(`menu conta: ${menuConta(conta(1)).items.map((i) => i.label).filter(Boolean).join(' | ')}`);
  log(`menu script: ${menuScript(conta(1)).items.length} itens`);
  log(`menu extensões: ${menuExtensoes(conta(1)).items.map((i) => i.label).filter(Boolean).join(' | ')}`);

  // Som
  definirMudo(conta(2), true);
  log(`mudo c2=${conta(2).view.webContents.isAudioMuted()} c1=${conta(1).view.webContents.isAudioMuted()}`);

  // Zoom: direto, depois de recarregar, por teclado e pela roda do mouse
  const z = conta(2).view.webContents;
  definirZoom(conta(2), 1.2);
  recarregarConta(conta(2));
  await espera(5_000);
  log(`zoom após recarga: c2=${z.getZoomFactor()} c1=${conta(1).view.webContents.getZoomFactor()}`);
  z.focus();
  z.sendInputEvent({ type: 'keyDown', keyCode: '-', modifiers: ['control'] });
  await espera(400);
  log(`zoom após Ctrl+-: ${ctx.layout.zooms[2]}`);
  z.sendInputEvent({ type: 'mouseWheel', x: 100, y: 100, deltaX: 0, deltaY: 120, wheelTicksY: 1, canScroll: true, modifiers: ['control'] });
  await espera(400);
  log(`zoom após Ctrl+roda: ${ctx.layout.zooms[2]} fator=${z.getZoomFactor()}`);
  definirZoom(conta(2), 1);

  // Atalhos
  z.sendInputEvent({ type: 'keyDown', keyCode: '1', modifiers: ['control'] });
  await espera(400);
  log(`Ctrl+1: focada=${ctx.focada?.n} ${areas()}`);
  await foto('barra-larga.png', conta(1).barra);
  conta(1).view.webContents.focus();
  conta(1).view.webContents.sendInputEvent({ type: 'keyDown', keyCode: '0', modifiers: ['control'] });
  await espera(400);
  log(`Ctrl+0: focada=${ctx.focada?.n ?? 'nenhuma'}`);

  // Sem internet: tela de erro, status e volta
  const c3 = conta(3);
  c3.view.webContents.loadURL('https://tick-sem-rede.invalid/').catch(() => {});
  await espera(4_000);
  log(`falha: url=${c3.view.webContents.getURL().split('/').pop()} situacao=${situacaoDe(c3)} tentar=${!!c3.timerRede}`);
  await foto('erro-sem-rede.png', c3.view);
  log(`barra diz: ${await c3.barra.webContents.executeJavaScript(`document.getElementById('situacao').textContent`)}`);
  await espera(TENTAR_DE_NOVO_MS + 4_000);
  log(`tentou sozinho: url=${logica.urlParaRegistro(c3.view.webContents.getURL())} situacao=${situacaoDe(c3)}`);

  // Página que quebra volta sozinha
  conta(2).view.webContents.forcefullyCrashRenderer();
  await espera(8_000);
  log(`após quebra: crashed=${conta(2).view.webContents.isCrashed()} url=${logica.urlParaRegistro(conta(2).view.webContents.getURL())} recargas=${conta(2).recargas?.length}`);

  // Desligar e religar
  fecharConta(c3);
  log(`desligada: abertas=${ctx.layout.abertas} slots=${ctx.layout.slots} ${areas()}`);
  await espera(500);
  await foto('lateral-desligada.png', ctx.lateral);
  await abrirConta(3);
  await espera(7_000);
  log(`religada: abertas=${ctx.layout.abertas} exts=${conta(3).ses.extensions.getAllExtensions().length} autoCompra=${await conta(3).view.webContents.executeJavaScript(`!!document.querySelector('#autocompra-painel')`)}`);

  // Extensão em conta desligada
  fecharConta(conta(3));
  await definirExtensao(3, 'auto-hunt', true);
  log(`desligada auto-hunt: auto=${estaAtiva(3, 'auto-hunt')} hunt=${estaAtiva(3, 'hunt')}`);
  await abrirConta(3);
  await espera(2_000);
  log(`religada exts: ${conta(3).ses.extensions.getAllExtensions().map((e) => e.name).join(' | ')}`);
  await definirExtensao(3, 'hunt', true);
  log(`hunt de volta: auto=${estaAtiva(3, 'auto-hunt')} hunt=${estaAtiva(3, 'hunt')}`);

  // Cofre: o que foi cifrado pelo jeito antigo precisa continuar sendo lido
  const falsa = JSON.stringify({ nick: 'copia-teste', token: 'falso' });
  gravarSeguro(arquivoSessoes(), JSON.stringify({ 1: safeStorage.encryptString(falsa).toString('base64') }));
  ctx.sessoes.clear();
  await abrirCofre();
  log(`cofre antigo lido: ${ctx.sessoes.get(1) === falsa}`);
  const nova = JSON.stringify({ nick: 'copia-nova', token: 'falso2' });
  await guardarSessao(2, nova);
  ctx.sessoes.clear();
  await abrirCofre();
  log(`cofre novo: lido=${ctx.sessoes.get(2) === nova} em claro=${fs.readFileSync(arquivoSessoes(), 'utf8').includes('copia-')}`);
  await conta(1).view.webContents.executeJavaScript(`localStorage.removeItem('sessao'); sessionStorage.removeItem('tick.restaurada');`);
  conta(1).restauracoes = MAX_RESTAURAR; // a sessão é falsa: só a devolução antes da carga interessa aqui
  recarregarConta(conta(1));
  await espera(5_000);
  log(`restaurada antes da carga: ${await conta(1).view.webContents.executeJavaScript(`sessionStorage.getItem('tick.restaurada')`)}`);
  await esquecerSessao(1);
  await esquecerSessao(2);
  log(`esquecida: ${!ctx.sessoes.has(1) && !JSON.parse(fs.readFileSync(arquivoSessoes(), 'utf8'))[1]}`);

  // Configurações
  abrirConfig();
  await espera(2_500);
  const texto = await ctx.janelaConfig.webContents.executeJavaScript(`document.body.innerText`);
  log(`config: ${texto.length} letras; memória=${JSON.stringify(memoriaPorConta())}; versões=${JSON.stringify(montarConfig().versoes)}; erros=${montarConfig().erros.length}`);
  await foto('config.png', ctx.janelaConfig);
  await ctx.janelaConfig.webContents.executeJavaScript(`window.scrollTo(0, document.body.scrollHeight)`);
  await espera(300);
  await foto('config-fim.png', ctx.janelaConfig);

  // Registro e aviso desligável
  ctx.layout.avisos.queda = false;
  avisar('queda', 'não deve aparecer', 'x');
  ctx.layout.avisos.queda = true;
  const registro = fs.readFileSync(arquivoRegistro(), 'utf8');
  log(`registro: tem erro=${registro.includes('[erro]')} tem token=${/falso|copia-/.test(registro)}`);
  ctx.janela.close();
  await espera(600);
  log(`X esconde: visivel=${ctx.janela.isVisible()} vivo=${!ctx.janela.isDestroyed()}`);
  mostrarJanela();
  registrar('teste: fim');
}

// Só com --dados temporário e sem login: confere modos, live e os módulos do jogo de que as ferramentas dependem.
async function testarRecursos() {
  const espera = (ms) => new Promise((ok) => setTimeout(ok, ms));
  const log = (t) => anotar(`teste ${t}`);
  await espera(9_000);
  const c = ordenadas()[0];
  const wc = c.view.webContents;
  const ler = () => wc.executeJavaScript(`({ economia: localStorage.getItem('cfg-economia'), ultra: localStorage.getItem('cfg-ultra'), classe: document.documentElement.classList.contains('modo-economia') })`);
  for (const m of ['economia', 'ultra', 'cena']) {
    await definirModoJogo(m);
    await espera(7_000);
    log(`modo ${m}: ${JSON.stringify(await ler())}`);
  }
  log(`módulos: ${JSON.stringify(await wc.executeJavaScript(`(async () => {
    const g = await import(location.origin + '/shared/ginasios.mjs');
    const t = await import(location.origin + '/shared/pvp-tabuleiro.mjs');
    const cr = await fetch(location.origin + '/assets/creatures.json').then((r) => r.json());
    const a = cr.creatures.find((x) => x.baseHp > 80 && x.baseAtk > x.baseSpAtk);
    const b = cr.creatures.find((x) => x.baseSpAtk > x.baseAtk + 60);
    const pk = (e) => ({ speciesId: e.pokeId, level: 500, ivs: { hp: 20, atk: 20, def: 20, spatk: 20, spdef: 20, speed: 20 }, qualidade: 1.2, quality: 1.2, potencia: 3 });
    const ma = g.metricasDeCombate(pk(a), a);
    const cmp = g.compararDuelo1v1(pk(a), a, pk(b), b, { amostras: 40 });
    return { temMetricas: !!ma, chaves: ma && Object.keys(ma), pctA: cmp?.pctA, alcances: [t.alcanceDaEspecie(a), t.alcanceDaEspecie(b)], casas: t.casasDaEquipe([null, null], [t.alcanceDaEspecie(a), t.alcanceDaEspecie(b)]) };
  })()`))}`);
  atualizarStatus(c, {
    ws: 'conectada', temLogin: true, nick: 'ContaTeste', nivel: 1234, ouro: 5678900,
    twitch: { vinculado: true, bonus: { xp: Date.now() + 90 * 60_000 }, canais: [{ id: 'exemplo', nome: 'Canal Exemplo', aoVivo: true, ativo: true, espectadores: 1500 }, { id: 'parado', nome: 'Parado', aoVivo: false, ativo: true, espectadores: 0 }] },
  });
  await espera(1_500);
  log(`menu lives: ${menuLives().items.map((i) => i.label).filter(Boolean).slice(0, 8).join(' | ')}`);
  fs.mkdirSync(PASTA_DIAG, { recursive: true });
  fs.writeFileSync(path.join(PASTA_DIAG, 'lateral.png'), (await ctx.lateral.webContents.capturePage()).toPNG());
  fs.writeFileSync(path.join(PASTA_DIAG, 'barra.png'), (await c.barra.webContents.capturePage()).toPNG());
  abrirConfig();
  await espera(2_500);
  for (let t = 0; t < 5; t++) {
    try {
      ctx.janelaConfig.show();
      fs.writeFileSync(path.join(PASTA_DIAG, 'config.png'), (await ctx.janelaConfig.webContents.capturePage()).toPNG());
      break;
    } catch { await espera(1_000); } // a captura falha enquanto a janela ainda está sendo desenhada
  }
  ctx.janelaConfig.close();
  abrirLive('twitch', 'twitch', 'Twitch');
  await espera(16_000);
  const lw = ctx.janelaLive.webContents;
  log(`live: url=${logica.urlParaRegistro(lw.getURL())} mudo=${lw.isAudioMuted()} partição=${lw.session === session.fromPartition('persist:lives')} ${JSON.stringify(await lw.executeJavaScript(`({ qualidade: localStorage.getItem('video-quality'), video: !!document.querySelector('video'), pausado: document.querySelector('video')?.paused ?? null })`))}`);
  ctx.janelaLive.close();
  registrar('teste: fim');
  anotar('teste: fim');
}

// Com as contas reais: só rola e dá zoom, restaura o zoom e sai. Não clica em nada nem envia nada ao jogo.
async function testarRolagem() {
  const espera = (ms) => new Promise((ok) => setTimeout(ok, ms));
  await espera(14_000);
  for (const c of ordenadas()) {
    const wc = c.view.webContents;
    const { width, height } = c.view.getBounds();
    const leitura = () => wc.executeJavaScript(`(() => {
      const p = document.querySelector('.eco-painel');
      return { economia: document.documentElement.classList.contains('modo-economia'), rola: p ? p.scrollHeight > p.clientHeight : null, topo: p?.scrollTop ?? null, zoomCena: document.getElementById('palco')?.dataset.zoom ?? null };
    })()`);
    const roda = (y, deltaY, modifiers = []) => wc.sendInputEvent({ type: 'mouseWheel', x: Math.floor(width / 2), y, deltaX: 0, deltaY, wheelTicksY: deltaY > 0 ? 1 : -1, canScroll: true, modifiers });
    const y = Math.floor(height * 0.72);
    const alvo = await wc.executeJavaScript(`document.elementFromPoint(${Math.floor(width / 2)}, ${y})?.closest('.eco-painel, #palco')?.className ?? 'fora do palco'`);
    const antes = await leitura();
    const zoomAntes = wc.getZoomFactor();
    wc.focus();
    roda(y, -240);
    await espera(700);
    const depoisRoda = await leitura();
    roda(y, 240);
    await espera(300);
    roda(y, 120, ['control']);
    await espera(500);
    const zoomDepois = wc.getZoomFactor();
    definirZoom(c, zoomAntes);
    anotar(`rolagem ${nomeDe(c)}: alvo=${alvo} ${JSON.stringify(antes)} -> ${JSON.stringify(depoisRoda)}; Ctrl+roda ${zoomAntes} -> ${zoomDepois}`);
    await espera(400);
    const f = path.join(PASTA_DIAG, `rolagem-${c.n}.png`);
    fs.mkdirSync(PASTA_DIAG, { recursive: true });
    try { fs.writeFileSync(f, (await wc.capturePage()).toPNG()); } catch { /* foto é só para conferir */ }
  }
  for (const c of ctx.contas) c.ses.flushStorageData();
  await espera(800);
  app.quit();
}

module.exports = { diagnosticar, testarApp, testarRecursos, testarRolagem };
