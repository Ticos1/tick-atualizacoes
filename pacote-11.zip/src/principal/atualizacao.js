// Atualização da edição para amigos: procurar, avisar e mostrar as novidades.
const { app, ipcMain, BrowserWindow } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const atualizador = require('../atualizador');
const { ctx, usar } = require('./contexto');
const { ICONE, PASTA_SRC, EDICAO_AMIGO } = require('./constantes');

const { anotar, avisar, registrarErro } = usar('anotar', 'avisar', 'registrarErro');

// ---------------------------------------------------------------- atualização (só na edição para amigos)
// Cada commit vira uma edição: procurar de 15 em 15 minutos faz a versão nova chegar no mesmo dia.
const INTERVALO_ATUALIZACAO_MS = 15 * 60_000;
// Quem clicou em "Depois" é lembrado de novo, no máximo uma vez por hora.
const LEMBRAR_REINICIO_MS = 60 * 60_000;
let reinicioPedidoEm = 0;

/** A edição já baixada que espera o Tick abrir de novo, ou 0. Uma marcada como ruim não conta: ela não abriria. */
function edicaoEsperandoReinicio() {
  const raiz = path.join(app.getPath('userData'), 'atualizacao');
  const versao = atualizador.versaoDe(path.join(raiz, 'atual'));
  let ruins = [];
  try { ruins = JSON.parse(fs.readFileSync(path.join(raiz, 'ruins.json'), 'utf8')); } catch { /* nenhuma ruim */ }
  return versao > ctx.VERSAO_AMIGO && !ruins.includes(versao) ? versao : 0;
}

async function procurarAtualizacao() {
  try {
    const nova = await atualizador.conferir({ dados: app.getPath('userData'), versaoEmUso: ctx.VERSAO_AMIGO });
    if (nova) {
      anotar(`atualização: edição ${nova.versao} instalada`);
      // O script é lido a cada carga: já vale ao recarregar a conta. O resto vale ao reabrir o Tick.
      ctx.USERSCRIPT = path.join(nova.pasta, 'vendor', 'pokeidle-autocompra.user.js');
      avisar('sistema', 'Tick atualizado', 'Reinicie o Tick para usar a versão nova e ver as novidades.');
      pedirReinicio(nova.versao);
      return;
    }
  } catch (e) {
    registrarErro('atualização', e);
  }
  const esperando = edicaoEsperandoReinicio();
  if (esperando && Date.now() - reinicioPedidoEm >= LEMBRAR_REINICIO_MS) {
    anotar(`atualização: lembrando de reiniciar para a edição ${esperando}`);
    pedirReinicio(esperando);
  }
}

let telaReinicio = null;
ipcMain.on('tick:reiniciar', () => {
  app.relaunch();
  app.quit();
});

/** Versão nova instalada: ela só vale ao abrir de novo, e a tela de novidades aparece nessa hora. */
function pedirReinicio(versao) {
  reinicioPedidoEm = Date.now();
  if (telaReinicio && !telaReinicio.isDestroyed()) telaReinicio.close();
  const largura = 460;
  const altura = 230;
  const area = ctx.janela.getBounds();
  const tela = new BrowserWindow({
    parent: ctx.janela, width: largura, height: altura,
    x: Math.round(area.x + (area.width - largura) / 2), y: Math.round(area.y + (area.height - altura) / 2),
    frame: false, resizable: false, minimizable: false, maximizable: false, skipTaskbar: true, show: false,
    title: 'Tick atualizado', icon: ICONE, backgroundColor: '#171a2b',
    webPreferences: { preload: path.join(PASTA_SRC, 'preload-ui.js') },
  });
  telaReinicio = tela;
  tela.once('ready-to-show', () => { tela.show(); tela.focus(); });
  tela.loadFile(path.join(PASTA_SRC, 'atualizado.html'), { query: { versao: String(versao) } }).catch((e) => registrarErro('aviso de atualização', e));
}

let textoNovidades = '';
ipcMain.handle('tick:novidades', () => ({ versao: ctx.VERSAO_AMIGO, texto: textoNovidades }));

/** Na primeira abertura e a cada versão nova, uma vez: a tela do Tick com o texto da última atualização. */
function mostrarNovidades() {
  const dados = app.getPath('userData');
  textoNovidades = atualizador.novidadesParaMostrar(dados, path.join(PASTA_SRC, '..'), ctx.VERSAO_AMIGO) ?? '';
  if (!textoNovidades) return;
  anotar(`novidades mostradas: edição ${ctx.VERSAO_AMIGO}`);
  const largura = 520;
  const altura = 440;
  const area = ctx.janela.getBounds();
  const tela = new BrowserWindow({
    parent: ctx.janela, width: largura, height: altura,
    x: Math.round(area.x + (area.width - largura) / 2), y: Math.round(area.y + (area.height - altura) / 2),
    frame: false, resizable: false, minimizable: false, maximizable: false, skipTaskbar: true, show: false,
    title: 'Novidades do Tick', icon: ICONE, backgroundColor: '#171a2b',
    webPreferences: { preload: path.join(PASTA_SRC, 'preload-ui.js') },
  });
  tela.once('ready-to-show', () => { tela.show(); tela.focus(); });
  tela.loadFile(path.join(PASTA_SRC, 'novidades.html')).catch((e) => registrarErro('novidades', e));
}

function iniciarAtualizacao() {
  if (!EDICAO_AMIGO) return;
  mostrarNovidades();
  atualizador.confirmar(app.getPath('userData'), ctx.VERSAO_AMIGO);
  setTimeout(procurarAtualizacao, 30_000);
  setInterval(procurarAtualizacao, INTERVALO_ATUALIZACAO_MS);
}

module.exports = { edicaoEsperandoReinicio, procurarAtualizacao, pedirReinicio, mostrarNovidades, iniciarAtualizacao };
