// @ts-check
// Regras puras do Tick, sem Electron, para poderem ser testadas com `npm test`.
const ZOOM_MIN = 0.5;
const ZOOM_MAX = 2;

/** Os números das contas, na ordem escolhida. Quem não está na ordem vai para o fim, pelo número. */
function ordenar(ns, ordem = []) {
  const pos = (n) => { const i = ordem.indexOf(n); return i < 0 ? 100 + n : i; };
  return [...ns].sort((a, b) => pos(a) - pos(b));
}

/** Arrastando para a direita, a conta cai depois do alvo; para a esquerda, antes. */
function mover(ns, n, alvo) {
  if (n === alvo || !ns.includes(n) || !ns.includes(alvo)) return [...ns];
  const resto = ns.filter((x) => x !== n);
  const i = resto.indexOf(alvo);
  resto.splice(ns.indexOf(n) < ns.indexOf(alvo) ? i + 1 : i, 0, n);
  return resto;
}

/** Colunas lado a lado. A última fica com a sobra do arredondamento, para não deixar fresta. */
function colunas(ns, pesos, inicio, fim) {
  const peso = (n) => pesos[n] ?? 1;
  const soma = ns.reduce((t, n) => t + peso(n), 0);
  let x = inicio;
  return ns.map((n, i) => {
    const largura = i === ns.length - 1 ? fim - x : Math.floor((fim - inicio) * peso(n) / soma);
    const coluna = { n, x, largura };
    x += largura;
    return coluna;
  });
}

/** "auto" usa colunas até 3 contas e 2×2 com 4. */
function usaDuasLinhas(modo, quantas) {
  if (quantas < 3) return false;
  return modo === '2x2' || (modo === 'auto' && quantas >= 4);
}

/** A área de cada conta. Em duas linhas, a primeira recebe a conta a mais quando o número é ímpar. */
function retangulos(ns, modo, pesos, inicio, fim, altura) {
  if (!usaDuasLinhas(modo, ns.length)) {
    return colunas(ns, pesos, inicio, fim).map((c) => ({ ...c, y: 0, altura }));
  }
  const corte = Math.ceil(ns.length / 2);
  const alturaCima = Math.floor(altura / 2);
  return [
    ...colunas(ns.slice(0, corte), pesos, inicio, fim).map((c) => ({ ...c, y: 0, altura: alturaCima })),
    ...colunas(ns.slice(corte), pesos, inicio, fim).map((c) => ({ ...c, y: alturaCima, altura: altura - alturaCima })),
  ];
}

function limitarZoom(z) {
  const numero = Number(z);
  if (!Number.isFinite(numero)) return 1;
  return Math.round(Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, numero)) * 100) / 100;
}

/** 1234 vira "1,2 mil", para caber em um menu. */
function numeroCurto(n) {
  const v = Number(n) || 0;
  return v >= 1000 ? `${(v / 1000).toFixed(1).replace('.', ',')} mil` : String(v);
}

/** Só http e https saem para o navegador: outros esquemas, como file: e ms-*, poderiam abrir programas do PC. */
function urlExternaSegura(url) {
  try {
    const { protocol } = new URL(url);
    return protocol === 'https:' || protocol === 'http:';
  } catch { return false; }
}

/** O login só entra pelo endereço local: outro Host indica um site apontando o próprio nome para este PC. */
const hostDeLoginValido = (host, porta) => host === `127.0.0.1:${porta}`;

/** O layout salvo, com os campos novos e migrado do antigo `contas.json` ({ abertas: 3 }). */
function normalizarLayout(salvo, abertasAntigas, maxContas) {
  const layout = {
    ordem: [], pesos: {}, apelidos: {}, nomes: {}, zooms: {}, mudas: {}, janela: null, avisouBandeja: false, xSai: false, modo: 'auto',
    ...salvo,
  };
  layout.avisos = { queda: true, nocaute: true, outro: true, ...salvo?.avisos };
  const validos = (lista) => [...new Set((lista ?? []).filter((n) => Number.isInteger(n) && n >= 1 && n <= maxContas))];
  if (Array.isArray(salvo?.abertas)) {
    layout.abertas = validos(salvo.abertas);
  } else {
    const k = Math.min(maxContas, Math.max(1, Number(abertasAntigas) || 1));
    layout.abertas = Array.from({ length: k }, (_, i) => i + 1);
  }
  layout.slots = validos([...(salvo?.slots ?? []), ...layout.abertas]);
  return layout;
}

/** A próxima conta para o botão "+": uma nunca usada. */
function proximaConta(slots, maxContas) {
  for (let n = 1; n <= maxContas; n++) if (!slots.includes(n)) return n;
  return null;
}

/** Compara versões como "1.0.9" e "1.0.13", número a número. Positivo: `a` é mais nova. */
function compararVersoes(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

/** Erro 5xx do jogo (Cloudflare 520/523 com o servidor fora): a página "abre", mas sem jogo. */
function servidorFora(url, codigo) {
  try { return new URL(url).hostname === 'pokeidle.io' && codigo >= 500; } catch { return false; }
}

/** Sessão e token nunca vão para o registro: de uma URL, só origem e caminho. */
function urlParaRegistro(url) {
  try { const u = new URL(url); return u.origin + u.pathname; } catch { return 'url inválida'; }
}

module.exports = { ZOOM_MIN, ZOOM_MAX, ordenar, mover, colunas, usaDuasLinhas, retangulos, limitarZoom, normalizarLayout, proximaConta, urlParaRegistro, numeroCurto, urlExternaSegura, hostDeLoginValido, servidorFora, compararVersoes };
