// A janela "Triar Depot": calcula na conta escolhida, mostra quem vai para a Coleção e quem seria vendido, e só
// age no "Confirmar". Quem é desmarcado na lista de venda fica no Depot.
const $ = (id) => document.getElementById(id);
const nota = (v) => (v == null ? '—' : String(Math.round(v * 100) / 100).replace('.', ','));
const semPrefixo = (e) => String(e?.message ?? e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');

let previa = null;   // a última prévia calculada, com o token que a confirmação precisa
let contaDaPrevia = null;
let acompanhando = null;

function cartao(rotulo, valor, cls = '') {
  const el = document.createElement('div');
  el.className = `cartao ${cls}`;
  const s = document.createElement('small');
  s.textContent = rotulo;
  const b = document.createElement('b');
  b.textContent = valor;
  el.append(s, b);
  return el;
}

/** Uma linha: marcador (ou caixa de venda), nome com nível e motivo, e a nota. */
function linha(p, comCaixa) {
  const li = document.createElement('li');
  li.classList.toggle('shiny', p.shiny);
  li.dataset.id = String(p.id);
  let marca;
  if (comCaixa) {
    marca = document.createElement('input');
    marca.type = 'checkbox';
    marca.checked = true;
    marca.title = 'Desmarque para manter no Depot';
    marca.addEventListener('change', () => { li.classList.toggle('fora', !marca.checked); pintarRodape(); });
  } else {
    marca = document.createElement('span');
    marca.className = 'selo';
    marca.textContent = p.shiny ? '✨' : '★';
  }
  const nome = document.createElement('div');
  nome.className = 'nome';
  const b = document.createElement('b');
  b.textContent = p.nome;
  const s = document.createElement('small');
  s.textContent = [p.nivel ? `Nv ${p.nivel}` : '', p.porque].filter(Boolean).join(' · ');
  nome.append(b, s);
  const n = document.createElement('div');
  n.className = 'nota';
  n.textContent = p.shiny ? 'shiny' : `N ${nota(p.nota)}`;
  if (p.evolucao) {
    const e = document.createElement('small');
    e.textContent = `${p.evolucao.nome}: ${nota(p.evolucao.nota)}`;
    n.append(e);
  }
  li.append(marca, nome, n);
  return li;
}

const manterIds = () => [...$('lista-vender').querySelectorAll('li')]
  .filter((li) => !li.querySelector('input').checked).map((li) => Number(li.dataset.id));

function pintarRodape() {
  if (!previa) return;
  const vender = previa.vender.length - manterIds().length;
  const guardar = previa.guardar.length;
  $('n-vender').textContent = vender === previa.vender.length ? String(vender) : `${vender} de ${previa.vender.length}`;
  $('confirmar').textContent = `Confirmar: guardar ${guardar} e vender ${vender}`;
  $('confirmar').disabled = guardar + vender === 0;
  $('rodape-texto').textContent = vender ? 'A venda não tem como desfazer.' : 'Só guarda na Coleção.';
}

function pintarPrevia(p) {
  previa = p;
  $('resumo').replaceChildren(
    cartao('Vão para a Coleção', String(p.guardar.length), 'guardar'),
    cartao('Serão vendidos', String(p.vender.length), 'vender'),
    cartao('Ficam no Depot (sem nota)', String(p.pulados)),
    cartao('Corte da nota', `${nota(p.corte)}+`),
  );
  $('resumo').hidden = false;
  $('n-guardar').textContent = String(p.guardar.length);
  $('lista-guardar').replaceChildren(...p.guardar.map((x) => linha(x, false)));
  $('lista-vender').replaceChildren(...p.vender.map((x) => linha(x, true)));
  $('n-manter').textContent = String(p.manter.length);
  $('lista-manter').replaceChildren(...p.manter.map((x) => linha(x, false)));
  $('manter').hidden = !p.manter.length;
  const nada = !p.guardar.length && !p.vender.length;
  $('listas').hidden = nada;
  $('status').className = 'fraco';
  $('status').textContent = nada
    ? 'Nada a fazer: o Depot já está em dia.'
    : 'Confira as listas. Nada foi feito ainda: o Tick espera o seu "Confirmar".';
  $('rodape').hidden = nada;
  $('confirmar').hidden = false;
  $('cancelar').hidden = false;
  $('parar').hidden = true;
  pintarRodape();
}

async function calcular() {
  const n = Number($('conta').value);
  if (!n) return;
  clearInterval(acompanhando);
  previa = null;
  contaDaPrevia = n;
  $('calcular').disabled = true;
  $('listas').hidden = true;
  $('resumo').hidden = true;
  $('manter').hidden = true;
  $('rodape').hidden = true;
  $('andamento').hidden = true;
  $('status').className = 'fraco';
  $('status').textContent = 'Calculando a nota de cada pokemon do Depot…';
  try {
    pintarPrevia(await window.tick.depotPrevia(n));
  } catch (e) {
    $('status').className = 'erro';
    $('status').textContent = `Não deu: ${semPrefixo(e)}.`;
  } finally {
    $('calcular').disabled = false;
  }
}

function pintarAndamento(s) {
  const pct = s.total ? Math.round((s.feitos / s.total) * 100) : 0;
  $('barra').style.width = `${pct}%`;
  const falhas = s.falhas ? `, ${s.falhas} falharam (${(s.motivos ?? []).join(', ')})` : '';
  $('andamento-texto').textContent = s.fim
    ? `${s.parado ? 'Parado' : 'Terminou'}: ${s.guardou} na Coleção, ${s.vendeu} vendidos${falhas}.`
    : `Triando ${s.feitos ?? 0} de ${s.total}: ${s.guardou ?? 0} na Coleção, ${s.vendeu ?? 0} vendidos${falhas}…`;
}

async function confirmar() {
  if (!previa) return;
  $('confirmar').disabled = true;
  $('cancelar').hidden = true;
  $('calcular').disabled = true;
  $('conta').disabled = true;
  for (const i of document.querySelectorAll('#lista-vender input')) i.disabled = true;
  try {
    await window.tick.depotConfirmar(contaDaPrevia, previa.token, manterIds());
  } catch (e) {
    $('status').className = 'erro';
    $('status').textContent = `Não deu: ${semPrefixo(e)}.`;
    $('calcular').disabled = false;
    $('conta').disabled = false;
    return;
  }
  $('confirmar').hidden = true;
  $('parar').hidden = false;
  $('andamento').hidden = false;
  $('status').textContent = 'Triando. Pode fechar esta janela: a conta continua até o fim.';
  acompanhando = setInterval(async () => {
    let s;
    try { s = await window.tick.depotSituacao(contaDaPrevia); } catch { return; }
    pintarAndamento(s);
    if (s.fim || !s.rodando) {
      clearInterval(acompanhando);
      $('parar').hidden = true;
      $('rodape').hidden = true;
      $('calcular').disabled = false;
      $('conta').disabled = false;
      $('status').textContent = 'Pronto. Clique em "Calcular de novo" para conferir o Depot.';
    }
  }, 1000);
}

async function carregarContas() {
  const lista = await window.tick.depotContas();
  const antes = $('conta').value || new URLSearchParams(location.search).get('n');
  $('conta').replaceChildren(...lista.map((c) => {
    const o = document.createElement('option');
    o.value = String(c.n);
    o.textContent = c.nome;
    return o;
  }));
  if (lista.some((c) => String(c.n) === antes)) $('conta').value = antes;
  $('calcular').disabled = !lista.length;
  if (!lista.length) {
    $('status').className = 'fraco';
    $('status').textContent = 'Nenhuma conta conectada agora.';
  }
  return lista.length > 0;
}

$('calcular').addEventListener('click', calcular);
$('conta').addEventListener('change', calcular);
$('confirmar').addEventListener('click', confirmar);
$('cancelar').addEventListener('click', () => window.close());
$('parar').addEventListener('click', async () => {
  $('parar').disabled = true;
  try { await window.tick.depotParar(contaDaPrevia); } catch { /* a próxima leitura mostra */ }
});
$('marcar-todos').addEventListener('click', () => {
  for (const i of document.querySelectorAll('#lista-vender input')) { i.checked = true; i.closest('li').classList.remove('fora'); }
  pintarRodape();
});
$('desmarcar-todos').addEventListener('click', () => {
  for (const i of document.querySelectorAll('#lista-vender input')) { i.checked = false; i.closest('li').classList.add('fora'); }
  pintarRodape();
});

// Abre já calculando: a pessoa vê a prévia sem precisar clicar.
carregarContas().then((tem) => { if (tem) calcular(); });
