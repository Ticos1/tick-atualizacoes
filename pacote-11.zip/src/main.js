// Tick — contas isoladas do PokeIdle, lado a lado, com as extensões integradas.
const { app, BaseWindow, WebContentsView, Menu, Notification, Tray, crashReporter, dialog, ipcMain, nativeImage, screen, session, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const logica = require('./logica');
const atualizador = require('./atualizador');
const { lerScript } = require('./script-partes');
// O que os módulos de src/principal compartilham com este arquivo: funções e o estado que muda.
const { ctx, expor, conferir: conferirContexto } = require('./principal/contexto');

const {
  URL_JOGO, SCRIPT_TRABALHO, SCRIPT_JUNTO, ASSISTENTE, ICONE, ID_SCRIPT, ID_ROTOM, MAX_CONTAS, ALTURA_BARRA, LARGURA_LATERAL,
  QUEDA_AVISO_MS, NOCAUTE_INTERVALO_MS, TENTAR_DE_NOVO_MS, TRAVADA_MS, LIMITE_RECARGAS, JANELA_RECARGAS_MS, GRAVAR_DADOS_MS,
  PASSO_ZOOM, CSS_ECONOMIA, LARGURAS, MODOS, DIAG, TESTE_APP, dadosTeste, EDICAO_AMIGO,
} = require('./principal/constantes');
let USERSCRIPT = fs.existsSync(SCRIPT_TRABALHO) ? SCRIPT_TRABALHO : SCRIPT_JUNTO;
const pastaDados = () => {
  if (EDICAO_AMIGO) return path.join(process.env.LOCALAPPDATA ?? app.getPath('appData'), 'Tick');
  return app.isPackaged
    ? path.resolve(path.dirname(process.execPath), '..', '..', 'dados')
    : path.join(__dirname, '..', 'dados');
};
app.setPath('userData', dadosTeste ? dadosTeste.slice('--dados='.length) : pastaDados());
// Arquivo de queda só neste PC, junto dos dados, para descobrir por que o Tick fechou. Nada é enviado.
app.setPath('crashDumps', path.join(app.getPath('userData'), 'Crashpad'));
crashReporter.start({ uploadToServer: false, compress: true });

// Sem o "Electron/x" e o "Tick/x" no fim: o app se apresenta como o Chromium que ele é.
app.userAgentFallback = app.userAgentFallback.replace(/\s(Electron|tick|Tick)\/\S+/g, '');
app.setAppUserModelId('Tick');

/** Mostra o motivo e fecha. A caixa só fica na tela depois de o app estar pronto: antes disso, ela some na hora. */
function avisarEFechar(titulo, texto) {
  app.whenReady().then(() => {
    dialog.showMessageBoxSync({ type: 'error', title: 'Tick', message: titulo, detail: texto, buttons: ['OK'] });
    app.exit(1);
  });
}

// Sem a pasta de dados, a trava abaixo falha e o app fecharia calado, como se o clique não tivesse feito nada.
let semPastaDeDados = false;
try {
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
} catch (e) {
  semPastaDeDados = true;
  avisarEFechar('O Tick não conseguiu abrir', `Não consegui criar a pasta de dados:\n${app.getPath('userData')}\n\n${e.message}`);
}

// Um segundo clique só traz a janela para a frente. Mas, se o Tick aberto não responder, ele está travado ou
// invisível: em vez de fechar calado, diz o que fazer.
const marcaResposta = path.join(app.getPath('userData'), 'tick.respondeu');
const segundoClique = semPastaDeDados || !app.requestSingleInstanceLock();
if (segundoClique && !semPastaDeDados) {
  const inicio = Date.now();
  const respondeu = () => { try { return fs.statSync(marcaResposta).mtimeMs >= inicio - 2_000; } catch { return false; } };
  const conferir = () => {
    if (respondeu()) return app.exit(0);
    if (Date.now() - inicio < 5_000) return setTimeout(conferir, 250);
    return avisarEFechar('O Tick já está aberto, mas não responde', 'Abra o Gerenciador de Tarefas (Ctrl + Shift + Esc), finalize todos os itens "Tick" e abra de novo.');
  };
  conferir();
}
app.on('second-instance', () => {
  try { fs.writeFileSync(marcaResposta, ''); } catch { /* sem a marca, o segundo clique só avisa */ }
  if (janela) mostrarJanela();
});

let janela, lateral;
let focada = null;  // a conta que ocupa a janela sozinha (null = grade)
let cheia = false;  // a janela em tela cheia, sempre com uma conta focada
const contas = [];  // as contas ligadas: { n, ses, view, barra, extIds, menu, cockpit, status, ... }
const abrindo = new Set();

const dados = (...partes) => path.join(app.getPath('userData'), ...partes);
ctx.dados = dados; // o registro precisa dela já na primeira anotação

// Os módulos do processo principal (src/principal). Cada um põe no contexto o que os outros usam.
for (const nome of ['registro', 'vigia', 'extensoes', 'atualizacao', 'cofre', 'paineis', 'login-navegador', 'lives', 'configuracoes', 'diagnostico']) {
  Object.assign(ctx, require(`./principal/${nome}`));
}
const {
  gravarSeguro, registrar, anotar, registrarErro, arquivoRegistro, iniciarVigia, iniciarDiagnosticoDeQuedas, apagarMarcaVigia,
  catalogo, estaAtiva, carregarExtensao, definirExtensao, marcarNoMenu, escolherExtensao, baixarExtensoesDaLoja,
  iniciarAtualizacaoDeExtensoes, iniciarAtualizacao, abrirCofre, guardarSessao, confirmarEsquecer, restaurarLogin,
  abrirMeta, escolherContaMeta, marcarColetorDoMeta, triarDepot, receberLogin, pararRecepcao, menuLives, abrirCockpit,
  abrirConfig, abrirHunts, diagnosticar, testarApp, testarRecursos, testarRolagem,
} = ctx;

let janelaAberta = false;

/** Sem janela, um erro deixaria o app invisível: mostra o motivo e fecha, para o próximo clique funcionar. */
function falhaAoAbrir(e) {
  if (janelaAberta) return;
  avisarEFechar('O Tick não conseguiu abrir', `${e?.message ?? e}\n\nRegistro: ${arquivoRegistro()}`);
}

process.on('uncaughtException', (e) => { anotar(`[erro] processo: ${e?.stack ?? e}`); falhaAoAbrir(e); });
process.on('unhandledRejection', (e) => { anotar(`[erro] promessa: ${e?.stack ?? e}`); falhaAoAbrir(e); });
const VERSAO_AMIGO = EDICAO_AMIGO ? atualizador.versaoDe(path.join(__dirname, '..')) : 0;
if (!segundoClique) anotar(`abrindo: Tick ${app.getVersion()}${EDICAO_AMIGO ? `, edição ${VERSAO_AMIGO}` : ''}, Windows ${process.getSystemVersion()}`);

// ---------------------------------------------------------------- layout lembrado
const arquivoLayout = () => dados('layout.json');
let layout = logica.normalizarLayout(null, undefined, MAX_CONTAS);

function lerLayout() {
  let salvo = null;
  let antigas;
  try { salvo = JSON.parse(fs.readFileSync(arquivoLayout(), 'utf8')); } catch { /* primeira vez */ }
  try { antigas = JSON.parse(fs.readFileSync(dados('contas.json'), 'utf8')).abertas; } catch { /* já migrado */ }
  layout = logica.normalizarLayout(salvo, antigas, MAX_CONTAS);
}
const salvarLayout = () => gravarSeguro(arquivoLayout(), JSON.stringify(layout, null, 2));

const contaDoJogo = (wc) => contas.find((c) => c.view.webContents === wc);
const nomeDoNumero = (n) => layout.apelidos[n] ?? contas.find((c) => c.n === n)?.status.nick ?? layout.nomes[n] ?? `Conta ${n}`;
const nomeDe = (c) => nomeDoNumero(c.n);
const ordenadas = () => logica.ordenar(contas.map((c) => c.n), layout.ordem).map((n) => contas.find((c) => c.n === n));

function moverConta(n, alvo) {
  layout.ordem = logica.mover(logica.ordenar(layout.slots, layout.ordem), n, alvo);
  salvarLayout();
  dispor();
  publicar();
}

function definirPeso(conta, peso) {
  layout.pesos[conta.n] = peso;
  salvarLayout();
  dispor();
}

function definirModo(modo) {
  if (!MODOS.some(([m]) => m === modo)) return;
  layout.modo = modo;
  salvarLayout();
  dispor();
}

function definirApelido(n, texto) {
  const apelido = String(texto ?? '').trim().slice(0, 24);
  if (apelido) layout.apelidos[n] = apelido;
  else delete layout.apelidos[n]; // vazio volta para o nick do jogo
  salvarLayout();
  publicar();
}

const zoomDe = (n) => layout.zooms[n] ?? 1;

function definirZoom(conta, z) {
  const zoom = logica.limitarZoom(z);
  layout.zooms[conta.n] = zoom;
  salvarLayout();
  conta.view.webContents.setZoomFactor(zoom);
  publicar();
}

function definirMudo(conta, mudo) {
  layout.mudas[conta.n] = mudo;
  salvarLayout();
  conta.view.webContents.setAudioMuted(mudo);
  publicar();
}

let guardaJanela;
function guardarJanela() {
  clearTimeout(guardaJanela);
  guardaJanela = setTimeout(() => {
    if (!janela || janela.isDestroyed() || janela.isFullScreen() || janela.isMinimized()) return;
    layout.janela = { limites: janela.getNormalBounds(), maximizada: janela.isMaximized() };
    salvarLayout();
  }, 500);
}

/** A posição salva, se ela ainda cabe em alguma tela (o monitor pode ter sido desconectado). */
function limitesSalvos() {
  const l = layout.janela?.limites;
  if (!l) return { width: 1320, height: 860 };
  const visivel = screen.getAllDisplays().some(({ workArea: a }) => l.x < a.x + a.width - 80 && l.x + l.width > a.x + 80 && l.y >= a.y - 20 && l.y < a.y + a.height - 80);
  return visivel ? l : { width: l.width, height: l.height };
}

// ---------------------------------------------------------------- bandeja e abertura com o Windows
let bandeja;
let saindo = false;
app.on('before-quit', () => { saindo = true; });

function mostrarJanela() {
  if (janela.isMinimized()) janela.restore();
  janela.show();
  janela.focus();
}

const opcoesInicio = () => ({ path: process.execPath, args: app.isPackaged ? [] : [app.getAppPath()] });
const comWindows = () => app.getLoginItemSettings(opcoesInicio()).openAtLogin;

function definirComWindows(sim) {
  app.setLoginItemSettings({ ...opcoesInicio(), openAtLogin: sim });
  pintarBandeja();
}

function pintarBandeja() {
  bandeja.setContextMenu(Menu.buildFromTemplate([
    { label: 'Abrir o Tick', click: mostrarJanela },
    { label: 'Configurações', click: abrirConfig },
    { label: 'Abrir com o Windows', type: 'checkbox', checked: comWindows(), click: (i) => definirComWindows(i.checked) },
    { type: 'separator' },
    { label: 'Sair do Tick', click: () => app.quit() },
  ]));
}

function montarBandeja() {
  bandeja = new Tray(nativeImage.createFromPath(path.join(__dirname, '..', 'assets', 'tick.png')).resize({ width: 16, height: 16 }));
  bandeja.setToolTip('Tick');
  pintarBandeja();
  bandeja.on('click', mostrarJanela);
}

// ---------------------------------------------------------------- estado mostrado na interface
function situacaoDe(c) {
  if (ctx.recepcao?.conta === c) return 'esperando';
  if (c.status.ws === 'conectada') return 'conectada';
  if (c.status.ws === 'outro') return 'outro';
  if (c.status.ws === 'semrede') return 'semrede';
  if (!c.status.temLogin) return 'semlogin';
  return c.status.ws === 'caiu' ? 'caiu' : 'carregando';
}

function publicar() {
  const estado = {
    contas: logica.ordenar(layout.slots, layout.ordem).map((n) => {
      const c = contas.find((x) => x.n === n);
      const base = { n, nome: nomeDoNumero(n), apelido: layout.apelidos[n] ?? null };
      if (!c) return { ...base, ligada: false, situacao: 'desligada' };
      return {
        ...base, ligada: true, nivel: c.status.nivel ?? null, ouro: c.status.ouro ?? null,
        situacao: situacaoDe(c), desde: c.desde ?? null, mudo: !!layout.mudas[n], shiny: c.status.shiny ?? null,
      };
    }),
    focada: focada?.n ?? null,
    cheia,
    podeAbrir: logica.proximaConta(layout.slots, MAX_CONTAS) != null,
    modoJogo: layout.modoJogo ?? 'cena',
    liveAberta: !!ctx.janelaLive && !ctx.janelaLive.isDestroyed(),
  };
  if (lateral && !lateral.webContents.isDestroyed()) lateral.webContents.send('tick:estado', estado);
  for (const c of contas) c.barra.webContents.send('tick:estado', estado);
  if (ctx.janelaConfig && !ctx.janelaConfig.isDestroyed()) ctx.janelaConfig.webContents.send('tick:estado', estado);
  if (ctx.janelaHunts && !ctx.janelaHunts.isDestroyed()) ctx.janelaHunts.webContents.send('tick:estado', estado);
}

ipcMain.on('tick:pedir-estado', publicar);

ipcMain.on('tick:acao', (ev, tipo, n, valor) => {
  const conta = contas.find((c) => c.n === n);
  if (tipo === 'abrir-conta') return abrirConta();
  if (tipo === 'ligar') return abrirConta(n);
  if (tipo === 'grade') return mostrar(null);
  if (tipo === 'config') return abrirConfig();
  if (tipo === 'modos') return menuModos().popup({ window: janela });
  if (tipo === 'lives') return menuLives().popup({ window: janela });
  if (tipo === 'meta') return abrirMeta();
  if (tipo === 'meta-conta') return escolherContaMeta();
  if (tipo === 'hunts') return abrirHunts();
  if (tipo === 'depot') return triarDepot();
  if (tipo === 'ferramentas') return menuFerramentas().popup({ window: janela });
  if (tipo === 'mover') return moverConta(n, valor);
  if (tipo === 'apelido') return definirApelido(n, valor);
  if (tipo === 'menu-lateral' && !conta) {
    return Menu.buildFromTemplate([{ label: `Ligar ${nomeDoNumero(n)}`, click: () => abrirConta(n) }]).popup({ window: janela });
  }
  if (!conta) return;
  if (tipo === 'focar') mostrar(focada === conta ? null : conta);
  else if (tipo === 'tela-cheia') alternarTelaCheia(conta);
  else if (tipo === 'recarregar') recarregarConta(conta);
  else if (tipo === 'mudo') definirMudo(conta, !layout.mudas[n]);
  else if (tipo === 'extensoes') menuExtensoes(conta).popup({ window: janela });
  else if (tipo === 'script') menuScript(conta).popup({ window: janela });
  else if (tipo === 'conta' || tipo === 'menu-lateral') menuConta(conta).popup({ window: janela });
});

function avisar(tipo, titulo, corpo) {
  if (layout.avisos[tipo] === false) return;
  registrar(`aviso: ${titulo} — ${corpo}`);
  if (!Notification.isSupported()) return;
  const n = new Notification({ title: titulo, body: corpo, icon: ICONE });
  n.on('click', mostrarJanela);
  n.show();
}

// ---------------------------------------------------------------- pontes do script
ipcMain.on('tick:userscript', (ev) => {
  const conta = contaDoJogo(ev.sender);
  // Lido a cada carga: atualizar o script só pede um F5. Desativado, sobra só o status da conta.
  let script = '';
  if (!conta || estaAtiva(conta.n, ID_SCRIPT)) {
    try { script = lerScript(USERSCRIPT); } catch (e) { registrarErro('script', e); }
  }
  ev.returnValue = `(() => {
    const P = window.__tickGM; delete window.__tickGM;
    const TICK_APP = true;
    // A rolagem. O jogo usa a roda sobre o palco para aproximar a câmera, mesmo no modo economia, em que a
    // cena está escondida; e, ao chamar preventDefault, também impede o Ctrl + roda de dar zoom.
    window.addEventListener('wheel', (ev) => {
      if (ev.ctrlKey) return ev.stopPropagation(); // Ctrl + roda é sempre o zoom da conta
      const alvo = ev.target;
      if (document.documentElement.classList.contains('modo-economia') && alvo.closest?.('.eco-painel')) ev.stopPropagation();
    }, { capture: true, passive: true });
    // Conta nova nasce com tudo desligado: o padrão do script compraria, venderia e trocaria de hunt
    // sozinho no primeiro login. Cada automação só liga quando a pessoa pedir, no menu da conta.
    if (!localStorage.getItem('tick.cfgSegura.v1')) {
      localStorage.setItem('autocompra.cfg.v1', JSON.stringify({
        ligado: false, garantirLigado: false, melhorHunt: false, triagem: false, vigia: false, historico: false,
      }));
      localStorage.setItem('tick.cfgSegura.v1', '1');
    }
    // Status da conta para a interface do Tick: só escuta o socket do jogo, nunca envia nada por ele.
    {
      const atual = { ws: 'carregando' };
      let pendente, ultimaSessao = null;
      const relatar = (mudou) => {
        const sessaoAgora = localStorage.getItem('sessao');
        // O jogo renova o token sozinho: a cópia do Tick acompanha.
        if (sessaoAgora && sessaoAgora !== ultimaSessao) { ultimaSessao = sessaoAgora; P.sessao(sessaoAgora); }
        let nick = null;
        try { nick = JSON.parse(sessaoAgora)?.nick ?? null; } catch {}
        Object.assign(atual, mudou, { temLogin: !!sessaoAgora, nick });
        if (!pendente) pendente = setTimeout(() => { pendente = null; P.status({ ...atual }); }, 1000);
      };
      const vistos = new WeakSet();
      let socket = null;
      const adotar = (ws) => {
        if (vistos.has(ws)) return;
        vistos.add(ws);
        socket = ws;
        if (ws.readyState === 1) relatar({ ws: 'conectada' });
        ws.addEventListener('open', () => { if (ws === socket) relatar({ ws: 'conectada' }); });
        // 4001: a conta abriu em outro lugar. O jogo não reconecta nesse caso, e o Tick também não insiste.
        ws.addEventListener('close', (ev) => { if (ws === socket) relatar({ ws: ev.code === 4001 ? 'outro' : 'caiu' }); });
        ws.addEventListener('message', (ev) => {
          if (typeof ev.data !== 'string' || !ev.data.includes('"')) return;
          let m;
          try { m = JSON.parse(ev.data); } catch { return; }
          const e = m.estado;
          if (e && typeof e === 'object') {
            const mudou = {};
            if (typeof e.gold === 'number') mudou.ouro = e.gold;
            if (typeof e.level === 'number') mudou.nivel = e.level;
            if (e.automation) {
              const r = e.automation.autoColecao;
              mudou.colecao = r && typeof r === 'object'
                ? { notaOn: !!r.nota?.on, notaMin: r.nota?.min ?? null, shinyOn: r.shiny?.on !== false }
                : { notaOn: !!e.automation.autoLockNota9, notaMin: e.automation.autoLockNotaMin ?? null, shinyOn: true };
              mudou.travados = e.automation.pokemonTravado?.length ?? 0;
            }
            for (const [rede, chave] of [['twitch', 'login'], ['kick', 'slug']]) {
              const b = e[rede];
              if (!b || typeof b !== 'object') continue;
              mudou[rede] = {
                vinculado: !!b.vinculado,
                bonus: b.bonus ?? {},
                canais: (Array.isArray(b.oficiais) ? b.oficiais : []).map((c) => ({ id: c[chave], nome: c.nome || c[chave], aoVivo: !!c.aoVivo, ativo: !!c.ativo, espectadores: c.espectadores ?? 0 })),
              };
            }
            if (Object.keys(mudou).length) relatar(mudou);
          }
          if (m.t === 'batalha' && Array.isArray(m.ev) && m.ev.some((x) => x?.k === 'centro' && x.motivo === 'morte')) P.nocaute();
        });
      };
      const WsOriginal = window.WebSocket;
      window.WebSocket = new Proxy(WsOriginal, {
        construct(alvo, args) {
          const ws = Reflect.construct(alvo, args);
          if (String(args[0] ?? '').includes('pokeidle.io')) adotar(ws);
          return ws;
        },
      });
      const enviarOriginal = WsOriginal.prototype.send;
      WsOriginal.prototype.send = function (dados) {
        if (String(this.url).includes('pokeidle.io')) adotar(this);
        return enviarOriginal.call(this, dados);
      };
      relatar({});
      setInterval(() => relatar({}), 30_000);
    }
    const cmds = new Map(); let n = 0, t;
    const sinc = () => { clearTimeout(t); t = setTimeout(() => P.menu([...cmds].map(([id, c]) => ({ id, nome: c.nome }))), 0); };
    P.aoClicarMenu((id) => cmds.get(id)?.fn());
    const GM_registerMenuCommand = (nome, fn) => { const id = ++n; cmds.set(id, { nome, fn }); sinc(); return id; };
    const GM_unregisterMenuCommand = (id) => { cmds.delete(id); sinc(); };
    const GM_xmlhttpRequest = (o) => {
      P.http({ method: o.method, url: o.url, headers: o.headers, data: o.data, timeout: o.timeout })
        .then((r) => o.onload?.(r), () => o.onerror?.());
    };
    ${script}
  })();
  //# sourceURL=tick://pokeidle-autocompra.user.js`;
});

// A cópia do login vai antes de qualquer script da página, para o jogo já a encontrar ao abrir.
ipcMain.on('tick:copia', (ev) => {
  const conta = contaDoJogo(ev.sender);
  ev.returnValue = conta ? ctx.sessoes.get(conta.n) ?? null : null;
});

// Só deixa sair para o Assistente: a página do jogo não ganha acesso geral à rede do PC.
ipcMain.handle('tick:http', async (_ev, p) => {
  if (p.method !== 'POST' || p.url !== ASSISTENTE) throw new Error('destino não permitido');
  const r = await fetch(p.url, {
    method: 'POST', headers: p.headers, body: p.data, signal: AbortSignal.timeout(p.timeout ?? 10_000),
  });
  registrar(`assistente: POST ${r.status}`);
  return { status: r.status };
});

ipcMain.on('tick:menu', (ev, lista) => {
  const conta = contaDoJogo(ev.sender);
  if (conta) conta.menu = lista;
});

ipcMain.on('tick:status', (ev, dadosStatus) => {
  const conta = contaDoJogo(ev.sender);
  if (conta) atualizarStatus(conta, dadosStatus);
});

/** A previsão de shiny vem da página do jogo: só texto curto e número passam para a interface do Tick. */
function limparShiny(s) {
  if (!s || typeof s !== 'object') return null;
  return {
    texto: String(s.texto ?? '').slice(0, 80),
    dica: String(s.dica ?? '').slice(0, 1500),
    escapou: Number.isInteger(s.escapou) && s.escapou >= 0 ? s.escapou : 0,
  };
}

function atualizarStatus(conta, novo) {
  const antes = conta.status.ws;
  if ('shiny' in novo) {
    const shiny = limparShiny(novo.shiny);
    if (shiny && shiny.escapou > (conta.status.shiny?.escapou ?? 0)) {
      avisar('shiny', 'Um shiny escapou', `${nomeDe(conta)} viu um shiny, e a bola não fechou.`);
    }
    novo = { ...novo, shiny };
  }
  conta.status = { ...conta.status, ...novo };
  const situacao = situacaoDe(conta);
  if (situacao !== conta.situacaoAnotada) {
    conta.situacaoAnotada = situacao;
    anotar(`conta ${conta.n}: ${situacao}`);
  }
  if (novo.nick && layout.nomes[conta.n] !== novo.nick) {
    layout.nomes[conta.n] = novo.nick; // para a conta ter nome mesmo desligada
    salvarLayout();
  }
  if (novo.temLogin === false) restaurarLogin(conta);
  if (novo.ws === 'conectada' && antes !== 'conectada') {
    marcarColetorDoMeta(conta);
    conta.restauracoes = 0;
    conta.desde = Date.now();
    conta.jaConectou = true;
    clearTimeout(conta.timerQueda);
    conta.timerQueda = null;
  }
  // Só um aviso que fala da conexão a encerra: a previsão de shiny, por exemplo, chega sem `ws`.
  if ('ws' in novo && novo.ws !== 'conectada' && antes === 'conectada') conta.desde = null;
  if (novo.ws === 'outro' && antes !== 'outro') {
    avisar('outro', 'Conta aberta em outro lugar', `${nomeDe(conta)} saiu do Tick porque foi aberta em outra aba ou aparelho. Feche lá e recarregue a conta.`);
  }
  if ((novo.ws === 'caiu' || novo.ws === 'semrede') && conta.jaConectou && !conta.timerQueda) {
    conta.timerQueda = setTimeout(() => {
      conta.timerQueda = null;
      if (conta.status.ws !== 'conectada' && contas.includes(conta)) avisar('queda', 'Conta desconectada', `${nomeDe(conta)} está fora do jogo há 1 minuto.`);
    }, QUEDA_AVISO_MS);
  }
  publicar();
}

ipcMain.on('tick:sessao', (ev, sessao) => {
  const conta = contaDoJogo(ev.sender);
  if (conta && typeof sessao === 'string') guardarSessao(conta.n, sessao);
});

ipcMain.on('tick:nocaute', (ev) => {
  const conta = contaDoJogo(ev.sender);
  if (!conta || Date.now() - (conta.ultimoNocaute ?? 0) < NOCAUTE_INTERVALO_MS) return;
  conta.ultimoNocaute = Date.now();
  avisar('nocaute', 'Time nocauteado', `${nomeDe(conta)} voltou ao Centro Pokémon.`);
});

// ---------------------------------------------------------------- recuperação de falhas
const naTelaDeErro = (wc) => wc.getURL().startsWith('file:');

function abrirJogo(conta) {
  clearTimeout(conta.timerRede);
  conta.view.webContents.loadURL(URL_JOGO).catch(() => { /* quem trata a falha é o did-fail-load */ });
}

/** Na tela de "sem conexão", recarregar repetiria a própria tela: abre o jogo de novo. */
function recarregarConta(conta) {
  const wc = conta.view.webContents;
  if (naTelaDeErro(wc) || wc.isCrashed()) abrirJogo(conta);
  else wc.reload();
}

function vigiarFalhas(conta) {
  const wc = conta.view.webContents;
  wc.on('did-fail-load', (_ev, codigo, descricao, url, principal) => {
    // -3 é carga interrompida por outra navegação: normal.
    if (!principal || codigo === -3 || url.startsWith('file:')) return;
    registrarErro(`conta ${conta.n}`, `não abriu ${logica.urlParaRegistro(url)}: ${descricao} (${codigo})`);
    atualizarStatus(conta, { ws: 'semrede' });
    // Navegar de dentro deste evento é ignorado: a tela de erro precisa esperar o evento terminar.
    setTimeout(() => {
      if (contas.includes(conta)) wc.loadFile(path.join(__dirname, 'erro.html')).catch((e) => registrarErro(`conta ${conta.n}`, e));
    }, 0);
  });
  // O Cloudflare responde 520/523 quando o servidor do jogo cai: a carga "dá certo", o
  // did-fail-load não dispara e a conta ficava parada na página de erro. Vai para a tela de
  // "sem conexão", que tenta de novo sozinha.
  wc.on('did-navigate', (_ev, url, codigo) => {
    if (!logica.servidorFora(url, codigo)) return;
    registrarErro(`conta ${conta.n}`, `servidor do jogo fora do ar (${codigo})`);
    atualizarStatus(conta, { ws: 'semrede' });
    setTimeout(() => {
      if (contas.includes(conta)) wc.loadFile(path.join(__dirname, 'erro.html')).catch((e) => registrarErro(`conta ${conta.n}`, e));
    }, 0);
  });
  wc.on('did-finish-load', () => {
    wc.setZoomFactor(zoomDe(conta.n)); // o zoom volta a cada carga
    clearTimeout(conta.timerRede);
    if (!naTelaDeErro(wc)) return;
    atualizarStatus(conta, { ws: 'semrede' });
    conta.timerRede = setTimeout(() => abrirJogo(conta), TENTAR_DE_NOVO_MS);
  });
  wc.on('render-process-gone', (_ev, { reason, exitCode }) => {
    if (reason === 'clean-exit' || !contas.includes(conta)) return;
    registrarErro(`conta ${conta.n}`, `a página parou: ${reason} (${exitCode})`);
    atualizarStatus(conta, { ws: 'caiu' });
    const agora = Date.now();
    conta.recargas = (conta.recargas ?? []).filter((t) => agora - t < JANELA_RECARGAS_MS);
    if (conta.recargas.length >= LIMITE_RECARGAS) {
      avisar('queda', 'Página parada', `${nomeDe(conta)} parou várias vezes seguidas. Recarregue a conta quando quiser tentar de novo.`);
      return;
    }
    conta.recargas.push(agora);
    conta.timerRede = setTimeout(() => abrirJogo(conta), 3_000);
  });
  wc.on('unresponsive', () => {
    clearTimeout(conta.timerTravada);
    conta.timerTravada = setTimeout(() => {
      registrarErro(`conta ${conta.n}`, 'página sem responder: reiniciando');
      wc.forcefullyCrashRenderer();
    }, TRAVADA_MS);
  });
  wc.on('responsive', () => clearTimeout(conta.timerTravada));
}

// ---------------------------------------------------------------- teclado
function teclas(conta, ev, input) {
  if (input.type !== 'keyDown') return;
  if (input.key === 'F11' && conta) { ev.preventDefault(); return alternarTelaCheia(conta); }
  if (input.key === 'F5' && conta) { ev.preventDefault(); return recarregarConta(conta); }
  if (!input.control || input.alt || input.meta) return;
  if (/^[1-9]$/.test(input.key)) {
    const alvo = ordenadas()[Number(input.key) - 1];
    if (alvo) { ev.preventDefault(); mostrar(alvo); }
    return;
  }
  if (input.key === '0') { ev.preventDefault(); return mostrar(null); }
  if (!conta) return;
  if (input.key === '=' || input.key === '+') { ev.preventDefault(); definirZoom(conta, zoomDe(conta.n) + PASSO_ZOOM); }
  else if (input.key === '-') { ev.preventDefault(); definirZoom(conta, zoomDe(conta.n) - PASSO_ZOOM); }
}

// ---------------------------------------------------------------- contas
async function abrirConta(pedida) {
  const n = pedida ?? logica.proximaConta(layout.slots, MAX_CONTAS);
  if (n == null || abrindo.has(n) || contas.some((c) => c.n === n)) return;
  abrindo.add(n);
  try {
    const ses = session.fromPartition(`persist:conta-${n}`);
    limitarPermissoes(ses);
    const conta = { n, ses, menu: [], extIds: {}, status: { ws: 'carregando', temLogin: true } };

    for (const item of catalogo()) {
      if (!estaAtiva(n, item.id)) continue;
      try { await carregarExtensao(conta, item); } catch (e) { registrarErro(`conta ${n}: extensão ${item.id}`, e); }
    }

    conta.barra = new WebContentsView({ webPreferences: { preload: path.join(__dirname, 'preload-ui.js') } });
    conta.barra.webContents.loadFile(path.join(__dirname, 'barra.html'), { query: { n: String(n) } });
    conta.view = new WebContentsView({
      webPreferences: {
        session: ses,
        preload: path.join(__dirname, 'preload-jogo.js'),
        backgroundThrottling: false,
      },
    });
    const wc = conta.view.webContents;
    wc.setAudioMuted(!!layout.mudas[n]);
    wc.setWindowOpenHandler(({ url }) => {
      const { hostname } = new URL(url);
      if (hostname === 'pokeidle.io') {
        return { action: 'allow', overrideBrowserWindowOptions: { width: 520, height: 700, autoHideMenuBar: true } };
      }
      abrirNoNavegador(url);
      return { action: 'deny' };
    });
    // O Google recusa login aqui dentro: o botão dele no jogo já leva direto ao caminho que funciona.
    const desviarGoogle = (ev, url) => {
      const { hostname, pathname } = new URL(url);
      if (hostname !== 'accounts.google.com' && !(hostname === 'pokeidle.io' && pathname.startsWith('/auth/google'))) return;
      ev.preventDefault();
      registrar(`login: botão do Google desviado na conta ${n}`);
      if (ctx.recepcao?.conta !== conta) receberLogin(conta);
    };
    wc.on('dom-ready', () => {
      if (!naTelaDeErro(wc)) wc.insertCSS(CSS_ECONOMIA).catch((e) => registrarErro(`conta ${n}: estilo`, e));
      // Quem ainda não recebeu o modo escolhido (a conta ligada depois da escolha) recebe uma vez, sem recarga em laço.
      if (layout.modoJogo && conta.modoConferido !== layout.modoJogo && !naTelaDeErro(wc)) {
        conta.modoConferido = layout.modoJogo;
        const querEco = layout.modoJogo === 'economia' ? '1' : '0';
        const querUltra = layout.modoJogo === 'ultra' ? '1' : '0';
        wc.executeJavaScript(`(localStorage.getItem('cfg-economia') ?? '0') === '${querEco}' && (localStorage.getItem('cfg-ultra') ?? '0') === '${querUltra}'`)
          .then((igual) => { if (!igual) aplicarModoNaConta(conta, layout.modoJogo); })
          .catch((e) => registrarErro(`modo da conta ${n}`, e));
      }
    });
    wc.on('will-navigate', desviarGoogle);
    wc.on('will-redirect', desviarGoogle);
    wc.on('before-input-event', (ev, input) => teclas(conta, ev, input));
    conta.barra.webContents.on('before-input-event', (ev, input) => teclas(conta, ev, input));
    // A roda do mouse pode disparar o evento mais de uma vez por clique: um passo a cada 100 ms.
    wc.on('zoom-changed', (_ev, direcao) => {
      if (Date.now() - (conta.ultimoZoom ?? 0) < 100) return;
      conta.ultimoZoom = Date.now();
      definirZoom(conta, zoomDe(n) + (direcao === 'in' ? PASSO_ZOOM : -PASSO_ZOOM));
    });
    // A página nova ainda não falou nada: até o script relatar, a conta está carregando.
    wc.on('did-start-navigation', (d) => {
      if (d.isMainFrame && !d.isSameDocument) atualizarStatus(conta, { ws: 'carregando' });
    });
    vigiarFalhas(conta);
    if (DIAG) {
      wc.on('console-message', ({ level, message }) => {
        if (level === 'error' || /autocompra|rotom|\/hunt|pih/i.test(message)) registrar(`conta ${n} [${level}] ${message.slice(0, 300)}`);
      });
      wc.on('did-navigate', (_e, url) => registrar(`conta ${n}: navegou para ${logica.urlParaRegistro(url)}`));
      wc.on('did-finish-load', () => { conta.timerDiag1 = setTimeout(() => diagnosticar(conta), 12_000); });
      conta.timerDiag2 = setInterval(() => diagnosticar(conta), 30_000);
    }

    contas.push(conta);
    if (!layout.slots.includes(n)) layout.slots.push(n);
    if (!layout.abertas.includes(n)) layout.abertas.push(n);
    salvarLayout();
    janela.contentView.addChildView(conta.barra);
    janela.contentView.addChildView(conta.view);
    dispor();
    publicar();
    wc.loadURL(URL_JOGO).catch(() => { /* quem trata a falha é o did-fail-load */ });
    return conta;
  } catch (e) {
    registrarErro(`abrir conta ${n}`, e);
    dialog.showMessageBox(janela, { type: 'error', title: 'Tick', message: `Não consegui ligar a Conta ${n}.`, detail: e.message });
  } finally {
    abrindo.delete(n);
  }
}

/** Desliga a conta sem esquecer o login: ela sai do jogo e fica na barra lateral para ligar de novo. */
function fecharConta(conta) {
  if (ctx.recepcao?.conta === conta) pararRecepcao();
  if (focada === conta) mostrar(null);
  for (const t of ['timerQueda', 'timerRede', 'timerTravada', 'timerDiag1']) clearTimeout(conta[t]);
  clearInterval(conta.timerDiag2);
  if (conta.cockpit && !conta.cockpit.isDestroyed()) conta.cockpit.close();
  conta.ses.flushStorageData();
  contas.splice(contas.indexOf(conta), 1);
  layout.abertas = layout.abertas.filter((n) => n !== conta.n);
  salvarLayout();
  janela.contentView.removeChildView(conta.barra);
  janela.contentView.removeChildView(conta.view);
  conta.view.webContents.close();
  conta.barra.webContents.close();
  dispor();
  publicar();
  anotar(`conta ${conta.n}: desligada`);
}

function dispor() {
  const { width, height } = janela.getContentBounds();
  const margem = cheia ? 0 : LARGURA_LATERAL;
  lateral.setVisible(!cheia);
  lateral.setBounds({ x: 0, y: 0, width: LARGURA_LATERAL, height });
  const visiveis = focada ? [focada] : ordenadas();
  for (const c of contas) {
    const visivel = visiveis.includes(c);
    c.barra.setVisible(visivel);
    c.view.setVisible(visivel); // continua rodando escondida: backgroundThrottling está desligado
  }
  for (const r of logica.retangulos(visiveis.map((c) => c.n), layout.modo, layout.pesos, margem, width, height)) {
    const c = contas.find((k) => k.n === r.n);
    c.barra.setBounds({ x: r.x, y: r.y, width: r.largura, height: ALTURA_BARRA });
    c.view.setBounds({ x: r.x, y: r.y + ALTURA_BARRA, width: r.largura, height: r.altura - ALTURA_BARRA });
  }
}

function mostrar(conta) {
  if (cheia) { cheia = false; janela.setFullScreen(false); }
  focada = conta;
  dispor();
  publicar();
  conta?.view.webContents.focus();
}

function alternarTelaCheia(conta) {
  const sair = cheia && focada === conta;
  focada = sair ? null : conta;
  cheia = !sair;
  janela.setFullScreen(cheia);
  dispor();
  publicar();
  if (cheia) conta.view.webContents.focus();
  registrar(`tela cheia: ${cheia ? `conta ${conta.n}` : 'nenhuma'}`);
}

// ---------------------------------------------------------------- limites para as páginas
function abrirNoNavegador(url) {
  if (logica.urlExternaSegura(url)) shell.openExternal(url);
  else anotar(`[erro] link recusado: ${logica.urlParaRegistro(url)}`);
}

// As páginas só recebem o que precisam: nada de câmera, microfone, localização ou notificações do site.
const PERMISSOES_DAS_PAGINAS = new Set(['fullscreen', 'clipboard-sanitized-write']);

function limitarPermissoes(ses) {
  ses.setPermissionRequestHandler((_wc, permissao, responder) => responder(PERMISSOES_DAS_PAGINAS.has(permissao)));
  ses.setPermissionCheckHandler((_wc, permissao) => PERMISSOES_DAS_PAGINAS.has(permissao));
}

// ---------------------------------------------------------------- modos do jogo, em todas as contas
const MODOS_JOGO = [['cena', 'Cena'], ['economia', 'Economia'], ['ultra', 'Ultra Economia']];
const ESPERA_RECARGA_MODO_MS = 1_500;

const scriptModoJogo = (modo) => `localStorage.setItem('cfg-economia', '${modo === 'economia' ? 1 : 0}'); localStorage.setItem('cfg-ultra', '${modo === 'ultra' ? 1 : 0}');`;

async function aplicarModoNaConta(conta, modo) {
  const wc = conta.view.webContents;
  if (naTelaDeErro(wc)) return;
  await wc.executeJavaScript(scriptModoJogo(modo));
  recarregarConta(conta);
}

/** O jogo lê o modo ao abrir. Recarrega uma conta por vez, para não derrubar todas juntas. */
async function definirModoJogo(modo) {
  if (!MODOS_JOGO.some(([m]) => m === modo)) return;
  layout.modoJogo = modo;
  salvarLayout();
  publicar();
  anotar(`modo do jogo: ${modo}`);
  for (const conta of ordenadas()) {
    try {
      await aplicarModoNaConta(conta, modo);
    } catch (e) {
      registrarErro(`modo da conta ${conta.n}`, e);
    }
    await new Promise((ok) => { setTimeout(ok, ESPERA_RECARGA_MODO_MS); });
  }
}

const menuModos = () => Menu.buildFromTemplate([
  { label: 'Modo de todas as contas', enabled: false },
  ...MODOS_JOGO.map(([m, nome]) => ({ label: nome, type: 'radio', checked: (layout.modoJogo ?? 'cena') === m, click: () => definirModoJogo(m) })),
]);

// ---------------------------------------------------------------- menus
/** A barra lateral recolhida (janela baixa, ou recolhida à mão): os botões dela num menu só. */
function menuFerramentas() {
  return Menu.buildFromTemplate([
    { label: 'Modo do jogo em todas as contas', submenu: menuModos() },
    { label: 'Lives da Twitch e Kick', submenu: menuLives() },
    { label: 'Meta do PvP', click: abrirMeta },
    { label: 'Trocar a conta que analisa o meta', click: () => escolherContaMeta() },
    { label: 'Melhor hunt em camadas', click: abrirHunts },
    { label: 'Triar Depot', click: triarDepot },
    { type: 'separator' },
    { label: 'Ver todas as contas', accelerator: 'Ctrl+0', registerAccelerator: false, enabled: !!focada, click: () => mostrar(null) },
    { label: 'Configurações', click: abrirConfig },
  ]);
}

function menuExtensoes(conta) {
  return Menu.buildFromTemplate([
    { label: 'Auto Compra', type: 'checkbox', checked: estaAtiva(conta.n, ID_SCRIPT), click: (i) => definirExtensao(conta.n, ID_SCRIPT, i.checked) },
    ...catalogo().map((x) => ({ label: x.nome, type: 'checkbox', checked: estaAtiva(conta.n, x.id), click: (i) => marcarNoMenu(conta, x, i.checked) })),
    { type: 'separator' },
    { label: 'Adicionar extensão de uma pasta...', click: () => escolherExtensao(conta) },
  ]);
}

function menuScript(conta) {
  return Menu.buildFromTemplate(conta.menu.length
    ? conta.menu.map((m) => ({ label: m.nome, click: () => conta.view.webContents.send('tick:menu-click', m.id) }))
    : [{ label: estaAtiva(conta.n, ID_SCRIPT) ? 'Auto Compra ainda carregando' : 'Auto Compra desativado nesta conta', enabled: false }]);
}

function menuConta(conta) {
  const zoom = zoomDe(conta.n);
  return Menu.buildFromTemplate([
    { label: 'Cockpit do Rotom Sniper', enabled: !!conta.extIds[ID_ROTOM], click: () => abrirCockpit(conta) },
    { type: 'separator' },
    {
      label: `Zoom: ${Math.round(zoom * 100)}%`,
      submenu: [
        { label: 'Aumentar', accelerator: 'Ctrl+=', registerAccelerator: false, enabled: zoom < logica.ZOOM_MAX, click: () => definirZoom(conta, zoom + PASSO_ZOOM) },
        { label: 'Diminuir', accelerator: 'Ctrl+-', registerAccelerator: false, enabled: zoom > logica.ZOOM_MIN, click: () => definirZoom(conta, zoom - PASSO_ZOOM) },
        { label: 'Voltar a 100%', enabled: zoom !== 1, click: () => definirZoom(conta, 1) },
      ],
    },
    {
      label: 'Largura da coluna',
      submenu: LARGURAS.map(([label, peso]) => ({
        label, type: 'radio', checked: (layout.pesos[conta.n] ?? 1) === peso, click: () => definirPeso(conta, peso),
      })),
    },
    {
      label: 'Disposição das contas',
      submenu: MODOS.map(([modo, label]) => ({ label, type: 'radio', checked: layout.modo === modo, click: () => definirModo(modo) })),
    },
    { label: 'Renomear conta', click: () => conta.barra.webContents.send('tick:renomear') },
    { type: 'separator' },
    ctx.recepcao?.conta === conta
      ? { label: 'Cancelar espera do login', click: () => pararRecepcao() }
      : { label: 'Receber login do navegador', click: () => receberLogin(conta) },
    { label: 'Esquecer o login desta conta', click: () => confirmarEsquecer(conta) },
    { type: 'separator' },
    { label: 'Desligar esta conta', click: () => fecharConta(conta) },
    { label: 'Configurações', click: abrirConfig },
    { label: 'Ferramentas de desenvolvedor', click: () => conta.view.webContents.openDevTools({ mode: 'detach' }) },
  ]);
}

// ---------------------------------------------------------------- o contexto dos módulos
// O que os módulos de src/principal usam daqui: o estado que muda (sempre o valor atual) e as funções.
expor({
  layout: () => layout, janela: () => janela, lateral: () => lateral, focada: () => focada, cheia: () => cheia,
  contas: () => contas, VERSAO_AMIGO: () => VERSAO_AMIGO,
  USERSCRIPT: { get: () => USERSCRIPT, set: (v) => { USERSCRIPT = v; } },
});
Object.assign(ctx, {
  avisar, dados, nomeDe, recarregarConta, comWindows, nomeDoNumero, situacaoDe, zoomDe, definirComWindows,
  salvarLayout, definirModo, abrirConta, fecharConta, definirMudo, definirZoom, dispor, definirApelido,
  naTelaDeErro, ordenadas, atualizarStatus, menuConta, menuScript, menuExtensoes, mostrarJanela,
  definirModoJogo, publicar, limitarPermissoes, abrirNoNavegador, mostrar,
});

// ---------------------------------------------------------------- início
app.whenReady().then(async () => {
  if (segundoClique) return;
  conferirContexto(); // um nome sem dono num módulo aparece aqui, na abertura, e não no meio do uso
  Menu.setApplicationMenu(null);
  lerLayout();
  // Neste PC, a cópia que anda junto com o Tick acompanha o script de trabalho.
  if (USERSCRIPT === SCRIPT_TRABALHO) {
    try { fs.copyFileSync(SCRIPT_TRABALHO, SCRIPT_JUNTO); } catch (e) { registrarErro('copiar script', e); }
  }
  janela = new BaseWindow({ ...limitesSalvos(), title: 'Tick', icon: ICONE, backgroundColor: '#15131c' });
  if (layout.janela?.maximizada) janela.maximize();
  montarBandeja();
  lateral = new WebContentsView({ webPreferences: { preload: path.join(__dirname, 'preload-ui.js') } });
  lateral.webContents.loadFile(path.join(__dirname, 'lateral.html'));
  lateral.webContents.on('before-input-event', (ev, input) => teclas(null, ev, input));
  janela.contentView.addChildView(lateral);
  janela.on('resize', () => { dispor(); guardarJanela(); });
  janela.on('move', guardarJanela);
  janela.on('leave-full-screen', () => { if (cheia) { cheia = false; focada = null; dispor(); publicar(); } });
  // O X esconde na bandeja e as contas seguem jogando, a menos que a pessoa escolha sair nas configurações.
  janela.on('close', (ev) => {
    if (saindo || layout.xSai) return;
    ev.preventDefault();
    janela.hide();
    if (!layout.avisouBandeja) {
      layout.avisouBandeja = true;
      salvarLayout();
      avisar('sistema', 'O Tick continua rodando', 'As contas seguem jogando. Para sair, clique com o botão direito no ícone do Tick perto do relógio.');
    }
  });
  janela.on('closed', () => app.quit());
  janela.on('session-end', apagarMarcaVigia); // o Windows está desligando: isto não é uma queda
  const gravarTudo = () => { for (const c of contas) c.ses.flushStorageData(); };
  setInterval(gravarTudo, GRAVAR_DADOS_MS);
  app.on('before-quit', gravarTudo);
  salvarLayout(); // grava a migração do contas.json
  iniciarVigia();
  iniciarDiagnosticoDeQuedas();
  dispor();
  janelaAberta = true;
  iniciarAtualizacao();
  iniciarAtualizacaoDeExtensoes();
  // Só depois da janela: nada que dependa da internet ou do sistema pode deixar o app invisível.
  let esperaCofre;
  await Promise.race([
    abrirCofre().catch((e) => registrarErro('cofre', e)),
    new Promise((ok) => { esperaCofre = setTimeout(() => { registrarErro('cofre', 'sem resposta em 10 segundos'); ok(); }, 10_000); }),
  ]);
  clearTimeout(esperaCofre);
  await baixarExtensoesDaLoja();
  const abertas = logica.ordenar(layout.abertas, layout.ordem);
  anotar(`início: ${app.isPackaged ? 'Tick.exe' : 'desenvolvimento'}, contas ${abertas.join(',') || 'nenhuma'}, logins guardados ${[...ctx.sessoes.keys()].join(',') || 'nenhum'}`);
  for (const n of abertas) await abrirConta(n);
  if (process.argv.includes('--teste-recursos')) testarRecursos().catch((e) => { registrarErro('teste recursos', e); registrar('teste: fim (com erro)'); });
  if (process.argv.includes('--teste-rolagem')) testarRolagem().catch((e) => { registrarErro('teste rolagem', e); app.quit(); });
  if (TESTE_APP) testarApp().catch((e) => { registrarErro('teste', e); registrar('teste: fim (com erro)'); });
}).catch((e) => { registrarErro('início', e); falhaAoAbrir(e); });
