// @ts-check
// O vigia do Tick: um processo separado, sem janela, que reabre o app se ele cair ou travar.
//
// O Tick grava uma marca em dados/ ao abrir e a apaga ao sair, e um sinal de vida a cada 30 s. Processo acabado
// com a marca ainda lá: caiu. Processo vivo sem sinal há 5 min: travou, e o vigia o fecha para reabrir. Quem
// sai por "Sair do Tick" ou desliga o PC não é reaberto. O Tick, por sua vez, confere o vigia a cada minuto e
// inicia outro se este parar. Rodar com ELECTRON_RUN_AS_NODE=1.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const CHECAGEM_MS = 2_000;
const SEM_SINAL_MS = 5 * 60_000;
// O relógio andou mais que isso entre duas checagens: o PC estava suspenso, e o Tick também. O sinal velho
// não conta como travamento: a contagem recomeça na volta.
const SALTO_MS = 30_000;
const CONFIRMAR_MS = 2 * 60_000; // tempo para o Tick reaberto assumir a marca
const JANELA_MS = 30 * 60_000;
// Cada queda seguida espera mais. Não desiste nunca: só "Sair do Tick" para o vigia.
const ESPERAS_MS = [15_000, 60_000, 5 * 60_000, 15 * 60_000];

/** Quanto esperar antes de reabrir, pelas quedas da última meia hora. */
function esperaParaReabrir(historico, agora, janela = JANELA_MS, esperas = ESPERAS_MS) {
  const recentes = (Array.isArray(historico) ? historico : []).filter((t) => Number.isFinite(t) && agora - t < janela);
  return { ms: esperas[Math.min(recentes.length, esperas.length - 1)], recentes };
}

/** O Tick está travado? `desde`: quando a contagem recomeçou (início do vigia ou volta da suspensão). */
function travado(ultimoSinal, desde, agora, semSinalMs = SEM_SINAL_MS) {
  const base = Math.max(Number.isFinite(ultimoSinal) ? ultimoSinal : 0, desde);
  return agora - base > semSinalMs;
}

const estaVivo = (pid) => {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return /** @type {NodeJS.ErrnoException} */ (e).code === 'EPERM';
  }
};

const lerMarca = (cfg) => {
  try { return fs.readFileSync(cfg.marca, 'utf8').trim(); } catch { return null; }
};
const lerSinal = (cfg) => {
  try { return Number(JSON.parse(fs.readFileSync(cfg.sinal, 'utf8')).em); } catch { return NaN; }
};

function anotar(cfg, txt) {
  try {
    fs.mkdirSync(path.dirname(cfg.registro), { recursive: true });
    fs.appendFileSync(cfg.registro, `${new Date().toISOString()} ${txt}\n`);
  } catch { /* sem registro, o vigia segue */ }
}

function gravar(arquivo, valor) {
  try { fs.writeFileSync(arquivo, JSON.stringify(valor)); } catch { /* o vigia segue */ }
}

const sair = () => process.exit(0);

/** Reabre com espera crescente e confere se o Tick novo assumiu. Se não assumir, tenta de novo. */
function recuperar(cfg, motivo) {
  let historico = [];
  try { historico = JSON.parse(fs.readFileSync(cfg.historico, 'utf8')); } catch { /* primeira vez */ }
  const agora = Date.now();
  const { ms, recentes } = esperaParaReabrir(historico, agora);
  gravar(cfg.historico, [...recentes, agora]);
  anotar(cfg, `vigia: reabrindo em ${Math.round(ms / 1000)} s (${recentes.length + 1}ª queda em 30 min)`);
  setTimeout(() => {
    // Alguém já abriu o Tick à mão, ou saiu por "Sair do Tick": não é mais comigo.
    if (lerMarca(cfg) !== String(cfg.pid)) {
      anotar(cfg, 'vigia: o Tick já foi aberto de outro jeito — encerrando');
      return sair();
    }
    gravar(cfg.ultimo, { motivo, em: Date.now(), quedas: recentes.length + 1 });
    const env = { ...process.env };
    delete env.ELECTRON_RUN_AS_NODE;
    const filho = spawn(cfg.exe, cfg.args ?? [], { detached: true, stdio: 'ignore', env, cwd: path.dirname(cfg.exe) });
    filho.on('error', (e) => anotar(cfg, `[erro] vigia: não consegui reabrir: ${e.message}`));
    filho.unref();
    const inicio = Date.now();
    const conferir = setInterval(() => {
      if (lerMarca(cfg) !== String(cfg.pid)) {
        clearInterval(conferir);
        anotar(cfg, 'vigia: o Tick reabriu — o vigia dele assume daqui');
        sair();
      } else if (Date.now() - inicio > CONFIRMAR_MS) {
        clearInterval(conferir);
        anotar(cfg, '[erro] vigia: o Tick reaberto não chegou a abrir — tento de novo');
        recuperar(cfg, motivo);
      }
    }, CHECAGEM_MS);
  }, ms);
}

function rodar(cfg) {
  gravar(cfg.pidVigia, { pid: process.pid, tick: cfg.pid });
  anotar(cfg, `vigia: vigiando o Tick (pid ${cfg.pid})`);
  const semSinalMs = cfg.semSinalMs ?? SEM_SINAL_MS;
  let desde = Date.now();
  let ultima = Date.now();
  const relogio = setInterval(() => {
    const agora = Date.now();
    if (agora - ultima > SALTO_MS) {
      anotar(cfg, `vigia: o PC voltou da suspensão (${Math.round((agora - ultima) / 60_000)} min parado)`);
      desde = agora;
    }
    ultima = agora;
    const deleMarca = lerMarca(cfg) === String(cfg.pid);
    if (!estaVivo(cfg.pid)) {
      clearInterval(relogio);
      if (!deleMarca) {
        anotar(cfg, 'vigia: o Tick saiu normalmente — encerrando');
        return sair();
      }
      const sinal = lerSinal(cfg);
      const fazia = Number.isFinite(sinal) ? ` (último sinal de vida há ${Math.round((agora - sinal) / 1000)} s)` : '';
      anotar(cfg, `[erro] vigia: o Tick fechou sem passar pela saída normal${fazia}`);
      return recuperar(cfg, 'caiu');
    }
    if (deleMarca && travado(lerSinal(cfg), desde, agora, semSinalMs)) {
      clearInterval(relogio);
      anotar(cfg, `[erro] vigia: o Tick não dá sinal de vida há ${Math.round(semSinalMs / 60_000)} min (travado) — fechando para reabrir`);
      try { process.kill(cfg.pid); } catch { /* já pode ter saído */ }
      return recuperar(cfg, 'travou');
    }
  }, cfg.checagemMs ?? CHECAGEM_MS);
}

if (require.main === module) rodar(JSON.parse(process.argv[2]));

module.exports = { esperaParaReabrir, travado, ESPERAS_MS, SEM_SINAL_MS };
