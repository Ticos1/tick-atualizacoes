const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('tick', {
  acao: (tipo, n, valor) => ipcRenderer.send('tick:acao', tipo, n, valor),
  aoEstado: (fn) => {
    ipcRenderer.on('tick:estado', (_ev, estado) => fn(estado));
    ipcRenderer.send('tick:pedir-estado');
  },
  aoRenomear: (fn) => ipcRenderer.on('tick:renomear', () => fn()),
  config: () => ipcRenderer.invoke('tick:config'),
  memoria: () => ipcRenderer.invoke('tick:memoria'),
  novidades: () => ipcRenderer.invoke('tick:novidades'),
  reiniciar: () => ipcRenderer.send('tick:reiniciar'),
  definir: (chave, n, valor) => ipcRenderer.invoke('tick:config-definir', chave, n, valor),
  huntContas: () => ipcRenderer.invoke('tick:hunt-contas'),
  huntAnalisar: (n) => ipcRenderer.invoke('tick:hunt-analisar', n),
  depotContas: () => ipcRenderer.invoke('tick:hunt-contas'),
  depotPrevia: (n) => ipcRenderer.invoke('tick:depot-previa', n),
  depotConfirmar: (n, token, manter) => ipcRenderer.invoke('tick:depot-confirmar', n, token, manter),
  depotSituacao: (n) => ipcRenderer.invoke('tick:depot-situacao', n),
  depotParar: (n) => ipcRenderer.invoke('tick:depot-parar', n),
});
