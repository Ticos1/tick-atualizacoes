const contas = document.getElementById('contas');
const abrir = document.getElementById('abrir');
const grade = document.getElementById('grade');

abrir.addEventListener('click', () => window.tick.acao('abrir-conta'));
grade.addEventListener('click', () => window.tick.acao('grade'));
document.getElementById('config').addEventListener('click', () => window.tick.acao('config'));
document.getElementById('modos').addEventListener('click', () => window.tick.acao('modos'));
document.getElementById('lives').addEventListener('click', () => window.tick.acao('lives'));
const meta = document.getElementById('meta');
meta.addEventListener('click', () => window.tick.acao('meta'));
meta.addEventListener('contextmenu', (ev) => { ev.preventDefault(); window.tick.acao('meta-conta'); });
document.getElementById('hunts').addEventListener('click', () => window.tick.acao('hunts'));
document.getElementById('depot').addEventListener('click', () => window.tick.acao('depot'));
document.getElementById('mais').addEventListener('click', () => window.tick.acao('ferramentas'));

// A barra recolhida: os botões de ferramenta viram o menu do "…". Recolhe sozinha quando a janela é baixa
// demais para todos, e também à mão, pela setinha de baixo (lembrada nesta barra).
const CHAVE_RECOLHIDA = 'tick.lateralRecolhida';
const recolher = document.getElementById('recolher');
let recolhidaAMao = false;
try { recolhidaAMao = localStorage.getItem(CHAVE_RECOLHIDA) === '1'; } catch { /* sem memória, começa aberta */ }

function ajustarLateral() {
  document.body.classList.remove('recolhida');
  const naoCabe = document.body.scrollHeight > document.body.clientHeight + 1;
  const recolhida = recolhidaAMao || naoCabe;
  document.body.classList.toggle('recolhida', recolhida);
  document.getElementById('mais').hidden = !recolhida;
  // Sem espaço, abrir à mão não adiantaria: a setinha só aparece quando a escolha é da pessoa.
  recolher.hidden = naoCabe && !recolhidaAMao;
  recolher.setAttribute('aria-expanded', String(!recolhida));
  recolher.title = recolhida ? 'Mostrar os botões da barra' : 'Recolher os botões da barra';
}

recolher.addEventListener('click', () => {
  recolhidaAMao = !recolhidaAMao;
  try { localStorage.setItem(CHAVE_RECOLHIDA, recolhidaAMao ? '1' : '0'); } catch { /* vale até fechar */ }
  ajustarLateral();
});
window.addEventListener('resize', ajustarLateral);

// Arrastar um botão sobre outro muda a ordem das contas.
let arrastada = null;

window.tick.aoEstado((estado) => {
  contas.replaceChildren(...estado.contas.map((c) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.title = c.ligada
      ? `${c.nome}: clique para ver só ela, botão direito para opções, arraste para mudar a ordem`
      : `${c.nome} desligada: clique para ligar`;
    b.setAttribute('aria-label', c.ligada ? c.nome : `Ligar ${c.nome}`);
    b.textContent = c.nome.slice(0, 3).toUpperCase();
    b.classList.toggle('ativa', estado.focada === c.n);
    b.classList.toggle('desligada', !c.ligada);
    b.draggable = true;
    b.addEventListener('dragstart', (ev) => { arrastada = c.n; ev.dataTransfer.effectAllowed = 'move'; });
    b.addEventListener('dragend', () => { arrastada = null; b.classList.remove('alvo'); });
    b.addEventListener('dragover', (ev) => {
      if (arrastada == null || arrastada === c.n) return;
      ev.preventDefault();
      b.classList.add('alvo');
    });
    b.addEventListener('dragleave', () => b.classList.remove('alvo'));
    b.addEventListener('drop', (ev) => {
      ev.preventDefault();
      if (arrastada != null) window.tick.acao('mover', arrastada, c.n);
    });
    if (c.ligada) {
      const ponto = document.createElement('span');
      ponto.className = `ponto ${c.situacao}`;
      b.append(ponto);
    }
    b.addEventListener('click', () => window.tick.acao(c.ligada ? 'focar' : 'ligar', c.n));
    b.addEventListener('contextmenu', (ev) => { ev.preventDefault(); window.tick.acao('menu-lateral', c.n); });
    return b;
  }));
  document.getElementById('modo-letra').textContent = { cena: 'C', economia: 'E', ultra: 'U' }[estado.modoJogo] ?? 'C';
  document.getElementById('lives').classList.toggle('ativa', !!estado.liveAberta);
  abrir.hidden = !estado.podeAbrir;
  grade.hidden = estado.focada == null;
  document.getElementById('mais').classList.toggle('ativa', !!estado.liveAberta);
  ajustarLateral();
});

ajustarLateral();
