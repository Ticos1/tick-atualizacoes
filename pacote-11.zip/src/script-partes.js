// @ts-check
// O script de Auto Compra é escrito em partes (vendor/autocompra/NN-nome.js) e vai para quem usa como um arquivo
// só, vendor/pokeidle-autocompra.user.js: é o que as edições já instaladas esperam encontrar no pacote.
const fs = require('node:fs');
const path = require('node:path');

const PASTA_PARTES = path.join(__dirname, '..', 'vendor', 'autocompra');
const SCRIPT_JUNTO = path.join(__dirname, '..', 'vendor', 'pokeidle-autocompra.user.js');

/** As partes, na ordem do número no começo do nome. */
function partes(pasta = PASTA_PARTES) {
  return fs.readdirSync(pasta).filter((f) => /^\d\d-[\w-]+\.js$/.test(f)).sort();
}

/**
 * O script inteiro: as partes coladas na ordem, com as quebras de linha do Git normalizadas.
 * @param {string} [pasta]
 * @returns {string}
 */
function montarScript(pasta = PASTA_PARTES) {
  return partes(pasta).map((f) => fs.readFileSync(path.join(pasta, f), 'utf8').replace(/\r\n/g, '\n')).join('');
}

/**
 * O texto do script para a página: no projeto, montado das partes (editar uma parte já vale no F5);
 * fora dele, o arquivo único.
 * @param {string} arquivo o arquivo único que vale para esta cópia do Tick
 * @returns {string}
 */
function lerScript(arquivo) {
  if (path.resolve(arquivo) === path.resolve(SCRIPT_JUNTO) && fs.existsSync(PASTA_PARTES)) return montarScript();
  return fs.readFileSync(arquivo, 'utf8');
}

module.exports = { PASTA_PARTES, SCRIPT_JUNTO, partes, montarScript, lerScript };
