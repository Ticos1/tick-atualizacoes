// @ts-check
// Abre um pacote .crx da Chrome Web Store, sem dependências, para as edições do Tick que não levam as extensões junto.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');

// O ID da loja é parte do manifesto de cada extensão: é sempre o mesmo, em qualquer versão.
const DA_LOJA = {
  hunt: 'mhnplloljgchpfpcpbhmcokmnefodjnh',
  'auto-hunt': 'njdfockaafkfolaocfkocpcieieokndb',
  'rotom-sniper': 'olccbpdjdkbfgondiiaicmlifhbcggmk',
};

const TAMANHO_MAX_ARQUIVO = 64 * 1024 * 1024;

/** O ID da extensão sai da chave do manifesto: um pacote de outra extensão não passa por este. */
function idDaChave(chaveBase64) {
  const hash = crypto.createHash('sha256').update(Buffer.from(chaveBase64, 'base64')).digest('hex').slice(0, 32);
  return [...hash].map((c) => String.fromCharCode(97 + parseInt(c, 16))).join('');
}

/** Os campos de uma mensagem protobuf: só inteiros e blocos, que é o que o cabeçalho do CRX3 usa. */
function camposProto(b) {
  const campos = [];
  let i = 0;
  const varint = () => {
    let v = 0;
    let fator = 1;
    for (;;) {
      if (i >= b.length) throw new Error('cabeçalho do pacote incompleto');
      const c = b[i++];
      v += (c & 0x7f) * fator;
      if (!(c & 0x80)) return v;
      fator *= 128;
    }
  };
  while (i < b.length) {
    const chave = varint();
    const tipo = chave % 8;
    const numero = Math.floor(chave / 8);
    if (tipo === 0) campos.push({ numero, valor: varint() });
    else if (tipo === 2) {
      const n = varint();
      if (i + n > b.length) throw new Error('cabeçalho do pacote incompleto');
      campos.push({ numero, valor: b.subarray(i, i + n) });
      i += n;
    } else throw new Error('cabeçalho do pacote desconhecido');
  }
  return campos;
}

/**
 * Confere a assinatura oficial do CRX3: o pacote tem de estar assinado pela chave da extensão esperada, cujo
 * hash é o próprio ID. A loja tira a chave do manifesto, então é aqui, e não nele, que está a prova.
 */
function conferirAssinaturaCrx3(crx, idEsperado) {
  if (crx.length < 12 || crx.toString('latin1', 0, 4) !== 'Cr24' || crx.readUInt32LE(4) !== 3) throw new Error('o pacote não é CRX3');
  const tamanho = crx.readUInt32LE(8);
  const cabecalho = camposProto(crx.subarray(12, 12 + tamanho));
  const zip = crx.subarray(12 + tamanho);
  const assinados = cabecalho.find((c) => c.numero === 10000)?.valor;
  if (!assinados) throw new Error('o pacote não é assinado');
  const provas = cabecalho.filter((c) => c.numero === 2).map((c) => camposProto(c.valor));
  for (const prova of provas) {
    const chave = prova.find((c) => c.numero === 1)?.valor;
    const assinatura = prova.find((c) => c.numero === 2)?.valor;
    if (!chave || !assinatura || idDaChave(chave.toString('base64')) !== idEsperado) continue;
    const tamanhoAssinado = Buffer.alloc(4);
    tamanhoAssinado.writeUInt32LE(assinados.length);
    const v = crypto.createVerify('RSA-SHA256');
    v.update(Buffer.from('CRX3 SignedData\0', 'latin1'));
    v.update(tamanhoAssinado);
    v.update(assinados);
    v.update(zip);
    if (v.verify({ key: chave, format: 'der', type: 'spki' }, assinatura)) return;
    throw new Error('a assinatura do pacote não confere');
  }
  throw new Error('o pacote é de outra extensão');
}

const urlDaLoja = (id, versaoChrome) => 'https://clients2.google.com/service/update2/crx?response=redirect'
  + `&prodversion=${versaoChrome}&acceptformat=crx2,crx3&x=${encodeURIComponent(`id=${id}&uc`)}`;

/** Pergunta à loja qual é a versão atual, sem baixar o pacote. */
const urlDaChecagem = (id, versaoChrome) => 'https://clients2.google.com/service/update2/crx?response=updatecheck'
  + `&prodversion=${versaoChrome}&acceptformat=crx2,crx3&x=${encodeURIComponent(`id=${id}&uc`)}`;

/** A versão na resposta da loja. `null` se ela não informou nenhuma. */
function versaoDaResposta(xml) {
  return /<updatecheck\b[^>]*\bversion="(\d+(?:\.\d+)*)"/.exec(String(xml))?.[1] ?? null;
}

/** O .zip dentro do .crx: depois de "Cr24", da versão e do cabeçalho. */
function zipDoCrx(crx) {
  if (crx.length < 16 || crx.toString('latin1', 0, 4) !== 'Cr24') throw new Error('o arquivo não é um pacote de extensão');
  const versao = crx.readUInt32LE(4);
  if (versao === 3) return crx.subarray(12 + crx.readUInt32LE(8));
  if (versao === 2) return crx.subarray(16 + crx.readUInt32LE(8) + crx.readUInt32LE(12));
  throw new Error(`versão de pacote desconhecida: ${versao}`);
}

/** Os arquivos do zip, pelo índice no fim dele. Nome que tente sair da pasta faz o pacote inteiro ser recusado. */
function lerZip(zip) {
  let fim = -1;
  for (let i = zip.length - 22; i >= 0 && i >= zip.length - 66_000; i--) {
    if (zip.readUInt32LE(i) === 0x06054b50) { fim = i; break; }
  }
  if (fim < 0) throw new Error('pacote incompleto');
  const total = zip.readUInt16LE(fim + 10);
  let p = zip.readUInt32LE(fim + 16);
  const arquivos = [];
  for (let k = 0; k < total; k++) {
    if (zip.readUInt32LE(p) !== 0x02014b50) throw new Error('pacote corrompido');
    const metodo = zip.readUInt16LE(p + 10);
    const comprimido = zip.readUInt32LE(p + 20);
    const tamanho = zip.readUInt32LE(p + 24);
    const lenNome = zip.readUInt16LE(p + 28);
    const lenExtra = zip.readUInt16LE(p + 30);
    const lenComentario = zip.readUInt16LE(p + 32);
    const local = zip.readUInt32LE(p + 42);
    const nome = zip.toString('utf8', p + 46, p + 46 + lenNome);
    p += 46 + lenNome + lenExtra + lenComentario;
    if (nome.endsWith('/')) continue;
    const partes = nome.split(/[\\/]/);
    if (path.isAbsolute(nome) || /^[a-zA-Z]:/.test(nome) || partes.includes('..')) throw new Error(`caminho recusado: ${nome}`);
    const inicio = local + 30 + zip.readUInt16LE(local + 26) + zip.readUInt16LE(local + 28);
    const bruto = zip.subarray(inicio, inicio + comprimido);
    let dados;
    if (metodo === 0) dados = bruto;
    else if (metodo === 8) dados = zlib.inflateRawSync(bruto, { maxOutputLength: TAMANHO_MAX_ARQUIVO });
    else throw new Error(`compressão desconhecida em ${nome}`);
    if (dados.length !== tamanho) throw new Error(`tamanho errado em ${nome}`);
    arquivos.push({ nome, partes, dados });
  }
  return arquivos;
}

/** Grava numa pasta temporária e só então troca: uma falha no meio não deixa uma extensão pela metade. */
function instalarCrx(crx, destino, idEsperado = null) {
  if (idEsperado) conferirAssinaturaCrx3(crx, idEsperado);
  const arquivos = lerZip(zipDoCrx(crx));
  if (!arquivos.some((a) => a.nome === 'manifest.json')) throw new Error('o pacote não tem manifest.json');
  const tmp = `${destino}.baixando`;
  fs.rmSync(tmp, { recursive: true, force: true });
  for (const a of arquivos) {
    if (a.partes[0] === '_metadata') continue; // o Electron recusa pastas que comecem com "_"
    const alvo = path.join(tmp, ...a.partes);
    fs.mkdirSync(path.dirname(alvo), { recursive: true });
    fs.writeFileSync(alvo, a.dados);
  }
  fs.rmSync(destino, { recursive: true, force: true });
  fs.renameSync(tmp, destino);
}

module.exports = { DA_LOJA, idDaChave, conferirAssinaturaCrx3, urlDaLoja, urlDaChecagem, versaoDaResposta, zipDoCrx, lerZip, instalarCrx };
