// Tick — contas isoladas do PokeIdle, lado a lado, com as extensões integradas.
const { app, BaseWindow, BrowserWindow, WebContentsView, Menu, Notification, Tray, crashReporter, dialog, ipcMain, nativeImage, safeStorage, screen, session, shell } = require('electron');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const logica = require('./logica');
const crx = require('./crx');
const atualizador = require('./atualizador');

const URL_JOGO = 'https://pokeidle.io/app';
// A cópia de trabalho do script, quando existe neste PC. Em outro PC vale a cópia que anda junto com o Tick.
const SCRIPT_TRABALHO = '';
const SCRIPT_JUNTO = path.join(__dirname, '..', 'vendor', 'pokeidle-autocompra.user.js');
let USERSCRIPT = fs.existsSync(SCRIPT_TRABALHO) ? SCRIPT_TRABALHO : SCRIPT_JUNTO;
const ASSISTENTE = 'http://127.0.0.1:5176/pokeidle';
const PASTA_EXT = path.join(__dirname, '..', 'vendor', 'extensions');
const ICONE = path.join(__dirname, '..', 'assets', 'tick.ico');
const ID_SCRIPT = 'autocompra';
const ID_ROTOM = 'rotom-sniper';
const LIGADAS_POR_PADRAO = new Set(['hunt', ID_ROTOM, ID_SCRIPT]);
// A Auto Hunt é baseada na /hunt: as duas mexem nas mesmas coisas da página, então só uma fica ativa.
const CONFLITOS = { hunt: ['auto-hunt'], 'auto-hunt': ['hunt'] };
const MAX_CONTAS = 4; // o limite permitido pelo jogo
const ALTURA_BARRA = 38;
const LARGURA_LATERAL = 60;
const PORTA_LOGIN = 5177;
const ESPERA_LOGIN_MS = 3 * 60_000;
const QUEDA_AVISO_MS = 60_000;      // uma queda só vira aviso se durar isto (o F5 e a reconexão do jogo são normais)
const NOCAUTE_INTERVALO_MS = 5 * 60_000; // no máximo um aviso de nocaute por conta neste intervalo
const TENTAR_DE_NOVO_MS = 30_000;   // sem internet: de quanto em quanto tempo tenta abrir o jogo
const TRAVADA_MS = 60_000;          // página sem responder por este tempo é reiniciada
const LIMITE_RECARGAS = 3;          // recargas por queda da página, dentro da janela abaixo; depois só avisa
const JANELA_RECARGAS_MS = 10 * 60_000;
const ESPERA_RESTAURAR_MS = 60_000; // devolver o login guardado: intervalo e tentativas, para não recarregar sem parar
const MAX_RESTAURAR = 3;
const GRAVAR_DADOS_MS = 30_000;     // o navegador grava o localStorage com atraso: isto reduz a perda num encerramento à força
const REGISTRO_MAX_BYTES = 1_000_000;
const PASSO_ZOOM = 0.1;
// O painel do modo economia foi feito para a tela inteira e corta o que não cabe. Em uma célula baixa, ele
// passa a rolar: o conteúdo mantém uma altura mínima, e em janela alta nada muda.
const CSS_ECONOMIA = `
  html.modo-economia .eco-painel { overflow-y: auto !important; }
  html.modo-economia .eco-corpo { flex: 1 0 620px !important; }
`;
const LARGURAS = [['Estreita', 0.75], ['Normal', 1], ['Larga', 1.5], ['Muito larga', 2]];
const MODOS = [['auto', 'Automático (2×2 com 4 contas)'], ['colunas', 'Colunas'], ['2x2', '2×2']];
const DIAG = process.argv.includes('--diag');
const TESTE_APP = process.argv.includes('--teste-app');
const PASTA_DIAG = path.join(__dirname, '..', 'diag');

// Os testes rodam em dados à parte, sem tocar nas contas de verdade.
const dadosTeste = process.argv.find((a) => a.startsWith('--dados='));
// Fora do AppData de propósito: o Windows redireciona o AppData de quem é aberto por um app da Loja, como o
// Claude Desktop. Lá, o Tick aberto pelo atalho e o aberto pelo Claude enxergariam contas diferentes.
// Empacotado, os dados ficam fora de dist/, que é apagada a cada novo pacote.
// A edição para outras pessoas pode ser aberta de qualquer pasta: os dados ficam no AppData de quem usa.
const EDICAO_AMIGO = fs.existsSync(path.join(__dirname, '..', 'amigo.json'));
const pastaDados = () => {
  if (EDICAO_AMIGO) return path.join(process.env.LOCALAPPDATA ?? app.getPath('appData'), 'Tick');
  return app.isPackaged
    ? path.resolve(path.dirname(process.execPath), '..', '..', 'dados')
    : path.join(__dirname, '..', 'dados');
};
app.setPath('userData', dadosTeste ? dadosTeste.slice('--dados='.length) : pastaDados());
// Arquivo de queda só neste PC, junto dos dados, para descobrir por que o Tick fechou. Nada é enviado.
app.setPath('crashDumps', path.join(app.getPath('userData'), 'Crashpad'));
crashReporter.start({ uploadToServer: false, compress: true });

// Sem o "Electron/x" e o "Tick/x" no fim: o app se apresenta como o Chromium que ele é.
app.userAgentFallback = app.userAgentFallback.replace(/\s(Electron|tick|Tick)\/\S+/g, '');
app.setAppUserModelId('Tick');

/** Mostra o motivo e fecha. A caixa só fica na tela depois de o app estar pronto: antes disso, ela some na hora. */
function avisarEFechar(titulo, texto) {
  app.whenReady().then(() => {
    dialog.showMessageBoxSync({ type: 'error', title: 'Tick', message: titulo, detail: texto, buttons: ['OK'] });
    app.exit(1);
  });
}

// Sem a pasta de dados, a trava abaixo falha e o app fecharia calado, como se o clique não tivesse feito nada.
let semPastaDeDados = false;
try {
  fs.mkdirSync(app.getPath('userData'), { recursive: true });
} catch (e) {
  semPastaDeDados = true;
  avisarEFechar('O Tick não conseguiu abrir', `Não consegui criar a pasta de dados:\n${app.getPath('userData')}\n\n${e.message}`);
}

// Um segundo clique só traz a janela para a frente. Mas, se o Tick aberto não responder, ele está travado ou
// invisível: em vez de fechar calado, diz o que fazer.
const marcaResposta = path.join(app.getPath('userData'), 'tick.respondeu');
const segundoClique = semPastaDeDados || !app.requestSingleInstanceLock();
if (segundoClique && !semPastaDeDados) {
  const inicio = Date.now();
  const respondeu = () => { try { return fs.statSync(marcaResposta).mtimeMs >= inicio - 2_000; } catch { return false; } };
  const conferir = () => {
    if (respondeu()) return app.exit(0);
    if (Date.now() - inicio < 5_000) return setTimeout(conferir, 250);
    return avisarEFechar('O Tick já está aberto, mas não responde', 'Abra o Gerenciador de Tarefas (Ctrl + Shift + Esc), finalize todos os itens "Tick" e abra de novo.');
  };
  conferir();
}
app.on('second-instance', () => {
  try { fs.writeFileSync(marcaResposta, ''); } catch { /* sem a marca, o segundo clique só avisa */ }
  if (janela) mostrarJanela();
});

let janela, lateral, janelaConfig, janelaHunts;
let focada = null;  // a conta que ocupa a janela sozinha (null = grade)
let cheia = false;  // a janela em tela cheia, sempre com uma conta focada
const contas = [];  // as contas ligadas: { n, ses, view, barra, extIds, menu, cockpit, status, ... }
const abrindo = new Set();

const dados = (...partes) => path.join(app.getPath('userData'), ...partes);

/** Grava em arquivo temporário e troca: uma queda no meio da gravação não corrompe o arquivo. */
function gravarSeguro(arquivo, conteudo) {
  fs.mkdirSync(path.dirname(arquivo), { recursive: true });
  fs.writeFileSync(`${arquivo}.tmp`, conteudo);
  fs.renameSync(`${arquivo}.tmp`, arquivo);
}

function registrar(txt) {
  if (!DIAG) return;
  fs.mkdirSync(PASTA_DIAG, { recursive: true });
  fs.appendFileSync(path.join(PASTA_DIAG, 'log.txt'), `${new Date().toISOString()} ${txt}\n`);
}

// ---------------------------------------------------------------- registro permanente
// Sempre ligado. Só guarda mensagens e, de URLs, origem e caminho: nunca sessão ou token.
const arquivoRegistro = () => dados('logs', 'tick.log');

function anotar(txt) {
  registrar(txt);
  try {
    fs.mkdirSync(path.dirname(arquivoRegistro()), { recursive: true });
    if (fs.existsSync(arquivoRegistro()) && fs.statSync(arquivoRegistro()).size > REGISTRO_MAX_BYTES) {
      fs.renameSync(arquivoRegistro(), `${arquivoRegistro()}.1`);
    }
    fs.appendFileSync(arquivoRegistro(), `${new Date().toISOString()} ${txt}\n`);
  } catch { /* sem registro, o app segue */ }
}

const registrarErro = (contexto, e) => anotar(`[erro] ${contexto}: ${e?.message ?? e}`);

function ultimosErros(quantos = 20) {
  try {
    return fs.readFileSync(arquivoRegistro(), 'utf8').trim().split('\n').filter((l) => l.includes('[erro]')).slice(-quantos).reverse();
  } catch { return []; }
}

// ---------------------------------------------------------------- vigia
// Processo separado que reabre o app se ele cair ou travar. A marca em dados/ é o que separa uma queda de uma
// saída normal; o sinal de vida, a cada 30 s, é o que separa um Tick travado de um vivo. E o Tick confere o
// vigia a cada minuto: se ele parar, inicia outro.
const marcaVigia = () => dados('tick.rodando');
const SINAL_MS = 30_000;
const CONFERIR_VIGIA_MS = 60_000;
const FUNCIONANDO_MS = 30 * 60_000;

const processoVivo = (pid) => {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return e.code === 'EPERM';
  }
};

function lancarVigia() {
  const filho = spawn(process.execPath, [path.join(__dirname, 'vigia.js'), JSON.stringify({
    pid: process.pid,
    marca: marcaVigia(),
    sinal: dados('tick.vivo'),
    pidVigia: dados('vigia.pid'),
    ultimo: dados('vigia-ultimo.json'),
    registro: arquivoRegistro(),
    historico: dados('vigia.json'),
    exe: process.execPath,
    args: process.argv.slice(1),
  })], { detached: true, stdio: 'ignore', windowsHide: true, env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' } });
  filho.on('error', (e) => registrarErro('vigia', e));
  filho.unref();
}

/** O vigia que vigia este Tick ainda está de pé? */
function vigiaVivo() {
  try {
    const v = JSON.parse(fs.readFileSync(dados('vigia.pid'), 'utf8'));
    return v.tick === process.pid && processoVivo(v.pid);
  } catch {
    return false;
  }
}

/** Reaberto pelo vigia: conta o porquê, e um aviso no Windows. */
function contarReabertura() {
  let ultimo = null;
  try { ultimo = JSON.parse(fs.readFileSync(dados('vigia-ultimo.json'), 'utf8')); } catch { return; }
  try { fs.rmSync(dados('vigia-ultimo.json')); } catch { /* segue */ }
  if (!ultimo || Date.now() - ultimo.em > 60 * 60_000) return;
  const oque = ultimo.motivo === 'travou' ? 'travou e foi fechado' : 'fechou sozinho';
  const vezes = ultimo.quedas > 1 ? ` Foram ${ultimo.quedas} vezes na última meia hora: se continuar, rode o Diagnóstico do Tick.` : '';
  anotar(`reaberto pelo vigia: o Tick ${oque}`);
  avisar('queda', 'O Tick foi reaberto', `O Tick ${oque}, e o vigia abriu de novo.${vezes}`);
}

function iniciarVigia() {
  if (!app.isPackaged || DIAG || TESTE_APP || !app.hasSingleInstanceLock()) return;
  if (fs.existsSync(marcaVigia())) {
    anotar('[erro] a última saída do Tick não foi normal: queda, falta de energia ou encerramento à força');
    anotarArquivosDeQueda();
    contarReabertura();
  }
  gravarSeguro(marcaVigia(), String(process.pid));
  const sinal = () => { try { gravarSeguro(dados('tick.vivo'), JSON.stringify({ pid: process.pid, em: Date.now() })); } catch { /* tenta no próximo */ } };
  sinal();
  setInterval(sinal, SINAL_MS);
  lancarVigia();
  setInterval(() => {
    if (!app.hasSingleInstanceLock() || vigiaVivo()) return;
    anotar('[erro] o vigia parou — iniciando outro');
    lancarVigia();
  }, CONFERIR_VIGIA_MS);
}

// ---------------------------------------------------------------- diagnóstico de quedas
// Os arquivos de queda ficam só neste PC, em dados/Crashpad, e nunca são enviados: podem ter pedaços da memória
// do app, inclusive login. Só os 5 mais novos ficam.
function anotarArquivosDeQueda() {
  const pasta = path.join(app.getPath('crashDumps'), 'reports');
  let arquivos = [];
  try {
    arquivos = fs.readdirSync(pasta).filter((f) => f.endsWith('.dmp'))
      .map((f) => ({ f, em: fs.statSync(path.join(pasta, f)).mtimeMs })).sort((a, b) => b.em - a.em);
  } catch { return; }
  const desde = (() => { try { return fs.statSync(marcaVigia()).mtimeMs; } catch { return 0; } })();
  for (const a of arquivos.filter((x) => x.em >= desde)) anotar(`[erro] arquivo de queda guardado: ${a.f}, de ${new Date(a.em).toISOString()}`);
  for (const a of arquivos.slice(5)) { try { fs.rmSync(path.join(pasta, a.f)); } catch { /* segue */ } }
}

function iniciarDiagnosticoDeQuedas() {
  // Vídeo, rede e utilitários do Electron: quando um deles cai várias vezes, o app inteiro fecha sem aviso.
  app.on('child-process-gone', (_ev, d) => {
    if (d.reason === 'clean-exit') return;
    anotar(`[erro] processo ${d.type}${d.name ? ` (${d.name})` : ''} parou: ${d.reason}, código ${d.exitCode}`);
  });
  setInterval(() => {
    const mb = Math.round(app.getAppMetrics().reduce((t, m) => t + (m.memory?.workingSetSize ?? 0), 0) / 1024);
    anotar(`Tick funcionando: ${contas.length} contas abertas, ${mb} MB de memória`);
  }, FUNCIONANDO_MS);
  app.on('will-quit', () => anotar('saindo: saída normal'));
}

function apagarMarcaVigia() {
  try {
    if (fs.readFileSync(marcaVigia(), 'utf8').trim() === String(process.pid)) fs.rmSync(marcaVigia());
  } catch { /* sem marca: nada a fazer */ }
}

app.on('will-quit', apagarMarcaVigia);

let janelaAberta = false;

/** Sem janela, um erro deixaria o app invisível: mostra o motivo e fecha, para o próximo clique funcionar. */
function falhaAoAbrir(e) {
  if (janelaAberta) return;
  avisarEFechar('O Tick não conseguiu abrir', `${e?.message ?? e}\n\nRegistro: ${arquivoRegistro()}`);
}

process.on('uncaughtException', (e) => { anotar(`[erro] processo: ${e?.stack ?? e}`); falhaAoAbrir(e); });
process.on('unhandledRejection', (e) => { anotar(`[erro] promessa: ${e?.stack ?? e}`); falhaAoAbrir(e); });
const VERSAO_AMIGO = EDICAO_AMIGO ? atualizador.versaoDe(path.join(__dirname, '..')) : 0;
if (!segundoClique) anotar(`abrindo: Tick ${app.getVersion()}${EDICAO_AMIGO ? `, edição ${VERSAO_AMIGO}` : ''}, Windows ${process.getSystemVersion()}`);

// ---------------------------------------------------------------- layout lembrado
const arquivoLayout = () => dados('layout.json');
let layout = logica.normalizarLayout(null, undefined, MAX_CONTAS);

function lerLayout() {
  let salvo = null;
  let antigas;
  try { salvo = JSON.parse(fs.readFileSync(arquivoLayout(), 'utf8')); } catch { /* primeira vez */ }
  try { antigas = JSON.parse(fs.readFileSync(dados('contas.json'), 'utf8')).abertas; } catch { /* já migrado */ }
  layout = logica.normalizarLayout(salvo, antigas, MAX_CONTAS);
}
const salvarLayout = () => gravarSeguro(arquivoLayout(), JSON.stringify(layout, null, 2));

const contaDoJogo = (wc) => contas.find((c) => c.view.webContents === wc);
const nomeDoNumero = (n) => layout.apelidos[n] ?? contas.find((c) => c.n === n)?.status.nick ?? layout.nomes[n] ?? `Conta ${n}`;
const nomeDe = (c) => nomeDoNumero(c.n);
const ordenadas = () => logica.ordenar(contas.map((c) => c.n), layout.ordem).map((n) => contas.find((c) => c.n === n));

function moverConta(n, alvo) {
  layout.ordem = logica.mover(logica.ordenar(layout.slots, layout.ordem), n, alvo);
  salvarLayout();
  dispor();
  publicar();
}

function definirPeso(conta, peso) {
  layout.pesos[conta.n] = peso;
  salvarLayout();
  dispor();
}

function definirModo(modo) {
  if (!MODOS.some(([m]) => m === modo)) return;
  layout.modo = modo;
  salvarLayout();
  dispor();
}

function definirApelido(n, texto) {
  const apelido = String(texto ?? '').trim().slice(0, 24);
  if (apelido) layout.apelidos[n] = apelido;
  else delete layout.apelidos[n]; // vazio volta para o nick do jogo
  salvarLayout();
  publicar();
}

const zoomDe = (n) => layout.zooms[n] ?? 1;

function definirZoom(conta, z) {
  const zoom = logica.limitarZoom(z);
  layout.zooms[conta.n] = zoom;
  salvarLayout();
  conta.view.webContents.setZoomFactor(zoom);
  publicar();
}

function definirMudo(conta, mudo) {
  layout.mudas[conta.n] = mudo;
  salvarLayout();
  conta.view.webContents.setAudioMuted(mudo);
  publicar();
}

let guardaJanela;
function guardarJanela() {
  clearTimeout(guardaJanela);
  guardaJanela = setTimeout(() => {
    if (!janela || janela.isDestroyed() || janela.isFullScreen() || janela.isMinimized()) return;
    layout.janela = { limites: janela.getNormalBounds(), maximizada: janela.isMaximized() };
    salvarLayout();
  }, 500);
}

/** A posição salva, se ela ainda cabe em alguma tela (o monitor pode ter sido desconectado). */
function limitesSalvos() {
  const l = layout.janela?.limites;
  if (!l) return { width: 1320, height: 860 };
  const visivel = screen.getAllDisplays().some(({ workArea: a }) => l.x < a.x + a.width - 80 && l.x + l.width > a.x + 80 && l.y >= a.y - 20 && l.y < a.y + a.height - 80);
  return visivel ? l : { width: l.width, height: l.height };
}

// ---------------------------------------------------------------- bandeja e abertura com o Windows
let bandeja;
let saindo = false;
app.on('before-quit', () => { saindo = true; });

function mostrarJanela() {
  if (janela.isMinimized()) janela.restore();
  janela.show();
  janela.focus();
}

const opcoesInicio = () => ({ path: process.execPath, args: app.isPackaged ? [] : [app.getAppPath()] });
const comWindows = () => app.getLoginItemSettings(opcoesInicio()).openAtLogin;

function definirComWindows(sim) {
  app.setLoginItemSettings({ ...opcoesInicio(), openAtLogin: sim });
  pintarBandeja();
}

function pintarBandeja() {
  bandeja.setContextMenu(Menu.buildFromTemplate([
    { label: 'Abrir o Tick', click: mostrarJanela },
    { label: 'Configurações', click: abrirConfig },
    { label: 'Abrir com o Windows', type: 'checkbox', checked: comWindows(), click: (i) => definirComWindows(i.checked) },
    { type: 'separator' },
    { label: 'Sair do Tick', click: () => app.quit() },
  ]));
}

function montarBandeja() {
  bandeja = new Tray(nativeImage.createFromPath(path.join(__dirname, '..', 'assets', 'tick.png')).resize({ width: 16, height: 16 }));
  bandeja.setToolTip('Tick');
  pintarBandeja();
  bandeja.on('click', mostrarJanela);
}

// ---------------------------------------------------------------- extensões por conta
// As que vêm com o Tick ficam em vendor/; as adicionadas pela pessoa, nos dados do app.
const pastaAdicionadas = () => dados('extensoes');
const arquivoEscolhas = () => dados('extensoes.json');

function lerManifesto(pasta) {
  return JSON.parse(fs.readFileSync(path.join(pasta, 'manifest.json'), 'utf8').replace(/^\uFEFF/, ''));
}

function catalogo() {
  const lista = [];
  const entrar = (novo) => {
    // A mesma extensão nas duas pastas (a de fábrica e a baixada da loja): vale a versão mais nova.
    const i = lista.findIndex((x) => x.id === novo.id);
    if (i < 0) lista.push(novo);
    else if (logica.compararVersoes(novo.versao, lista[i].versao) > 0) lista[i] = novo;
  };
  for (const raiz of [PASTA_EXT, pastaAdicionadas()]) {
    if (!fs.existsSync(raiz)) continue;
    for (const d of fs.readdirSync(raiz, { withFileTypes: true })) {
      if (!d.isDirectory()) continue;
      const pasta = path.join(raiz, d.name);
      try {
        const m = lerManifesto(pasta);
        entrar({ id: d.name, nome: m.name.startsWith('__MSG_') ? d.name : m.name, versao: m.version, pasta });
      } catch (e) { registrarErro(`extensão ${d.name}`, e); }
    }
  }
  return lista;
}

function lerEscolhas() {
  try { return JSON.parse(fs.readFileSync(arquivoEscolhas(), 'utf8')); } catch { return {}; }
}

function estaAtiva(n, id) {
  return lerEscolhas()[n]?.[id] ?? LIGADAS_POR_PADRAO.has(id);
}

function salvarEscolha(n, id, ativa) {
  const e = lerEscolhas();
  e[n] = { ...e[n], [id]: ativa };
  gravarSeguro(arquivoEscolhas(), JSON.stringify(e, null, 2));
}

// A edição para outras pessoas não leva as extensões de terceiros: cada PC baixa da Chrome Web Store, o canal
// oficial dos autores. Falhou? O Tick abre mesmo assim, e tenta de novo na próxima vez.
async function baixarExtensoesDaLoja() {
  const faltando = Object.entries(crx.DA_LOJA).filter(([id]) => !catalogo().some((x) => x.id === id));
  if (!EDICAO_AMIGO || !faltando.length) return;
  fs.mkdirSync(pastaAdicionadas(), { recursive: true });
  const falhas = [];
  for (const [id, daLoja] of faltando) {
    try {
      const r = await fetch(crx.urlDaLoja(daLoja, process.versions.chrome), { signal: AbortSignal.timeout(30_000) });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      crx.instalarCrx(Buffer.from(await r.arrayBuffer()), path.join(pastaAdicionadas(), id), daLoja);
      anotar(`extensão ${id} baixada da Chrome Web Store: ${lerManifesto(path.join(pastaAdicionadas(), id)).version}`);
    } catch (e) {
      registrarErro(`baixar extensão ${id}`, e);
      falhas.push(id);
    }
  }
  if (falhas.length) {
    dialog.showMessageBox({
      type: 'warning', title: 'Tick', message: 'Não consegui baixar todas as extensões.',
      detail: `Faltou: ${falhas.join(', ')}. O Tick segue sem elas. Confira a internet e abra o Tick de novo.`,
    });
  }
}

// A /hunt muda junto com o jogo, e a Melhor hunt decide pelo ranking dela. Só no Tick da casa.
const ATUALIZAR_SOZINHAS = ['hunt'];
const CHECAR_EXTENSOES_MS = 6 * 60 * 60_000;
const ENTRE_RECARGAS_MS = 5_000; // uma conta de cada vez

async function pedirNaLoja(url) {
  const r = await fetch(url, { signal: AbortSignal.timeout(30_000) });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r;
}

async function atualizarExtensao(id) {
  const atual = catalogo().find((x) => x.id === id);
  const daLoja = crx.DA_LOJA[id];
  const nova = crx.versaoDaResposta(await (await pedirNaLoja(crx.urlDaChecagem(daLoja, process.versions.chrome))).text());
  if (!nova || (atual && logica.compararVersoes(nova, atual.versao) <= 0)) return;
  const pacote = Buffer.from(await (await pedirNaLoja(crx.urlDaLoja(daLoja, process.versions.chrome))).arrayBuffer());
  crx.conferirAssinaturaCrx3(pacote, daLoja); // antes de tirar a versão em uso das contas
  // A extensão carregada guarda o manifesto antigo: sai das contas antes de os arquivos mudarem.
  const emUso = contas.filter((c) => c.extIds[id]);
  for (const c of emUso) {
    c.ses.extensions.removeExtension(c.extIds[id]);
    delete c.extIds[id];
  }
  try {
    fs.mkdirSync(pastaAdicionadas(), { recursive: true });
    crx.instalarCrx(pacote, path.join(pastaAdicionadas(), id), daLoja);
    anotar(`extensão ${id}: ${atual?.versao ?? 'nenhuma'} → ${nova}`);
  } finally {
    // Deu certo ou não, cada conta volta com a extensão que estiver na lista agora.
    for (const c of emUso) {
      if (!contas.includes(c)) continue;
      try {
        await carregarExtensao(c, catalogo().find((x) => x.id === id));
        recarregarConta(c);
      } catch (e) { registrarErro(`conta ${c.n}: extensão ${id}`, e); }
      await new Promise((ok) => setTimeout(ok, ENTRE_RECARGAS_MS));
    }
  }
}

async function atualizarExtensoes() {
  for (const id of ATUALIZAR_SOZINHAS) {
    try { await atualizarExtensao(id); } catch (e) { registrarErro(`atualizar extensão ${id}`, e); }
  }
}

function iniciarAtualizacaoDeExtensoes() {
  if (EDICAO_AMIGO || dadosTeste || TESTE_APP) return;
  setTimeout(atualizarExtensoes, 60_000);
  setInterval(atualizarExtensoes, CHECAR_EXTENSOES_MS);
}

// ---------------------------------------------------------------- atualização (só na edição para amigos)
// Cada commit vira uma edição: procurar de 15 em 15 minutos faz a versão nova chegar no mesmo dia.
const INTERVALO_ATUALIZACAO_MS = 15 * 60_000;
// Quem clicou em "Depois" é lembrado de novo, no máximo uma vez por hora.
const LEMBRAR_REINICIO_MS = 60 * 60_000;
let reinicioPedidoEm = 0;

/** A edição já baixada que espera o Tick abrir de novo, ou 0. Uma marcada como ruim não conta: ela não abriria. */
function edicaoEsperandoReinicio() {
  const raiz = path.join(app.getPath('userData'), 'atualizacao');
  const versao = atualizador.versaoDe(path.join(raiz, 'atual'));
  let ruins = [];
  try { ruins = JSON.parse(fs.readFileSync(path.join(raiz, 'ruins.json'), 'utf8')); } catch { /* nenhuma ruim */ }
  return versao > VERSAO_AMIGO && !ruins.includes(versao) ? versao : 0;
}

async function procurarAtualizacao() {
  try {
    const nova = await atualizador.conferir({ dados: app.getPath('userData'), versaoEmUso: VERSAO_AMIGO });
    if (nova) {
      anotar(`atualização: edição ${nova.versao} instalada`);
      // O script é lido a cada carga: já vale ao recarregar a conta. O resto vale ao reabrir o Tick.
      USERSCRIPT = path.join(nova.pasta, 'vendor', 'pokeidle-autocompra.user.js');
      avisar('sistema', 'Tick atualizado', 'Reinicie o Tick para usar a versão nova e ver as novidades.');
      pedirReinicio(nova.versao);
      return;
    }
  } catch (e) {
    registrarErro('atualização', e);
  }
  const esperando = edicaoEsperandoReinicio();
  if (esperando && Date.now() - reinicioPedidoEm >= LEMBRAR_REINICIO_MS) {
    anotar(`atualização: lembrando de reiniciar para a edição ${esperando}`);
    pedirReinicio(esperando);
  }
}

let telaReinicio = null;
ipcMain.on('tick:reiniciar', () => {
  app.relaunch();
  app.quit();
});

/** Versão nova instalada: ela só vale ao abrir de novo, e a tela de novidades aparece nessa hora. */
function pedirReinicio(versao) {
  reinicioPedidoEm = Date.now();
  if (telaReinicio && !telaReinicio.isDestroyed()) telaReinicio.close();
  const largura = 460;
  const altura = 230;
  const area = janela.getBounds();
  const tela = new BrowserWindow({
    parent: janela, width: largura, height: altura,
    x: Math.round(area.x + (area.width - largura) / 2), y: Math.round(area.y + (area.height - altura) / 2),
    frame: false, resizable: false, minimizable: false, maximizable: false, skipTaskbar: true, show: false,
    title: 'Tick atualizado', icon: ICONE, backgroundColor: '#171a2b',
    webPreferences: { preload: path.join(__dirname, 'preload-ui.js') },
  });
  telaReinicio = tela;
  tela.once('ready-to-show', () => { tela.show(); tela.focus(); });
  tela.loadFile(path.join(__dirname, 'atualizado.html'), { query: { versao: String(versao) } }).catch((e) => registrarErro('aviso de atualização', e));
}

let textoNovidades = '';
ipcMain.handle('tick:novidades', () => ({ versao: VERSAO_AMIGO, texto: textoNovidades }));

/** Na primeira abertura e a cada versão nova, uma vez: a tela do Tick com o texto da última atualização. */
function mostrarNovidades() {
  const dados = app.getPath('userData');
  textoNovidades = atualizador.novidadesParaMostrar(dados, path.join(__dirname, '..'), VERSAO_AMIGO) ?? '';
  if (!textoNovidades) return;
  anotar(`novidades mostradas: edição ${VERSAO_AMIGO}`);
  const largura = 520;
  const altura = 440;
  const area = janela.getBounds();
  const tela = new BrowserWindow({
    parent: janela, width: largura, height: altura,
    x: Math.round(area.x + (area.width - largura) / 2), y: Math.round(area.y + (area.height - altura) / 2),
    frame: false, resizable: false, minimizable: false, maximizable: false, skipTaskbar: true, show: false,
    title: 'Novidades do Tick', icon: ICONE, backgroundColor: '#171a2b',
    webPreferences: { preload: path.join(__dirname, 'preload-ui.js') },
  });
  tela.once('ready-to-show', () => { tela.show(); tela.focus(); });
  tela.loadFile(path.join(__dirname, 'novidades.html')).catch((e) => registrarErro('novidades', e));
}

function iniciarAtualizacao() {
  if (!EDICAO_AMIGO) return;
  mostrarNovidades();
  atualizador.confirmar(app.getPath('userData'), VERSAO_AMIGO);
  setTimeout(procurarAtualizacao, 30_000);
  setInterval(procurarAtualizacao, INTERVALO_ATUALIZACAO_MS);
}

async function carregarExtensao(conta, item) {
  // Ao religar uma conta, a sessão ainda pode ter a extensão carregada: reaproveita.
  const ja = conta.ses.extensions.getAllExtensions().find((x) => path.resolve(x.path) === path.resolve(item.pasta));
  const ext = ja ?? await conta.ses.extensions.loadExtension(item.pasta);
  conta.extIds[item.id] = ext.id;
  registrar(`conta ${conta.n}: extensão "${ext.name}" ${ext.version} carregada`);
}

async function aplicarExtensao(conta, id, ativa) {
  if (id !== ID_SCRIPT) {
    if (ativa) {
      await carregarExtensao(conta, catalogo().find((x) => x.id === id));
    } else if (conta.extIds[id]) {
      conta.ses.extensions.removeExtension(conta.extIds[id]);
      delete conta.extIds[id];
      if (id === ID_ROTOM && conta.cockpit && !conta.cockpit.isDestroyed()) conta.cockpit.close();
    }
  } else if (!ativa) {
    conta.menu = [];
  }
  salvarEscolha(conta.n, id, ativa);
  registrar(`conta ${conta.n}: ${id} ${ativa ? 'ativada' : 'desativada'}`);
}

/** Vale para conta ligada ou desligada; a desligada só guarda a escolha para quando abrir. */
async function definirExtensao(n, id, ativa) {
  const conta = contas.find((c) => c.n === n);
  const aplicar = (qual, valor) => (conta ? aplicarExtensao(conta, qual, valor) : salvarEscolha(n, qual, valor));
  if (ativa) {
    for (const outra of CONFLITOS[id] ?? []) {
      if (estaAtiva(n, outra)) await aplicar(outra, false);
    }
  }
  await aplicar(id, ativa);
  publicar();
  if (conta) recarregarConta(conta); // extensão só entra ou sai da página numa carga nova
}

function avisoAutoHunt(n) {
  dialog.showMessageBox(janela, {
    type: 'info', title: 'Tick', message: `Auto Hunt ativada na ${nomeDoNumero(n)}`,
    detail: 'A /hunt foi desativada nesta conta, porque as duas não funcionam juntas.\n\n'
      + 'A Auto Hunt também troca de hunt e compra itens. Se for ligá-la no jogo, deixe "Auto Compra" e "Melhor hunt" desligadas, para não comprar nem trocar em dobro.',
  });
}

async function marcarNoMenu(conta, item, ativa) {
  await definirExtensao(conta.n, item.id, ativa);
  if (ativa && item.id === 'auto-hunt') avisoAutoHunt(conta.n);
}

// Copia a pasta para os dados do app, carrega e só então registra: pasta quebrada não entra na lista.
async function adicionarExtensao(conta, origem) {
  const manifesto = lerManifesto(origem);
  if (!manifesto.name || !manifesto.manifest_version) throw new Error('o manifest.json não tem nome ou versão');
  const id = manifesto.name.toLowerCase().normalize('NFD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'extensao';
  if (catalogo().some((x) => x.id === id) || id === ID_SCRIPT) throw new Error('essa extensão já está na lista');
  const destino = path.join(pastaAdicionadas(), id);
  fs.cpSync(origem, destino, { recursive: true, filter: (o) => path.basename(o) !== '_metadata' });
  try {
    await carregarExtensao(conta, { id, pasta: destino });
  } catch (e) {
    fs.rmSync(destino, { recursive: true, force: true });
    throw e;
  }
  salvarEscolha(conta.n, id, true);
  recarregarConta(conta);
  return manifesto.name;
}

async function escolherExtensao(conta) {
  const { canceled, filePaths } = await dialog.showOpenDialog(janela, {
    title: 'Escolha a pasta da extensão (a que tem o manifest.json)', properties: ['openDirectory'],
  });
  if (canceled) return;
  try {
    const manifesto = lerManifesto(filePaths[0]);
    const { response } = await dialog.showMessageBox(janela, {
      type: 'warning', title: 'Tick', buttons: ['Adicionar', 'Cancelar'], defaultId: 1, cancelId: 1,
      message: `Adicionar "${manifesto.name}" à ${nomeDe(conta)}?`,
      detail: 'A extensão vai poder agir na sua conta dentro do jogo. Use só extensões em que você confia.',
    });
    if (response !== 0) return;
    const nome = await adicionarExtensao(conta, filePaths[0]);
    dialog.showMessageBox(janela, { type: 'info', title: 'Tick', message: `"${nome}" ativada na ${nomeDe(conta)}.`, detail: 'Nas outras contas ela começa desativada.' });
  } catch (e) {
    registrarErro('adicionar extensão', e);
    dialog.showMessageBox(janela, { type: 'error', title: 'Tick', message: 'Não consegui adicionar a extensão.', detail: e.code === 'ENOENT' ? 'Essa pasta não tem um manifest.json.' : e.message });
  }
}

// ---------------------------------------------------------------- login lembrado
// O jogo apaga a sessão salva em qualquer resposta ruim do servidor, até num erro passageiro. O Tick guarda
// uma cópia criptografada pelo Windows e a devolve quando ela some. Se o token venceu de verdade, o próprio
// jogo pede login de novo. A criptografia é assíncrona, mas a página pede a cópia de forma síncrona antes de
// carregar: por isso as sessões ficam abertas em memória, e o disco só tem a versão cifrada.
const arquivoSessoes = () => dados('sessoes.json');
const sessoes = new Map();
let cifradas = {};
let cofreDisponivel = false;
let filaCofre = Promise.resolve();

const gravarCofre = () => gravarSeguro(arquivoSessoes(), JSON.stringify(cifradas));

async function abrirCofre() {
  cofreDisponivel = await safeStorage.isAsyncEncryptionAvailable();
  if (!cofreDisponivel) return registrarErro('cofre', 'criptografia indisponível: o login não será lembrado');
  try { cifradas = JSON.parse(fs.readFileSync(arquivoSessoes(), 'utf8')); } catch { cifradas = {}; }
  let mudou = false;
  for (const [n, texto] of Object.entries(cifradas)) {
    try {
      const { result, shouldReEncrypt } = await safeStorage.decryptStringAsync(Buffer.from(texto, 'base64'));
      sessoes.set(Number(n), result);
      if (shouldReEncrypt) {
        cifradas[n] = (await safeStorage.encryptStringAsync(result)).toString('base64');
        mudou = true;
      }
    } catch (e) { registrarErro(`cofre conta ${n}`, e); }
  }
  if (mudou) gravarCofre();
}

function guardarSessao(n, sessao) {
  if (!cofreDisponivel || sessoes.get(n) === sessao) return filaCofre;
  try {
    const s = JSON.parse(sessao);
    if (!s?.nick || !s?.token) return filaCofre;
  } catch { return filaCofre; }
  sessoes.set(n, sessao);
  filaCofre = filaCofre.then(async () => {
    cifradas[n] = (await safeStorage.encryptStringAsync(sessao)).toString('base64');
    gravarCofre();
  }).catch((e) => registrarErro('cofre', e));
  return filaCofre;
}

function esquecerSessao(n) {
  sessoes.delete(n);
  filaCofre = filaCofre.then(() => {
    delete cifradas[n];
    gravarCofre();
  }).catch((e) => registrarErro('cofre', e));
  return filaCofre;
}

async function confirmarEsquecer(conta) {
  const { response } = await dialog.showMessageBox(janela, {
    type: 'question', title: 'Tick', buttons: ['Esquecer', 'Cancelar'], defaultId: 1, cancelId: 1,
    message: `Esquecer o login da ${nomeDe(conta)}?`, detail: 'A conta volta para a tela de login do jogo. Nada muda na sua conta.',
  });
  if (response !== 0) return;
  await esquecerSessao(conta.n);
  await conta.view.webContents.executeJavaScript(`localStorage.removeItem('sessao'); localStorage.removeItem('nick');`);
  conta.status = { ...conta.status, nick: undefined, nivel: undefined, ouro: undefined };
  recarregarConta(conta);
  registrar(`login: conta ${conta.n} esquecida`);
}

// A conta caiu na tela de login, mas há um login guardado: devolve e recarrega. O limite evita recarregar
// sem parar quando o login venceu de verdade; nesse caso, o jogo continua pedindo login.
function restaurarLogin(conta) {
  if (recepcao?.conta === conta || !sessoes.has(conta.n)) return;
  conta.restauracoes ??= 0;
  if (conta.restauracoes >= MAX_RESTAURAR) return;
  if (Date.now() - (conta.ultimaRestauracao ?? 0) < ESPERA_RESTAURAR_MS) return;
  conta.restauracoes++;
  conta.ultimaRestauracao = Date.now();
  anotar(`conta ${conta.n}: sem login na página, devolvendo o login guardado (${conta.restauracoes}/${MAX_RESTAURAR})`);
  recarregarConta(conta);
}

// ---------------------------------------------------------------- estado mostrado na interface
function situacaoDe(c) {
  if (recepcao?.conta === c) return 'esperando';
  if (c.status.ws === 'conectada') return 'conectada';
  if (c.status.ws === 'outro') return 'outro';
  if (c.status.ws === 'semrede') return 'semrede';
  if (!c.status.temLogin) return 'semlogin';
  return c.status.ws === 'caiu' ? 'caiu' : 'carregando';
}

function publicar() {
  const estado = {
    contas: logica.ordenar(layout.slots, layout.ordem).map((n) => {
      const c = contas.find((x) => x.n === n);
      const base = { n, nome: nomeDoNumero(n), apelido: layout.apelidos[n] ?? null };
      if (!c) return { ...base, ligada: false, situacao: 'desligada' };
      return {
        ...base, ligada: true, nivel: c.status.nivel ?? null, ouro: c.status.ouro ?? null,
        situacao: situacaoDe(c), desde: c.desde ?? null, mudo: !!layout.mudas[n], shiny: c.status.shiny ?? null,
      };
    }),
    focada: focada?.n ?? null,
    cheia,
    podeAbrir: logica.proximaConta(layout.slots, MAX_CONTAS) != null,
    modoJogo: layout.modoJogo ?? 'cena',
    liveAberta: !!janelaLive && !janelaLive.isDestroyed(),
  };
  if (lateral && !lateral.webContents.isDestroyed()) lateral.webContents.send('tick:estado', estado);
  for (const c of contas) c.barra.webContents.send('tick:estado', estado);
  if (janelaConfig && !janelaConfig.isDestroyed()) janelaConfig.webContents.send('tick:estado', estado);
  if (janelaHunts && !janelaHunts.isDestroyed()) janelaHunts.webContents.send('tick:estado', estado);
}

ipcMain.on('tick:pedir-estado', publicar);

ipcMain.on('tick:acao', (ev, tipo, n, valor) => {
  const conta = contas.find((c) => c.n === n);
  if (tipo === 'abrir-conta') return abrirConta();
  if (tipo === 'ligar') return abrirConta(n);
  if (tipo === 'grade') return mostrar(null);
  if (tipo === 'config') return abrirConfig();
  if (tipo === 'modos') return menuModos().popup({ window: janela });
  if (tipo === 'lives') return menuLives().popup({ window: janela });
  if (tipo === 'meta') return abrirMeta();
  if (tipo === 'meta-conta') return escolherContaMeta();
  if (tipo === 'hunts') return abrirHunts();
  if (tipo === 'mover') return moverConta(n, valor);
  if (tipo === 'apelido') return definirApelido(n, valor);
  if (tipo === 'menu-lateral' && !conta) {
    return Menu.buildFromTemplate([{ label: `Ligar ${nomeDoNumero(n)}`, click: () => abrirConta(n) }]).popup({ window: janela });
  }
  if (!conta) return;
  if (tipo === 'focar') mostrar(focada === conta ? null : conta);
  else if (tipo === 'tela-cheia') alternarTelaCheia(conta);
  else if (tipo === 'recarregar') recarregarConta(conta);
  else if (tipo === 'mudo') definirMudo(conta, !layout.mudas[n]);
  else if (tipo === 'extensoes') menuExtensoes(conta).popup({ window: janela });
  else if (tipo === 'script') menuScript(conta).popup({ window: janela });
  else if (tipo === 'conta' || tipo === 'menu-lateral') menuConta(conta).popup({ window: janela });
});

// ---------------------------------------------------------------- meta do PvP
// Uma conta só lê o ranking sozinha. Qual é fica nos dados do Tick (layout.contaMeta), nunca no código, que é
// público. A análise e o painel são do script, na página da conta; aqui só se escolhe a conta e se abre.
const contaDoMeta = () => contas.find((c) => layout.contaMeta && c.status.nick === layout.contaMeta);

function marcarColetorDoMeta(conta) {
  const sim = !!layout.contaMeta && conta.status.nick === layout.contaMeta;
  conta.view.webContents.executeJavaScript(sim ? "localStorage.setItem('tick.metaColetor', '1')" : "localStorage.removeItem('tick.metaColetor')")
    .catch((e) => registrarErro('meta do PvP', e));
}

function escolherContaMeta(depois) {
  const opcoes = contas.filter((c) => c.status.nick);
  if (!opcoes.length) {
    return dialog.showMessageBox(janela, { type: 'info', message: 'Entre em uma conta primeiro', detail: 'O meta do PvP é lido do ranking do jogo por uma das suas contas.' });
  }
  Menu.buildFromTemplate([
    { label: 'Qual conta analisa o meta a cada 6 h?', enabled: false },
    ...opcoes.map((c) => ({
      label: c.status.nick,
      type: 'radio',
      checked: c.status.nick === layout.contaMeta,
      click: () => {
        layout.contaMeta = c.status.nick;
        salvarLayout();
        for (const x of contas) marcarColetorDoMeta(x);
        anotar('meta do PvP: conta escolhida');
        depois?.();
      },
    })),
  ]).popup({ window: janela });
}

function abrirMeta() {
  // O clique esquerdo nunca abre o menu de escolha, que é do botão direito: sem conta escolhida, fica com a
  // que está em foco ou com a primeira conectada.
  if (!layout.contaMeta) {
    const pronta = (c) => c && c.status.ws === 'conectada' && c.status.nick;
    const padrao = pronta(focada) ? focada : logica.ordenar(contas.map((c) => c.n), layout.ordem).map((n) => contas.find((c) => c.n === n)).find(pronta);
    if (!padrao) {
      return dialog.showMessageBox(janela, { type: 'info', message: 'Entre em uma conta primeiro', detail: 'O meta do PvP é lido do ranking do jogo por uma das suas contas.' });
    }
    layout.contaMeta = padrao.status.nick;
    salvarLayout();
    for (const x of contas) marcarColetorDoMeta(x);
    anotar('meta do PvP: conta escolhida sozinha');
  }
  const conta = contaDoMeta();
  if (!conta || conta.status.ws !== 'conectada') {
    return dialog.showMessageBox(janela, {
      type: 'info',
      message: `${layout.contaMeta} não está conectada`,
      detail: 'Ligue essa conta, ou clique com o botão direito no botão do meta para escolher outra.',
    });
  }
  const item = (conta.menu ?? []).find((m) => m.nome.startsWith('🏆'));
  if (!item) {
    return dialog.showMessageBox(janela, { type: 'info', message: 'Auto Compra ainda não está pronto nessa conta', detail: 'Espere a conta terminar de carregar, ou ligue o script de Auto Compra nela.' });
  }
  mostrar(conta);
  conta.view.webContents.send('tick:menu-click', item.id);
}

function avisar(tipo, titulo, corpo) {
  if (layout.avisos[tipo] === false) return;
  registrar(`aviso: ${titulo} — ${corpo}`);
  if (!Notification.isSupported()) return;
  const n = new Notification({ title: titulo, body: corpo, icon: ICONE });
  n.on('click', mostrarJanela);
  n.show();
}

// ---------------------------------------------------------------- pontes do script
ipcMain.on('tick:userscript', (ev) => {
  const conta = contaDoJogo(ev.sender);
  // Lido a cada carga: atualizar o script só pede um F5. Desativado, sobra só o status da conta.
  let script = '';
  if (!conta || estaAtiva(conta.n, ID_SCRIPT)) {
    try { script = fs.readFileSync(USERSCRIPT, 'utf8'); } catch (e) { registrarErro('script', e); }
  }
  ev.returnValue = `(() => {
    const P = window.__tickGM; delete window.__tickGM;
    const TICK_APP = true;
    // A rolagem. O jogo usa a roda sobre o palco para aproximar a câmera, mesmo no modo economia, em que a
    // cena está escondida; e, ao chamar preventDefault, também impede o Ctrl + roda de dar zoom.
    window.addEventListener('wheel', (ev) => {
      if (ev.ctrlKey) return ev.stopPropagation(); // Ctrl + roda é sempre o zoom da conta
      const alvo = ev.target;
      if (document.documentElement.classList.contains('modo-economia') && alvo.closest?.('.eco-painel')) ev.stopPropagation();
    }, { capture: true, passive: true });
    // Conta nova nasce com tudo desligado: o padrão do script compraria, venderia e trocaria de hunt
    // sozinho no primeiro login. Cada automação só liga quando a pessoa pedir, no menu da conta.
    if (!localStorage.getItem('tick.cfgSegura.v1')) {
      localStorage.setItem('autocompra.cfg.v1', JSON.stringify({
        ligado: false, garantirLigado: false, melhorHunt: false, triagem: false, vigia: false, historico: false,
      }));
      localStorage.setItem('tick.cfgSegura.v1', '1');
    }
    // Status da conta para a interface do Tick: só escuta o socket do jogo, nunca envia nada por ele.
    {
      const atual = { ws: 'carregando' };
      let pendente, ultimaSessao = null;
      const relatar = (mudou) => {
        const sessaoAgora = localStorage.getItem('sessao');
        // O jogo renova o token sozinho: a cópia do Tick acompanha.
        if (sessaoAgora && sessaoAgora !== ultimaSessao) { ultimaSessao = sessaoAgora; P.sessao(sessaoAgora); }
        let nick = null;
        try { nick = JSON.parse(sessaoAgora)?.nick ?? null; } catch {}
        Object.assign(atual, mudou, { temLogin: !!sessaoAgora, nick });
        if (!pendente) pendente = setTimeout(() => { pendente = null; P.status({ ...atual }); }, 1000);
      };
      const vistos = new WeakSet();
      let socket = null;
      const adotar = (ws) => {
        if (vistos.has(ws)) return;
        vistos.add(ws);
        socket = ws;
        if (ws.readyState === 1) relatar({ ws: 'conectada' });
        ws.addEventListener('open', () => { if (ws === socket) relatar({ ws: 'conectada' }); });
        // 4001: a conta abriu em outro lugar. O jogo não reconecta nesse caso, e o Tick também não insiste.
        ws.addEventListener('close', (ev) => { if (ws === socket) relatar({ ws: ev.code === 4001 ? 'outro' : 'caiu' }); });
        ws.addEventListener('message', (ev) => {
          if (typeof ev.data !== 'string' || !ev.data.includes('"')) return;
          let m;
          try { m = JSON.parse(ev.data); } catch { return; }
          const e = m.estado;
          if (e && typeof e === 'object') {
            const mudou = {};
            if (typeof e.gold === 'number') mudou.ouro = e.gold;
            if (typeof e.level === 'number') mudou.nivel = e.level;
            if (e.automation) {
              const r = e.automation.autoColecao;
              mudou.colecao = r && typeof r === 'object'
                ? { notaOn: !!r.nota?.on, notaMin: r.nota?.min ?? null, shinyOn: r.shiny?.on !== false }
                : { notaOn: !!e.automation.autoLockNota9, notaMin: e.automation.autoLockNotaMin ?? null, shinyOn: true };
              mudou.travados = e.automation.pokemonTravado?.length ?? 0;
            }
            for (const [rede, chave] of [['twitch', 'login'], ['kick', 'slug']]) {
              const b = e[rede];
              if (!b || typeof b !== 'object') continue;
              mudou[rede] = {
                vinculado: !!b.vinculado,
                bonus: b.bonus ?? {},
                canais: (Array.isArray(b.oficiais) ? b.oficiais : []).map((c) => ({ id: c[chave], nome: c.nome || c[chave], aoVivo: !!c.aoVivo, ativo: !!c.ativo, espectadores: c.espectadores ?? 0 })),
              };
            }
            if (Object.keys(mudou).length) relatar(mudou);
          }
          if (m.t === 'batalha' && Array.isArray(m.ev) && m.ev.some((x) => x?.k === 'centro' && x.motivo === 'morte')) P.nocaute();
        });
      };
      const WsOriginal = window.WebSocket;
      window.WebSocket = new Proxy(WsOriginal, {
        construct(alvo, args) {
          const ws = Reflect.construct(alvo, args);
          if (String(args[0] ?? '').includes('pokeidle.io')) adotar(ws);
          return ws;
        },
      });
      const enviarOriginal = WsOriginal.prototype.send;
      WsOriginal.prototype.send = function (dados) {
        if (String(this.url).includes('pokeidle.io')) adotar(this);
        return enviarOriginal.call(this, dados);
      };
      relatar({});
      setInterval(() => relatar({}), 30_000);
    }
    const cmds = new Map(); let n = 0, t;
    const sinc = () => { clearTimeout(t); t = setTimeout(() => P.menu([...cmds].map(([id, c]) => ({ id, nome: c.nome }))), 0); };
    P.aoClicarMenu((id) => cmds.get(id)?.fn());
    const GM_registerMenuCommand = (nome, fn) => { const id = ++n; cmds.set(id, { nome, fn }); sinc(); return id; };
    const GM_unregisterMenuCommand = (id) => { cmds.delete(id); sinc(); };
    const GM_xmlhttpRequest = (o) => {
      P.http({ method: o.method, url: o.url, headers: o.headers, data: o.data, timeout: o.timeout })
        .then((r) => o.onload?.(r), () => o.onerror?.());
    };
    ${script}
  })();
  //# sourceURL=tick://pokeidle-autocompra.user.js`;
});

// A cópia do login vai antes de qualquer script da página, para o jogo já a encontrar ao abrir.
ipcMain.on('tick:copia', (ev) => {
  const conta = contaDoJogo(ev.sender);
  ev.returnValue = conta ? sessoes.get(conta.n) ?? null : null;
});

// Só deixa sair para o Assistente: a página do jogo não ganha acesso geral à rede do PC.
ipcMain.handle('tick:http', async (_ev, p) => {
  if (p.method !== 'POST' || p.url !== ASSISTENTE) throw new Error('destino não permitido');
  const r = await fetch(p.url, {
    method: 'POST', headers: p.headers, body: p.data, signal: AbortSignal.timeout(p.timeout ?? 10_000),
  });
  registrar(`assistente: POST ${r.status}`);
  return { status: r.status };
});

ipcMain.on('tick:menu', (ev, lista) => {
  const conta = contaDoJogo(ev.sender);
  if (conta) conta.menu = lista;
});

ipcMain.on('tick:status', (ev, dadosStatus) => {
  const conta = contaDoJogo(ev.sender);
  if (conta) atualizarStatus(conta, dadosStatus);
});

/** A previsão de shiny vem da página do jogo: só texto curto e número passam para a interface do Tick. */
function limparShiny(s) {
  if (!s || typeof s !== 'object') return null;
  return {
    texto: String(s.texto ?? '').slice(0, 80),
    dica: String(s.dica ?? '').slice(0, 1500),
    escapou: Number.isInteger(s.escapou) && s.escapou >= 0 ? s.escapou : 0,
  };
}

function atualizarStatus(conta, novo) {
  const antes = conta.status.ws;
  if ('shiny' in novo) {
    const shiny = limparShiny(novo.shiny);
    if (shiny && shiny.escapou > (conta.status.shiny?.escapou ?? 0)) {
      avisar('shiny', 'Um shiny escapou', `${nomeDe(conta)} viu um shiny, e a bola não fechou.`);
    }
    novo = { ...novo, shiny };
  }
  conta.status = { ...conta.status, ...novo };
  const situacao = situacaoDe(conta);
  if (situacao !== conta.situacaoAnotada) {
    conta.situacaoAnotada = situacao;
    anotar(`conta ${conta.n}: ${situacao}`);
  }
  if (novo.nick && layout.nomes[conta.n] !== novo.nick) {
    layout.nomes[conta.n] = novo.nick; // para a conta ter nome mesmo desligada
    salvarLayout();
  }
  if (novo.temLogin === false) restaurarLogin(conta);
  if (novo.ws === 'conectada' && antes !== 'conectada') {
    marcarColetorDoMeta(conta);
    conta.restauracoes = 0;
    conta.desde = Date.now();
    conta.jaConectou = true;
    clearTimeout(conta.timerQueda);
    conta.timerQueda = null;
  }
  // Só um aviso que fala da conexão a encerra: a previsão de shiny, por exemplo, chega sem `ws`.
  if ('ws' in novo && novo.ws !== 'conectada' && antes === 'conectada') conta.desde = null;
  if (novo.ws === 'outro' && antes !== 'outro') {
    avisar('outro', 'Conta aberta em outro lugar', `${nomeDe(conta)} saiu do Tick porque foi aberta em outra aba ou aparelho. Feche lá e recarregue a conta.`);
  }
  if ((novo.ws === 'caiu' || novo.ws === 'semrede') && conta.jaConectou && !conta.timerQueda) {
    conta.timerQueda = setTimeout(() => {
      conta.timerQueda = null;
      if (conta.status.ws !== 'conectada' && contas.includes(conta)) avisar('queda', 'Conta desconectada', `${nomeDe(conta)} está fora do jogo há 1 minuto.`);
    }, QUEDA_AVISO_MS);
  }
  publicar();
}

ipcMain.on('tick:sessao', (ev, sessao) => {
  const conta = contaDoJogo(ev.sender);
  if (conta && typeof sessao === 'string') guardarSessao(conta.n, sessao);
});

ipcMain.on('tick:nocaute', (ev) => {
  const conta = contaDoJogo(ev.sender);
  if (!conta || Date.now() - (conta.ultimoNocaute ?? 0) < NOCAUTE_INTERVALO_MS) return;
  conta.ultimoNocaute = Date.now();
  avisar('nocaute', 'Time nocauteado', `${nomeDe(conta)} voltou ao Centro Pokémon.`);
});

// ---------------------------------------------------------------- login vindo do Brave
// O Google recusa login dentro do Tick. Então o login é feito no Brave, e o script de lá manda a sessão
// do jogo para cá. A porta só fica aberta enquanto uma conta espera, e só em 127.0.0.1. O cabeçalho próprio
// obriga o navegador a pedir licença (CORS), que nunca é dada: um site qualquer não consegue enviar nada.
let recepcao = null;

function pararRecepcao() {
  if (!recepcao) return;
  clearTimeout(recepcao.timer);
  recepcao.servidor.close();
  recepcao.servidor.closeAllConnections();
  recepcao = null;
  publicar();
}

function receberLogin(conta, comAviso = true) {
  pararRecepcao();
  const servidor = http.createServer((req, res) => {
    const responder = (status, corpo) => {
      res.writeHead(status, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(corpo));
    };
    if (req.method !== 'POST' || req.url !== '/sessao' || req.headers['x-tick'] !== 'sessao' || !logica.hostDeLoginValido(req.headers.host, PORTA_LOGIN)) return responder(403, { erro: 'recusado' });
    let bruto = '';
    req.setEncoding('utf8');
    req.on('data', (p) => { bruto += p; if (bruto.length > 64_000) req.destroy(); });
    req.on('end', () => {
      let corpo;
      try {
        corpo = JSON.parse(bruto);
        if (typeof corpo.sessao !== 'string' || typeof JSON.parse(corpo.sessao) !== 'object') throw new Error();
      } catch { return responder(400, { erro: 'sessão inválida' }); }
      responder(200, { conta: conta.n });
      pararRecepcao();
      aplicarSessao(conta, corpo).catch((e) => registrarErro('login', e));
    });
  });
  servidor.on('error', (e) => {
    registrarErro('login', e.code);
    dialog.showMessageBox(janela, { type: 'error', title: 'Tick', message: `Não consegui abrir a porta ${PORTA_LOGIN} para receber o login.` });
    recepcao = null;
    publicar();
  });
  servidor.listen(PORTA_LOGIN, '127.0.0.1');
  recepcao = { servidor, conta, timer: setTimeout(pararRecepcao, ESPERA_LOGIN_MS) };
  registrar(`login: conta ${conta.n} esperando sessão`);
  publicar();
  if (comAviso) {
    dialog.showMessageBox(janela, {
      type: 'info', title: 'Tick', message: `${nomeDe(conta)} esperando o login (3 minutos)`,
      detail: 'No navegador, entre no PokeIdle com a conta desejada e aperte F5.\n\nDepois abra o menu do Tampermonkey e clique em "Enviar esta conta ao Tick".',
    });
  }
}

async function aplicarSessao(conta, { sessao, nick }) {
  const wc = conta.view.webContents;
  conta.restauracoes = 0;
  try { await wc.loadURL(URL_JOGO); } catch { /* o jogo pode redirecionar no meio da carga */ }
  await wc.executeJavaScript(`localStorage.setItem('sessao', ${JSON.stringify(sessao)});
    ${typeof nick === 'string' ? `localStorage.setItem('nick', ${JSON.stringify(nick)});` : ''}`);
  guardarSessao(conta.n, sessao);
  wc.reload();
  registrar(`login: sessão aplicada na conta ${conta.n}`);
  dialog.showMessageBox(janela, { type: 'info', title: 'Tick', message: `Login recebido na ${nomeDe(conta)}.` });
}

// ---------------------------------------------------------------- recuperação de falhas
const naTelaDeErro = (wc) => wc.getURL().startsWith('file:');

function abrirJogo(conta) {
  clearTimeout(conta.timerRede);
  conta.view.webContents.loadURL(URL_JOGO).catch(() => { /* quem trata a falha é o did-fail-load */ });
}

/** Na tela de "sem conexão", recarregar repetiria a própria tela: abre o jogo de novo. */
function recarregarConta(conta) {
  const wc = conta.view.webContents;
  if (naTelaDeErro(wc) || wc.isCrashed()) abrirJogo(conta);
  else wc.reload();
}

function vigiarFalhas(conta) {
  const wc = conta.view.webContents;
  wc.on('did-fail-load', (_ev, codigo, descricao, url, principal) => {
    // -3 é carga interrompida por outra navegação: normal.
    if (!principal || codigo === -3 || url.startsWith('file:')) return;
    registrarErro(`conta ${conta.n}`, `não abriu ${logica.urlParaRegistro(url)}: ${descricao} (${codigo})`);
    atualizarStatus(conta, { ws: 'semrede' });
    // Navegar de dentro deste evento é ignorado: a tela de erro precisa esperar o evento terminar.
    setTimeout(() => {
      if (contas.includes(conta)) wc.loadFile(path.join(__dirname, 'erro.html')).catch((e) => registrarErro(`conta ${conta.n}`, e));
    }, 0);
  });
  // O Cloudflare responde 520/523 quando o servidor do jogo cai: a carga "dá certo", o
  // did-fail-load não dispara e a conta ficava parada na página de erro. Vai para a tela de
  // "sem conexão", que tenta de novo sozinha.
  wc.on('did-navigate', (_ev, url, codigo) => {
    if (!logica.servidorFora(url, codigo)) return;
    registrarErro(`conta ${conta.n}`, `servidor do jogo fora do ar (${codigo})`);
    atualizarStatus(conta, { ws: 'semrede' });
    setTimeout(() => {
      if (contas.includes(conta)) wc.loadFile(path.join(__dirname, 'erro.html')).catch((e) => registrarErro(`conta ${conta.n}`, e));
    }, 0);
  });
  wc.on('did-finish-load', () => {
    wc.setZoomFactor(zoomDe(conta.n)); // o zoom volta a cada carga
    clearTimeout(conta.timerRede);
    if (!naTelaDeErro(wc)) return;
    atualizarStatus(conta, { ws: 'semrede' });
    conta.timerRede = setTimeout(() => abrirJogo(conta), TENTAR_DE_NOVO_MS);
  });
  wc.on('render-process-gone', (_ev, { reason, exitCode }) => {
    if (reason === 'clean-exit' || !contas.includes(conta)) return;
    registrarErro(`conta ${conta.n}`, `a página parou: ${reason} (${exitCode})`);
    atualizarStatus(conta, { ws: 'caiu' });
    const agora = Date.now();
    conta.recargas = (conta.recargas ?? []).filter((t) => agora - t < JANELA_RECARGAS_MS);
    if (conta.recargas.length >= LIMITE_RECARGAS) {
      avisar('queda', 'Página parada', `${nomeDe(conta)} parou várias vezes seguidas. Recarregue a conta quando quiser tentar de novo.`);
      return;
    }
    conta.recargas.push(agora);
    conta.timerRede = setTimeout(() => abrirJogo(conta), 3_000);
  });
  wc.on('unresponsive', () => {
    clearTimeout(conta.timerTravada);
    conta.timerTravada = setTimeout(() => {
      registrarErro(`conta ${conta.n}`, 'página sem responder: reiniciando');
      wc.forcefullyCrashRenderer();
    }, TRAVADA_MS);
  });
  wc.on('responsive', () => clearTimeout(conta.timerTravada));
}

// ---------------------------------------------------------------- teclado
function teclas(conta, ev, input) {
  if (input.type !== 'keyDown') return;
  if (input.key === 'F11' && conta) { ev.preventDefault(); return alternarTelaCheia(conta); }
  if (input.key === 'F5' && conta) { ev.preventDefault(); return recarregarConta(conta); }
  if (!input.control || input.alt || input.meta) return;
  if (/^[1-9]$/.test(input.key)) {
    const alvo = ordenadas()[Number(input.key) - 1];
    if (alvo) { ev.preventDefault(); mostrar(alvo); }
    return;
  }
  if (input.key === '0') { ev.preventDefault(); return mostrar(null); }
  if (!conta) return;
  if (input.key === '=' || input.key === '+') { ev.preventDefault(); definirZoom(conta, zoomDe(conta.n) + PASSO_ZOOM); }
  else if (input.key === '-') { ev.preventDefault(); definirZoom(conta, zoomDe(conta.n) - PASSO_ZOOM); }
}

// ---------------------------------------------------------------- contas
async function abrirConta(pedida) {
  const n = pedida ?? logica.proximaConta(layout.slots, MAX_CONTAS);
  if (n == null || abrindo.has(n) || contas.some((c) => c.n === n)) return;
  abrindo.add(n);
  try {
    const ses = session.fromPartition(`persist:conta-${n}`);
    limitarPermissoes(ses);
    const conta = { n, ses, menu: [], extIds: {}, status: { ws: 'carregando', temLogin: true } };

    for (const item of catalogo()) {
      if (!estaAtiva(n, item.id)) continue;
      try { await carregarExtensao(conta, item); } catch (e) { registrarErro(`conta ${n}: extensão ${item.id}`, e); }
    }

    conta.barra = new WebContentsView({ webPreferences: { preload: path.join(__dirname, 'preload-ui.js') } });
    conta.barra.webContents.loadFile(path.join(__dirname, 'barra.html'), { query: { n: String(n) } });
    conta.view = new WebContentsView({
      webPreferences: {
        session: ses,
        preload: path.join(__dirname, 'preload-jogo.js'),
        backgroundThrottling: false,
      },
    });
    const wc = conta.view.webContents;
    wc.setAudioMuted(!!layout.mudas[n]);
    wc.setWindowOpenHandler(({ url }) => {
      const { hostname } = new URL(url);
      if (hostname === 'pokeidle.io') {
        return { action: 'allow', overrideBrowserWindowOptions: { width: 520, height: 700, autoHideMenuBar: true } };
      }
      abrirNoNavegador(url);
      return { action: 'deny' };
    });
    // O Google recusa login aqui dentro: o botão dele no jogo já leva direto ao caminho que funciona.
    const desviarGoogle = (ev, url) => {
      const { hostname, pathname } = new URL(url);
      if (hostname !== 'accounts.google.com' && !(hostname === 'pokeidle.io' && pathname.startsWith('/auth/google'))) return;
      ev.preventDefault();
      registrar(`login: botão do Google desviado na conta ${n}`);
      if (recepcao?.conta !== conta) receberLogin(conta);
    };
    wc.on('dom-ready', () => {
      if (!naTelaDeErro(wc)) wc.insertCSS(CSS_ECONOMIA).catch((e) => registrarErro(`conta ${n}: estilo`, e));
      // Quem ainda não recebeu o modo escolhido (a conta ligada depois da escolha) recebe uma vez, sem recarga em laço.
      if (layout.modoJogo && conta.modoConferido !== layout.modoJogo && !naTelaDeErro(wc)) {
        conta.modoConferido = layout.modoJogo;
        const querEco = layout.modoJogo === 'economia' ? '1' : '0';
        const querUltra = layout.modoJogo === 'ultra' ? '1' : '0';
        wc.executeJavaScript(`(localStorage.getItem('cfg-economia') ?? '0') === '${querEco}' && (localStorage.getItem('cfg-ultra') ?? '0') === '${querUltra}'`)
          .then((igual) => { if (!igual) aplicarModoNaConta(conta, layout.modoJogo); })
          .catch((e) => registrarErro(`modo da conta ${n}`, e));
      }
    });
    wc.on('will-navigate', desviarGoogle);
    wc.on('will-redirect', desviarGoogle);
    wc.on('before-input-event', (ev, input) => teclas(conta, ev, input));
    conta.barra.webContents.on('before-input-event', (ev, input) => teclas(conta, ev, input));
    // A roda do mouse pode disparar o evento mais de uma vez por clique: um passo a cada 100 ms.
    wc.on('zoom-changed', (_ev, direcao) => {
      if (Date.now() - (conta.ultimoZoom ?? 0) < 100) return;
      conta.ultimoZoom = Date.now();
      definirZoom(conta, zoomDe(n) + (direcao === 'in' ? PASSO_ZOOM : -PASSO_ZOOM));
    });
    // A página nova ainda não falou nada: até o script relatar, a conta está carregando.
    wc.on('did-start-navigation', (d) => {
      if (d.isMainFrame && !d.isSameDocument) atualizarStatus(conta, { ws: 'carregando' });
    });
    vigiarFalhas(conta);
    if (DIAG) {
      wc.on('console-message', ({ level, message }) => {
        if (level === 'error' || /autocompra|rotom|\/hunt|pih/i.test(message)) registrar(`conta ${n} [${level}] ${message.slice(0, 300)}`);
      });
      wc.on('did-navigate', (_e, url) => registrar(`conta ${n}: navegou para ${logica.urlParaRegistro(url)}`));
      wc.on('did-finish-load', () => { conta.timerDiag1 = setTimeout(() => diagnosticar(conta), 12_000); });
      conta.timerDiag2 = setInterval(() => diagnosticar(conta), 30_000);
    }

    contas.push(conta);
    if (!layout.slots.includes(n)) layout.slots.push(n);
    if (!layout.abertas.includes(n)) layout.abertas.push(n);
    salvarLayout();
    janela.contentView.addChildView(conta.barra);
    janela.contentView.addChildView(conta.view);
    dispor();
    publicar();
    wc.loadURL(URL_JOGO).catch(() => { /* quem trata a falha é o did-fail-load */ });
    return conta;
  } catch (e) {
    registrarErro(`abrir conta ${n}`, e);
    dialog.showMessageBox(janela, { type: 'error', title: 'Tick', message: `Não consegui ligar a Conta ${n}.`, detail: e.message });
  } finally {
    abrindo.delete(n);
  }
}

/** Desliga a conta sem esquecer o login: ela sai do jogo e fica na barra lateral para ligar de novo. */
function fecharConta(conta) {
  if (recepcao?.conta === conta) pararRecepcao();
  if (focada === conta) mostrar(null);
  for (const t of ['timerQueda', 'timerRede', 'timerTravada', 'timerDiag1']) clearTimeout(conta[t]);
  clearInterval(conta.timerDiag2);
  if (conta.cockpit && !conta.cockpit.isDestroyed()) conta.cockpit.close();
  conta.ses.flushStorageData();
  contas.splice(contas.indexOf(conta), 1);
  layout.abertas = layout.abertas.filter((n) => n !== conta.n);
  salvarLayout();
  janela.contentView.removeChildView(conta.barra);
  janela.contentView.removeChildView(conta.view);
  conta.view.webContents.close();
  conta.barra.webContents.close();
  dispor();
  publicar();
  anotar(`conta ${conta.n}: desligada`);
}

function dispor() {
  const { width, height } = janela.getContentBounds();
  const margem = cheia ? 0 : LARGURA_LATERAL;
  lateral.setVisible(!cheia);
  lateral.setBounds({ x: 0, y: 0, width: LARGURA_LATERAL, height });
  const visiveis = focada ? [focada] : ordenadas();
  for (const c of contas) {
    const visivel = visiveis.includes(c);
    c.barra.setVisible(visivel);
    c.view.setVisible(visivel); // continua rodando escondida: backgroundThrottling está desligado
  }
  for (const r of logica.retangulos(visiveis.map((c) => c.n), layout.modo, layout.pesos, margem, width, height)) {
    const c = contas.find((k) => k.n === r.n);
    c.barra.setBounds({ x: r.x, y: r.y, width: r.largura, height: ALTURA_BARRA });
    c.view.setBounds({ x: r.x, y: r.y + ALTURA_BARRA, width: r.largura, height: r.altura - ALTURA_BARRA });
  }
}

function mostrar(conta) {
  if (cheia) { cheia = false; janela.setFullScreen(false); }
  focada = conta;
  dispor();
  publicar();
  conta?.view.webContents.focus();
}

function alternarTelaCheia(conta) {
  const sair = cheia && focada === conta;
  focada = sair ? null : conta;
  cheia = !sair;
  janela.setFullScreen(cheia);
  dispor();
  publicar();
  if (cheia) conta.view.webContents.focus();
  registrar(`tela cheia: ${cheia ? `conta ${conta.n}` : 'nenhuma'}`);
}

// ---------------------------------------------------------------- limites para as páginas
function abrirNoNavegador(url) {
  if (logica.urlExternaSegura(url)) shell.openExternal(url);
  else anotar(`[erro] link recusado: ${logica.urlParaRegistro(url)}`);
}

// As páginas só recebem o que precisam: nada de câmera, microfone, localização ou notificações do site.
const PERMISSOES_DAS_PAGINAS = new Set(['fullscreen', 'clipboard-sanitized-write']);

function limitarPermissoes(ses) {
  ses.setPermissionRequestHandler((_wc, permissao, responder) => responder(PERMISSOES_DAS_PAGINAS.has(permissao)));
  ses.setPermissionCheckHandler((_wc, permissao) => PERMISSOES_DAS_PAGINAS.has(permissao));
}

// ---------------------------------------------------------------- modos do jogo, em todas as contas
const MODOS_JOGO = [['cena', 'Cena'], ['economia', 'Economia'], ['ultra', 'Ultra Economia']];
const ESPERA_RECARGA_MODO_MS = 1_500;

const scriptModoJogo = (modo) => `localStorage.setItem('cfg-economia', '${modo === 'economia' ? 1 : 0}'); localStorage.setItem('cfg-ultra', '${modo === 'ultra' ? 1 : 0}');`;

async function aplicarModoNaConta(conta, modo) {
  const wc = conta.view.webContents;
  if (naTelaDeErro(wc)) return;
  await wc.executeJavaScript(scriptModoJogo(modo));
  recarregarConta(conta);
}

/** O jogo lê o modo ao abrir. Recarrega uma conta por vez, para não derrubar todas juntas. */
async function definirModoJogo(modo) {
  if (!MODOS_JOGO.some(([m]) => m === modo)) return;
  layout.modoJogo = modo;
  salvarLayout();
  publicar();
  anotar(`modo do jogo: ${modo}`);
  for (const conta of ordenadas()) {
    try {
      await aplicarModoNaConta(conta, modo);
    } catch (e) {
      registrarErro(`modo da conta ${conta.n}`, e);
    }
    await new Promise((ok) => { setTimeout(ok, ESPERA_RECARGA_MODO_MS); });
  }
}

const menuModos = () => Menu.buildFromTemplate([
  { label: 'Modo de todas as contas', enabled: false },
  ...MODOS_JOGO.map(([m, nome]) => ({ label: nome, type: 'radio', checked: (layout.modoJogo ?? 'cena') === m, click: () => definirModoJogo(m) })),
]);

// ---------------------------------------------------------------- live em janela própria
// Os pontos do canal só caem para quem assiste com o vídeo rodando. Por isso é uma janela de verdade, uma só,
// com a conta da pessoa: sem som e, na Twitch, na menor qualidade. Nada aqui clica ou resgata nada sozinho.
let janelaLive = null;
let liveComSom = false;
const HOSTS_LIVE = /(^|\.)(twitch\.tv|kick\.com)$/;
const urlDaLive = (rede, id) => (rede === 'twitch' ? `https://www.twitch.tv/${encodeURIComponent(id)}` : `https://kick.com/${encodeURIComponent(id)}`);

function abrirLive(rede, id, nome) {
  const url = urlDaLive(rede, id);
  if (!janelaLive || janelaLive.isDestroyed()) {
    janelaLive = new BrowserWindow({
      width: 520, height: 340, minWidth: 320, minHeight: 200, title: 'Live', autoHideMenuBar: true, icon: ICONE, backgroundColor: '#000000',
      webPreferences: { partition: 'persist:lives', backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required' },
    });
    const wc = janelaLive.webContents;
    limitarPermissoes(wc.session);
    wc.setAudioMuted(!liveComSom);
    wc.setWindowOpenHandler(({ url: alvo }) => {
      abrirNoNavegador(alvo);
      return { action: 'deny' };
    });
    wc.on('will-navigate', (ev, alvo) => {
      let host = '';
      try { host = new URL(alvo).hostname; } catch { /* endereço inválido fica de fora */ }
      if (!HOSTS_LIVE.test(host)) { ev.preventDefault(); abrirNoNavegador(alvo); }
    });
    // A Twitch guarda a qualidade na própria página: na primeira carga, grava e recarrega uma vez.
    wc.on('did-finish-load', async () => {
      if (!wc.getURL().includes('twitch.tv')) return;
      const mudou = await wc.executeJavaScript(`(() => {
        const q = JSON.stringify({ default: '160p30' });
        if (localStorage.getItem('video-quality') === q) return false;
        localStorage.setItem('video-quality', q);
        return true;
      })()`).catch(() => false);
      if (mudou) wc.reload();
    });
    janelaLive.on('closed', () => { janelaLive = null; });
  }
  janelaLive.setTitle(`Live: ${nome}`);
  janelaLive.loadURL(url).catch((e) => registrarErro('live', e));
  janelaLive.show();
  anotar(`live aberta: ${rede}/${id}`);
}

function textoHoras(ms) {
  const min = Math.round(ms / 60_000);
  return min >= 60 ? `${Math.floor(min / 60)}h${String(min % 60).padStart(2, '0')}` : `${min} min`;
}

function menuLives() {
  const canais = new Map();
  const agora = Date.now();
  const situacao = [];
  for (const c of ordenadas()) {
    const horas = [];
    for (const [rede, rotulo] of [['twitch', 'Twitch'], ['kick', 'Kick']]) {
      const b = c.status[rede];
      if (!b) continue;
      for (const k of b.canais) if (k.aoVivo && k.ativo) canais.set(`${rede}/${k.id}`, { ...k, rede, rotulo });
      for (const [tipo, ate] of Object.entries(b.bonus)) if (Number(ate) > agora) horas.push(`${rotulo} ${tipo} ${textoHoras(Number(ate) - agora)}`);
    }
    const vinculos = ['twitch', 'kick'].filter((r) => c.status[r]?.vinculado).join(' e ');
    situacao.push({ label: `${nomeDe(c)}: ${horas.join(', ') || 'sem bônus'}${vinculos ? '' : ' (sem Twitch ou Kick vinculada)'}`, enabled: false });
  }
  const ordem = [...canais.values()].sort((a, b) => b.espectadores - a.espectadores).slice(0, 15);
  const aberta = janelaLive && !janelaLive.isDestroyed();
  return Menu.buildFromTemplate([
    { label: 'Lives oficiais com pontos, ao vivo', enabled: false },
    ...(ordem.length
      ? ordem.map((k) => ({ label: `${k.rotulo}: ${k.nome} (${logica.numeroCurto(k.espectadores)})`, click: () => abrirLive(k.rede, k.id, k.nome) }))
      : [{ label: 'Nenhuma agora, ou as contas ainda não conectaram', enabled: false }]),
    { type: 'separator' },
    { label: 'Som da live', type: 'checkbox', checked: liveComSom, click: (i) => { liveComSom = i.checked; if (aberta) janelaLive.webContents.setAudioMuted(!liveComSom); } },
    { label: 'Fechar a live', enabled: !!aberta, click: () => janelaLive.close() },
    { type: 'separator' },
    { label: 'Horas de bônus', enabled: false },
    ...situacao,
  ]);
}

function abrirCockpit(conta) {
  if (!conta.extIds[ID_ROTOM]) return;
  if (conta.cockpit && !conta.cockpit.isDestroyed()) return conta.cockpit.focus();
  conta.cockpit = new BrowserWindow({
    width: 1160, height: 760, title: `Rotom Sniper — ${nomeDe(conta)}`, autoHideMenuBar: true, icon: ICONE,
    webPreferences: { session: conta.ses, backgroundThrottling: false },
  });
  conta.cockpit.webContents.setWindowOpenHandler(({ url }) => {
    abrirNoNavegador(url);
    return { action: 'deny' };
  });
  conta.cockpit.loadURL(`chrome-extension://${conta.extIds[ID_ROTOM]}/cockpit.html`).catch((e) => registrarErro('cockpit', e));
}

// ---------------------------------------------------------------- menus
function menuExtensoes(conta) {
  return Menu.buildFromTemplate([
    { label: 'Auto Compra', type: 'checkbox', checked: estaAtiva(conta.n, ID_SCRIPT), click: (i) => definirExtensao(conta.n, ID_SCRIPT, i.checked) },
    ...catalogo().map((x) => ({ label: x.nome, type: 'checkbox', checked: estaAtiva(conta.n, x.id), click: (i) => marcarNoMenu(conta, x, i.checked) })),
    { type: 'separator' },
    { label: 'Adicionar extensão de uma pasta...', click: () => escolherExtensao(conta) },
  ]);
}

function menuScript(conta) {
  return Menu.buildFromTemplate(conta.menu.length
    ? conta.menu.map((m) => ({ label: m.nome, click: () => conta.view.webContents.send('tick:menu-click', m.id) }))
    : [{ label: estaAtiva(conta.n, ID_SCRIPT) ? 'Auto Compra ainda carregando' : 'Auto Compra desativado nesta conta', enabled: false }]);
}

function menuConta(conta) {
  const zoom = zoomDe(conta.n);
  return Menu.buildFromTemplate([
    { label: 'Cockpit do Rotom Sniper', enabled: !!conta.extIds[ID_ROTOM], click: () => abrirCockpit(conta) },
    { type: 'separator' },
    {
      label: `Zoom: ${Math.round(zoom * 100)}%`,
      submenu: [
        { label: 'Aumentar', accelerator: 'Ctrl+=', registerAccelerator: false, enabled: zoom < logica.ZOOM_MAX, click: () => definirZoom(conta, zoom + PASSO_ZOOM) },
        { label: 'Diminuir', accelerator: 'Ctrl+-', registerAccelerator: false, enabled: zoom > logica.ZOOM_MIN, click: () => definirZoom(conta, zoom - PASSO_ZOOM) },
        { label: 'Voltar a 100%', enabled: zoom !== 1, click: () => definirZoom(conta, 1) },
      ],
    },
    {
      label: 'Largura da coluna',
      submenu: LARGURAS.map(([label, peso]) => ({
        label, type: 'radio', checked: (layout.pesos[conta.n] ?? 1) === peso, click: () => definirPeso(conta, peso),
      })),
    },
    {
      label: 'Disposição das contas',
      submenu: MODOS.map(([modo, label]) => ({ label, type: 'radio', checked: layout.modo === modo, click: () => definirModo(modo) })),
    },
    { label: 'Renomear conta', click: () => conta.barra.webContents.send('tick:renomear') },
    { type: 'separator' },
    recepcao?.conta === conta
      ? { label: 'Cancelar espera do login', click: () => pararRecepcao() }
      : { label: 'Receber login do navegador', click: () => receberLogin(conta) },
    { label: 'Esquecer o login desta conta', click: () => confirmarEsquecer(conta) },
    { type: 'separator' },
    { label: 'Desligar esta conta', click: () => fecharConta(conta) },
    { label: 'Configurações', click: abrirConfig },
    { label: 'Ferramentas de desenvolvedor', click: () => conta.view.webContents.openDevTools({ mode: 'detach' }) },
  ]);
}

// ---------------------------------------------------------------- configurações
function versaoDoScript() {
  try { return fs.readFileSync(USERSCRIPT, 'utf8').match(/^\/\/ @version\s+(\S+)/m)?.[1] ?? '?'; } catch { return 'não encontrado'; }
}

function memoriaPorConta() {
  const metricas = app.getAppMetrics();
  return Object.fromEntries(contas.map((c) => {
    const pid = c.view.webContents.getOSProcessId();
    const m = metricas.find((x) => x.pid === pid);
    return [c.n, m ? Math.round(m.memory.workingSetSize / 1024) : null];
  }));
}

function montarConfig() {
  const memoria = memoriaPorConta();
  const slots = logica.ordenar(layout.slots, layout.ordem);
  return {
    geral: { comWindows: comWindows(), xSai: layout.xSai, modo: layout.modo },
    modos: MODOS,
    avisos: layout.avisos,
    contas: slots.map((n) => {
      const c = contas.find((x) => x.n === n);
      return {
        n, nome: nomeDoNumero(n), apelido: layout.apelidos[n] ?? '', ligada: !!c, situacao: c ? situacaoDe(c) : 'desligada',
        mudo: !!layout.mudas[n], zoom: zoomDe(n), peso: layout.pesos[n] ?? 1, memoria: memoria[n] ?? null,
      };
    }),
    podeAdicionar: logica.proximaConta(layout.slots, MAX_CONTAS) != null,
    larguras: LARGURAS,
    zoomMin: logica.ZOOM_MIN,
    zoomMax: logica.ZOOM_MAX,
    extensoes: [
      { id: ID_SCRIPT, nome: 'Auto Compra', versao: versaoDoScript() },
      ...catalogo().map(({ id, nome, versao }) => ({ id, nome, versao })),
    ].map((x) => ({ ...x, ativas: Object.fromEntries(slots.map((n) => [n, estaAtiva(n, x.id)])) })),
    versoes: { tick: app.getVersion(), electron: process.versions.electron, chromium: process.versions.chrome, script: versaoDoScript(), origemScript: USERSCRIPT === SCRIPT_TRABALHO ? 'cópia de trabalho' : 'cópia junto do Tick' },
    erros: ultimosErros(),
    cofre: cofreDisponivel,
  };
}

ipcMain.handle('tick:config', montarConfig);
ipcMain.handle('tick:memoria', memoriaPorConta);

ipcMain.handle('tick:config-definir', async (_ev, chave, n, valor) => {
  const conta = contas.find((c) => c.n === n);
  if (chave === 'comWindows') definirComWindows(!!valor);
  else if (chave === 'xSai') { layout.xSai = !!valor; salvarLayout(); }
  else if (chave === 'modo') definirModo(valor);
  else if (chave === 'aviso' && n in layout.avisos) { layout.avisos[n] = !!valor; salvarLayout(); }
  else if (chave === 'adicionar') await abrirConta();
  else if (chave === 'ligada') { if (valor && !conta) await abrirConta(n); else if (!valor && conta) fecharConta(conta); }
  else if (chave === 'mudo' && conta) definirMudo(conta, !!valor);
  else if (chave === 'mudo') { layout.mudas[n] = !!valor; salvarLayout(); }
  else if (chave === 'zoom' && conta) definirZoom(conta, valor);
  else if (chave === 'zoom') { layout.zooms[n] = logica.limitarZoom(valor); salvarLayout(); }
  else if (chave === 'peso' && LARGURAS.some(([, p]) => p === valor)) { layout.pesos[n] = valor; salvarLayout(); dispor(); }
  else if (chave === 'nome') definirApelido(n, valor);
  else if (chave === 'extensao') {
    const [id, ativa] = valor;
    await definirExtensao(n, id, ativa);
    if (ativa && id === 'auto-hunt') avisoAutoHunt(n);
  } else if (chave === 'abrir-registro') {
    if (!fs.existsSync(arquivoRegistro())) gravarSeguro(arquivoRegistro(), '');
    shell.openPath(arquivoRegistro());
  } else if (chave === 'abrir-dados') shell.openPath(dados());
  return montarConfig();
});

// ---------------------------------------------------------------- melhor hunt em camadas
// Só compara: a conta lê o ranking da extensão /hunt e devolve as camadas; quem troca de hunt é a Melhor hunt.
function abrirHunts() {
  if (janelaHunts && !janelaHunts.isDestroyed()) { janelaHunts.show(); return janelaHunts.focus(); }
  janelaHunts = new BrowserWindow({
    width: 820, height: 640, minWidth: 560, minHeight: 400, title: 'Melhor hunt em camadas', autoHideMenuBar: true, icon: ICONE, backgroundColor: '#171a2b',
    webPreferences: { preload: path.join(__dirname, 'preload-ui.js') },
  });
  janelaHunts.loadFile(path.join(__dirname, 'hunts.html')).catch((e) => registrarErro('melhor hunt em camadas', e));
}

ipcMain.handle('tick:hunt-contas', () => contas
  .filter((c) => c.status.ws === 'conectada')
  .map((c) => ({ n: c.n, nome: nomeDe(c) })));

ipcMain.handle('tick:hunt-analisar', async (_ev, n) => {
  const conta = contas.find((c) => c.n === Number(n));
  if (!conta || conta.status.ws !== 'conectada') throw new Error('essa conta não está conectada');
  return conta.view.webContents.executeJavaScript(
    "window.__tickHunt ? window.__tickHunt.analisar() : Promise.reject(new Error('o script de Auto Compra ainda não carregou nesta conta'))",
    true,
  );
});

function abrirConfig() {
  if (janelaConfig && !janelaConfig.isDestroyed()) { janelaConfig.show(); return janelaConfig.focus(); }
  janelaConfig = new BrowserWindow({
    width: 780, height: 680, minWidth: 560, minHeight: 420, title: 'Configurações do Tick', autoHideMenuBar: true, icon: ICONE, backgroundColor: '#15131c',
    webPreferences: { preload: path.join(__dirname, 'preload-ui.js') },
  });
  janelaConfig.loadFile(path.join(__dirname, 'config.html')).catch((e) => registrarErro('configurações', e));
}

// ---------------------------------------------------------------- diagnóstico (só com --diag)
async function diagnosticar(conta) {
  if (!contas.includes(conta) || naTelaDeErro(conta.view.webContents)) return;
  try {
    const wc = conta.view.webContents;
    const pagina = await wc.executeJavaScript(`({
      url: location.origin + location.pathname,
      autoCompra: !!document.querySelector('#autocompra-painel'),
      huntElementos: document.querySelectorAll('[class*="pih"]').length,
      vazouPonte: '__tickGM' in window,
      temSessao: !!localStorage.getItem('sessao'),
    })`);
    fs.mkdirSync(PASTA_DIAG, { recursive: true });
    fs.writeFileSync(path.join(PASTA_DIAG, `conta-${conta.n}.json`), JSON.stringify({
      em: new Date().toISOString(), situacao: situacaoDe(conta), status: conta.status, pagina,
    }, null, 2));
    // Nunca fotografa páginas do Google: a tela de login mostra dados da pessoa.
    if (pagina.url.startsWith('https://pokeidle.io')) {
      fs.writeFileSync(path.join(PASTA_DIAG, `conta-${conta.n}.png`), (await wc.capturePage()).toPNG());
    }
  } catch (e) {
    registrar(`conta ${conta.n}: diagnóstico falhou: ${e.message}`);
  }
}

// Roda em dados à parte (--dados), com sessões falsas: nunca toca nas contas reais.
async function testarApp() {
  const espera = (ms) => new Promise((ok) => setTimeout(ok, ms));
  const log = (txt) => registrar(`teste ${txt}`);
  const foto = async (nome, vista) => {
    for (let t = 0; t < 4; t++) {
      try {
        fs.writeFileSync(path.join(PASTA_DIAG, nome), (await vista.webContents.capturePage()).toPNG());
        return;
      } catch { await espera(1_000); } // a captura falha enquanto a janela ainda está sendo desenhada
    }
    log(`foto ${nome}: não saiu`);
  };
  const areas = () => ordenadas().map((c) => { const b = c.view.getBounds(); return `c${c.n}=${c.view.getVisible() ? '' : 'oculta:'}${b.x},${b.y} ${b.width}x${b.height}`; }).join(' | ');
  const conta = (n) => contas.find((c) => c.n === n);
  while (contas.length < 4) await abrirConta();
  log(`abriu ${contas.length}; proxima=${logica.proximaConta(layout.slots, MAX_CONTAS)}`);
  await abrirConta();
  log(`pedir a 5ª: continua ${contas.length}`);
  await espera(9_000);
  log(`auto com 4: ${areas()}`);
  definirModo('colunas');
  log(`colunas: ${areas()}`);
  definirModo('2x2');
  log(`2x2: ${areas()}`);
  definirModo('auto');
  atualizarStatus(conta(1), { ws: 'conectada', temLogin: true, nick: 'Exemplo', nivel: 624, ouro: 76237 });
  log(`nome salvo: ${layout.nomes[1]}`);
  await espera(600);
  await foto('barra-grade.png', conta(1).barra);
  await foto('lateral-quatro.png', lateral);

  // Menus
  log(`menu conta: ${menuConta(conta(1)).items.map((i) => i.label).filter(Boolean).join(' | ')}`);
  log(`menu script: ${menuScript(conta(1)).items.length} itens`);
  log(`menu extensões: ${menuExtensoes(conta(1)).items.map((i) => i.label).filter(Boolean).join(' | ')}`);

  // Som
  definirMudo(conta(2), true);
  log(`mudo c2=${conta(2).view.webContents.isAudioMuted()} c1=${conta(1).view.webContents.isAudioMuted()}`);

  // Zoom: direto, depois de recarregar, por teclado e pela roda do mouse
  const z = conta(2).view.webContents;
  definirZoom(conta(2), 1.2);
  recarregarConta(conta(2));
  await espera(5_000);
  log(`zoom após recarga: c2=${z.getZoomFactor()} c1=${conta(1).view.webContents.getZoomFactor()}`);
  z.focus();
  z.sendInputEvent({ type: 'keyDown', keyCode: '-', modifiers: ['control'] });
  await espera(400);
  log(`zoom após Ctrl+-: ${layout.zooms[2]}`);
  z.sendInputEvent({ type: 'mouseWheel', x: 100, y: 100, deltaX: 0, deltaY: 120, wheelTicksY: 1, canScroll: true, modifiers: ['control'] });
  await espera(400);
  log(`zoom após Ctrl+roda: ${layout.zooms[2]} fator=${z.getZoomFactor()}`);
  definirZoom(conta(2), 1);

  // Atalhos
  z.sendInputEvent({ type: 'keyDown', keyCode: '1', modifiers: ['control'] });
  await espera(400);
  log(`Ctrl+1: focada=${focada?.n} ${areas()}`);
  await foto('barra-larga.png', conta(1).barra);
  conta(1).view.webContents.focus();
  conta(1).view.webContents.sendInputEvent({ type: 'keyDown', keyCode: '0', modifiers: ['control'] });
  await espera(400);
  log(`Ctrl+0: focada=${focada?.n ?? 'nenhuma'}`);

  // Sem internet: tela de erro, status e volta
  const c3 = conta(3);
  c3.view.webContents.loadURL('https://tick-sem-rede.invalid/').catch(() => {});
  await espera(4_000);
  log(`falha: url=${c3.view.webContents.getURL().split('/').pop()} situacao=${situacaoDe(c3)} tentar=${!!c3.timerRede}`);
  await foto('erro-sem-rede.png', c3.view);
  log(`barra diz: ${await c3.barra.webContents.executeJavaScript(`document.getElementById('situacao').textContent`)}`);
  await espera(TENTAR_DE_NOVO_MS + 4_000);
  log(`tentou sozinho: url=${logica.urlParaRegistro(c3.view.webContents.getURL())} situacao=${situacaoDe(c3)}`);

  // Página que quebra volta sozinha
  conta(2).view.webContents.forcefullyCrashRenderer();
  await espera(8_000);
  log(`após quebra: crashed=${conta(2).view.webContents.isCrashed()} url=${logica.urlParaRegistro(conta(2).view.webContents.getURL())} recargas=${conta(2).recargas?.length}`);

  // Desligar e religar
  fecharConta(c3);
  log(`desligada: abertas=${layout.abertas} slots=${layout.slots} ${areas()}`);
  await espera(500);
  await foto('lateral-desligada.png', lateral);
  await abrirConta(3);
  await espera(7_000);
  log(`religada: abertas=${layout.abertas} exts=${conta(3).ses.extensions.getAllExtensions().length} autoCompra=${await conta(3).view.webContents.executeJavaScript(`!!document.querySelector('#autocompra-painel')`)}`);

  // Extensão em conta desligada
  fecharConta(conta(3));
  await definirExtensao(3, 'auto-hunt', true);
  log(`desligada auto-hunt: auto=${estaAtiva(3, 'auto-hunt')} hunt=${estaAtiva(3, 'hunt')}`);
  await abrirConta(3);
  await espera(2_000);
  log(`religada exts: ${conta(3).ses.extensions.getAllExtensions().map((e) => e.name).join(' | ')}`);
  await definirExtensao(3, 'hunt', true);
  log(`hunt de volta: auto=${estaAtiva(3, 'auto-hunt')} hunt=${estaAtiva(3, 'hunt')}`);

  // Cofre: o que foi cifrado pelo jeito antigo precisa continuar sendo lido
  const falsa = JSON.stringify({ nick: 'copia-teste', token: 'falso' });
  gravarSeguro(arquivoSessoes(), JSON.stringify({ 1: safeStorage.encryptString(falsa).toString('base64') }));
  sessoes.clear();
  await abrirCofre();
  log(`cofre antigo lido: ${sessoes.get(1) === falsa}`);
  const nova = JSON.stringify({ nick: 'copia-nova', token: 'falso2' });
  await guardarSessao(2, nova);
  sessoes.clear();
  await abrirCofre();
  log(`cofre novo: lido=${sessoes.get(2) === nova} em claro=${fs.readFileSync(arquivoSessoes(), 'utf8').includes('copia-')}`);
  await conta(1).view.webContents.executeJavaScript(`localStorage.removeItem('sessao'); sessionStorage.removeItem('tick.restaurada');`);
  conta(1).restauracoes = MAX_RESTAURAR; // a sessão é falsa: só a devolução antes da carga interessa aqui
  recarregarConta(conta(1));
  await espera(5_000);
  log(`restaurada antes da carga: ${await conta(1).view.webContents.executeJavaScript(`sessionStorage.getItem('tick.restaurada')`)}`);
  await esquecerSessao(1);
  await esquecerSessao(2);
  log(`esquecida: ${!sessoes.has(1) && !JSON.parse(fs.readFileSync(arquivoSessoes(), 'utf8'))[1]}`);

  // Configurações
  abrirConfig();
  await espera(2_500);
  const texto = await janelaConfig.webContents.executeJavaScript(`document.body.innerText`);
  log(`config: ${texto.length} letras; memória=${JSON.stringify(memoriaPorConta())}; versões=${JSON.stringify(montarConfig().versoes)}; erros=${montarConfig().erros.length}`);
  await foto('config.png', janelaConfig);
  await janelaConfig.webContents.executeJavaScript(`window.scrollTo(0, document.body.scrollHeight)`);
  await espera(300);
  await foto('config-fim.png', janelaConfig);

  // Registro e aviso desligável
  layout.avisos.queda = false;
  avisar('queda', 'não deve aparecer', 'x');
  layout.avisos.queda = true;
  const registro = fs.readFileSync(arquivoRegistro(), 'utf8');
  log(`registro: tem erro=${registro.includes('[erro]')} tem token=${/falso|copia-/.test(registro)}`);
  janela.close();
  await espera(600);
  log(`X esconde: visivel=${janela.isVisible()} vivo=${!janela.isDestroyed()}`);
  mostrarJanela();
  registrar('teste: fim');
}

// Só com --dados temporário e sem login: confere modos, live e os módulos do jogo de que as ferramentas dependem.
async function testarRecursos() {
  const espera = (ms) => new Promise((ok) => setTimeout(ok, ms));
  const log = (t) => anotar(`teste ${t}`);
  await espera(9_000);
  const c = ordenadas()[0];
  const wc = c.view.webContents;
  const ler = () => wc.executeJavaScript(`({ economia: localStorage.getItem('cfg-economia'), ultra: localStorage.getItem('cfg-ultra'), classe: document.documentElement.classList.contains('modo-economia') })`);
  for (const m of ['economia', 'ultra', 'cena']) {
    await definirModoJogo(m);
    await espera(7_000);
    log(`modo ${m}: ${JSON.stringify(await ler())}`);
  }
  log(`módulos: ${JSON.stringify(await wc.executeJavaScript(`(async () => {
    const g = await import(location.origin + '/shared/ginasios.mjs');
    const t = await import(location.origin + '/shared/pvp-tabuleiro.mjs');
    const cr = await fetch(location.origin + '/assets/creatures.json').then((r) => r.json());
    const a = cr.creatures.find((x) => x.baseHp > 80 && x.baseAtk > x.baseSpAtk);
    const b = cr.creatures.find((x) => x.baseSpAtk > x.baseAtk + 60);
    const pk = (e) => ({ speciesId: e.pokeId, level: 500, ivs: { hp: 20, atk: 20, def: 20, spatk: 20, spdef: 20, speed: 20 }, qualidade: 1.2, quality: 1.2, potencia: 3 });
    const ma = g.metricasDeCombate(pk(a), a);
    const cmp = g.compararDuelo1v1(pk(a), a, pk(b), b, { amostras: 40 });
    return { temMetricas: !!ma, chaves: ma && Object.keys(ma), pctA: cmp?.pctA, alcances: [t.alcanceDaEspecie(a), t.alcanceDaEspecie(b)], casas: t.casasDaEquipe([null, null], [t.alcanceDaEspecie(a), t.alcanceDaEspecie(b)]) };
  })()`))}`);
  atualizarStatus(c, {
    ws: 'conectada', temLogin: true, nick: 'ContaTeste', nivel: 1234, ouro: 5678900,
    twitch: { vinculado: true, bonus: { xp: Date.now() + 90 * 60_000 }, canais: [{ id: 'exemplo', nome: 'Canal Exemplo', aoVivo: true, ativo: true, espectadores: 1500 }, { id: 'parado', nome: 'Parado', aoVivo: false, ativo: true, espectadores: 0 }] },
  });
  await espera(1_500);
  log(`menu lives: ${menuLives().items.map((i) => i.label).filter(Boolean).slice(0, 8).join(' | ')}`);
  fs.mkdirSync(PASTA_DIAG, { recursive: true });
  fs.writeFileSync(path.join(PASTA_DIAG, 'lateral.png'), (await lateral.webContents.capturePage()).toPNG());
  fs.writeFileSync(path.join(PASTA_DIAG, 'barra.png'), (await c.barra.webContents.capturePage()).toPNG());
  abrirConfig();
  await espera(2_500);
  for (let t = 0; t < 5; t++) {
    try {
      janelaConfig.show();
      fs.writeFileSync(path.join(PASTA_DIAG, 'config.png'), (await janelaConfig.webContents.capturePage()).toPNG());
      break;
    } catch { await espera(1_000); } // a captura falha enquanto a janela ainda está sendo desenhada
  }
  janelaConfig.close();
  abrirLive('twitch', 'twitch', 'Twitch');
  await espera(16_000);
  const lw = janelaLive.webContents;
  log(`live: url=${logica.urlParaRegistro(lw.getURL())} mudo=${lw.isAudioMuted()} partição=${lw.session === session.fromPartition('persist:lives')} ${JSON.stringify(await lw.executeJavaScript(`({ qualidade: localStorage.getItem('video-quality'), video: !!document.querySelector('video'), pausado: document.querySelector('video')?.paused ?? null })`))}`);
  janelaLive.close();
  registrar('teste: fim');
  anotar('teste: fim');
}

// Com as contas reais: só rola e dá zoom, restaura o zoom e sai. Não clica em nada nem envia nada ao jogo.
async function testarRolagem() {
  const espera = (ms) => new Promise((ok) => setTimeout(ok, ms));
  await espera(14_000);
  for (const c of ordenadas()) {
    const wc = c.view.webContents;
    const { width, height } = c.view.getBounds();
    const leitura = () => wc.executeJavaScript(`(() => {
      const p = document.querySelector('.eco-painel');
      return { economia: document.documentElement.classList.contains('modo-economia'), rola: p ? p.scrollHeight > p.clientHeight : null, topo: p?.scrollTop ?? null, zoomCena: document.getElementById('palco')?.dataset.zoom ?? null };
    })()`);
    const roda = (y, deltaY, modifiers = []) => wc.sendInputEvent({ type: 'mouseWheel', x: Math.floor(width / 2), y, deltaX: 0, deltaY, wheelTicksY: deltaY > 0 ? 1 : -1, canScroll: true, modifiers });
    const y = Math.floor(height * 0.72);
    const alvo = await wc.executeJavaScript(`document.elementFromPoint(${Math.floor(width / 2)}, ${y})?.closest('.eco-painel, #palco')?.className ?? 'fora do palco'`);
    const antes = await leitura();
    const zoomAntes = wc.getZoomFactor();
    wc.focus();
    roda(y, -240);
    await espera(700);
    const depoisRoda = await leitura();
    roda(y, 240);
    await espera(300);
    roda(y, 120, ['control']);
    await espera(500);
    const zoomDepois = wc.getZoomFactor();
    definirZoom(c, zoomAntes);
    anotar(`rolagem ${nomeDe(c)}: alvo=${alvo} ${JSON.stringify(antes)} -> ${JSON.stringify(depoisRoda)}; Ctrl+roda ${zoomAntes} -> ${zoomDepois}`);
    await espera(400);
    const f = path.join(PASTA_DIAG, `rolagem-${c.n}.png`);
    fs.mkdirSync(PASTA_DIAG, { recursive: true });
    try { fs.writeFileSync(f, (await wc.capturePage()).toPNG()); } catch { /* foto é só para conferir */ }
  }
  for (const c of contas) c.ses.flushStorageData();
  await espera(800);
  app.quit();
}

// ---------------------------------------------------------------- início
app.whenReady().then(async () => {
  if (segundoClique) return;
  Menu.setApplicationMenu(null);
  lerLayout();
  // Neste PC, a cópia que anda junto com o Tick acompanha o script de trabalho.
  if (USERSCRIPT === SCRIPT_TRABALHO) {
    try { fs.copyFileSync(SCRIPT_TRABALHO, SCRIPT_JUNTO); } catch (e) { registrarErro('copiar script', e); }
  }
  janela = new BaseWindow({ ...limitesSalvos(), title: 'Tick', icon: ICONE, backgroundColor: '#15131c' });
  if (layout.janela?.maximizada) janela.maximize();
  montarBandeja();
  lateral = new WebContentsView({ webPreferences: { preload: path.join(__dirname, 'preload-ui.js') } });
  lateral.webContents.loadFile(path.join(__dirname, 'lateral.html'));
  lateral.webContents.on('before-input-event', (ev, input) => teclas(null, ev, input));
  janela.contentView.addChildView(lateral);
  janela.on('resize', () => { dispor(); guardarJanela(); });
  janela.on('move', guardarJanela);
  janela.on('leave-full-screen', () => { if (cheia) { cheia = false; focada = null; dispor(); publicar(); } });
  // O X esconde na bandeja e as contas seguem jogando, a menos que a pessoa escolha sair nas configurações.
  janela.on('close', (ev) => {
    if (saindo || layout.xSai) return;
    ev.preventDefault();
    janela.hide();
    if (!layout.avisouBandeja) {
      layout.avisouBandeja = true;
      salvarLayout();
      avisar('sistema', 'O Tick continua rodando', 'As contas seguem jogando. Para sair, clique com o botão direito no ícone do Tick perto do relógio.');
    }
  });
  janela.on('closed', () => app.quit());
  janela.on('session-end', apagarMarcaVigia); // o Windows está desligando: isto não é uma queda
  const gravarTudo = () => { for (const c of contas) c.ses.flushStorageData(); };
  setInterval(gravarTudo, GRAVAR_DADOS_MS);
  app.on('before-quit', gravarTudo);
  salvarLayout(); // grava a migração do contas.json
  iniciarVigia();
  iniciarDiagnosticoDeQuedas();
  dispor();
  janelaAberta = true;
  iniciarAtualizacao();
  iniciarAtualizacaoDeExtensoes();
  // Só depois da janela: nada que dependa da internet ou do sistema pode deixar o app invisível.
  let esperaCofre;
  await Promise.race([
    abrirCofre().catch((e) => registrarErro('cofre', e)),
    new Promise((ok) => { esperaCofre = setTimeout(() => { registrarErro('cofre', 'sem resposta em 10 segundos'); ok(); }, 10_000); }),
  ]);
  clearTimeout(esperaCofre);
  await baixarExtensoesDaLoja();
  const abertas = logica.ordenar(layout.abertas, layout.ordem);
  anotar(`início: ${app.isPackaged ? 'Tick.exe' : 'desenvolvimento'}, contas ${abertas.join(',') || 'nenhuma'}, logins guardados ${[...sessoes.keys()].join(',') || 'nenhum'}`);
  for (const n of abertas) await abrirConta(n);
  if (process.argv.includes('--teste-recursos')) testarRecursos().catch((e) => { registrarErro('teste recursos', e); registrar('teste: fim (com erro)'); });
  if (process.argv.includes('--teste-rolagem')) testarRolagem().catch((e) => { registrarErro('teste rolagem', e); app.quit(); });
  if (TESTE_APP) testarApp().catch((e) => { registrarErro('teste', e); registrar('teste: fim (com erro)'); });
}).catch((e) => { registrarErro('início', e); falhaAoAbrir(e); });
