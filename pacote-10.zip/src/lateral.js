const contas = document.getElementById('contas');
const abrir = document.getElementById('abrir');
const grade = document.getElementById('grade');

abrir.addEventListener('click', () => window.tick.acao('abrir-conta'));
grade.addEventListener('click', () => window.tick.acao('grade'));
document.getElementById('config').addEventListener('click', () => window.tick.acao('config'));
document.getElementById('modos').addEventListener('click', () => window.tick.acao('modos'));
document.getElementById('lives').addEventListener('click', () => window.tick.acao('lives'));
const meta = document.getElementById('meta');
meta.addEventListener('click', () => window.tick.acao('meta'));
meta.addEventListener('contextmenu', (ev) => { ev.preventDefault(); window.tick.acao('meta-conta'); });
document.getElementById('hunts').addEventListener('click', () => window.tick.acao('hunts'));

// Arrastar um botão sobre outro muda a ordem das contas.
let arrastada = null;

window.tick.aoEstado((estado) => {
  contas.replaceChildren(...estado.contas.map((c) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.title = c.ligada
      ? `${c.nome}: clique para ver só ela, botão direito para opções, arraste para mudar a ordem`
      : `${c.nome} desligada: clique para ligar`;
    b.setAttribute('aria-label', c.ligada ? c.nome : `Ligar ${c.nome}`);
    b.textContent = c.nome.slice(0, 3).toUpperCase();
    b.classList.toggle('ativa', estado.focada === c.n);
    b.classList.toggle('desligada', !c.ligada);
    b.draggable = true;
    b.addEventListener('dragstart', (ev) => { arrastada = c.n; ev.dataTransfer.effectAllowed = 'move'; });
    b.addEventListener('dragend', () => { arrastada = null; b.classList.remove('alvo'); });
    b.addEventListener('dragover', (ev) => {
      if (arrastada == null || arrastada === c.n) return;
      ev.preventDefault();
      b.classList.add('alvo');
    });
    b.addEventListener('dragleave', () => b.classList.remove('alvo'));
    b.addEventListener('drop', (ev) => {
      ev.preventDefault();
      if (arrastada != null) window.tick.acao('mover', arrastada, c.n);
    });
    if (c.ligada) {
      const ponto = document.createElement('span');
      ponto.className = `ponto ${c.situacao}`;
      b.append(ponto);
    }
    b.addEventListener('click', () => window.tick.acao(c.ligada ? 'focar' : 'ligar', c.n));
    b.addEventListener('contextmenu', (ev) => { ev.preventDefault(); window.tick.acao('menu-lateral', c.n); });
    return b;
  }));
  document.getElementById('modo-letra').textContent = { cena: 'C', economia: 'E', ultra: 'U' }[estado.modoJogo] ?? 'C';
  document.getElementById('lives').classList.toggle('ativa', !!estado.liveAberta);
  abrir.hidden = !estado.podeAbrir;
  grade.hidden = estado.focada == null;
});
