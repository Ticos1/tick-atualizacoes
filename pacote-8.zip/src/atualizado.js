const depois = () => window.close();

document.getElementById('edicao').textContent = `Edição ${new URLSearchParams(location.search).get('versao')}`;
document.getElementById('depois').addEventListener('click', depois);
document.getElementById('reiniciar').addEventListener('click', () => window.tick.reiniciar());
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') depois(); });
