const N = Number(new URLSearchParams(location.search).get('n'));
const $ = (id) => document.getElementById(id);
const ICONE_ABRIR = 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5';
const ICONE_FECHAR = 'M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5';
const ICONE_SOM = 'M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12';
const ICONE_MUDO = 'm16 9 5 6M21 9l-5 6';
const TEXTOS = { esperando: 'esperando login', semlogin: 'sem login', carregando: 'carregando', caiu: 'desconectada', outro: 'aberta em outro lugar', semrede: 'sem conexão' };
let ultimo = null;

function tempo(desde) {
  const min = Math.floor((Date.now() - desde) / 60_000);
  if (min < 1) return 'agora';
  if (min < 60) return `há ${min} min`;
  return `há ${Math.floor(min / 60)} h ${min % 60} min`;
}

function pintar() {
  const c = ultimo?.contas.find((x) => x.n === N);
  if (!c) return;
  document.title = c.nome;
  $('ponto').className = `ponto ${c.situacao}`;
  $('nome').textContent = c.nome;
  $('nivel').textContent = c.nivel != null ? `Nv ${c.nivel}` : '';
  $('situacao').textContent = c.situacao === 'conectada' ? `conectada ${tempo(c.desde)}` : TEXTOS[c.situacao] ?? '';
  $('ouro').textContent = c.ouro != null ? `${c.ouro.toLocaleString('pt-BR')} ouro` : '';
  // A previsão de shiny vem do script da conta; passando o mouse, as dicas.
  $('shiny').textContent = c.situacao === 'conectada' ? c.shiny?.texto ?? '' : '';
  $('shiny').title = c.situacao === 'conectada' ? c.shiny?.dica ?? '' : '';
  $('mudo-icone').setAttribute('d', c.mudo ? ICONE_MUDO : ICONE_SOM);
  $('mudo').setAttribute('aria-pressed', String(!!c.mudo));
  $('mudo').title = c.mudo ? 'Ligar o som' : 'Tirar o som';
  $('mudo').setAttribute('aria-label', $('mudo').title);
  const cheia = ultimo.cheia && ultimo.focada === N;
  $('tela-icone').setAttribute('d', cheia ? ICONE_FECHAR : ICONE_ABRIR);
  $('tela').title = cheia ? 'Sair da tela cheia (F11)' : 'Tela cheia (F11)';
  $('tela').setAttribute('aria-label', cheia ? 'Sair da tela cheia' : 'Tela cheia');
}

for (const [id, tipo] of [['ext', 'extensoes'], ['script', 'script'], ['conta', 'conta'], ['mudo', 'mudo'], ['recarregar', 'recarregar'], ['tela', 'tela-cheia']]) {
  $(id).addEventListener('click', () => window.tick.acao(tipo, N));
}

// Renomear: Enter ou clicar fora salva, Esc desiste, vazio volta para o nick do jogo.
function comecarRenomear() {
  const c = ultimo?.contas.find((x) => x.n === N);
  $('nome-campo').value = c?.apelido ?? c?.nome ?? '';
  $('nome').hidden = true;
  $('nome-campo').hidden = false;
  $('nome-campo').focus();
  $('nome-campo').select();
}
function terminarRenomear(salvar) {
  if ($('nome-campo').hidden) return;
  $('nome-campo').hidden = true;
  $('nome').hidden = false;
  if (salvar) window.tick.acao('apelido', N, $('nome-campo').value);
}
$('nome').addEventListener('dblclick', comecarRenomear);
$('nome-campo').addEventListener('blur', () => terminarRenomear(true));
$('nome-campo').addEventListener('keydown', (ev) => {
  if (ev.key === 'Enter') terminarRenomear(true);
  else if (ev.key === 'Escape') terminarRenomear(false);
});
window.tick.aoRenomear(comecarRenomear);
window.tick.aoEstado((estado) => { ultimo = estado; pintar(); });
setInterval(pintar, 30_000);
