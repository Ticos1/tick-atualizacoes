const texto = document.getElementById('texto');
const fechar = () => window.close();

document.getElementById('fechar').addEventListener('click', fechar);
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') fechar(); });

// Linhas com "- " viram lista; as outras, parágrafos. Sempre como texto puro.
window.tick.novidades().then(({ versao, texto: conteudo }) => {
  document.getElementById('edicao').textContent = `Edição ${versao}`;
  let lista = null;
  for (const linha of conteudo.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)) {
    if (linha.startsWith('- ')) {
      if (!lista) lista = texto.appendChild(document.createElement('ul'));
      lista.appendChild(document.createElement('li')).textContent = linha.slice(2);
    } else {
      lista = null;
      texto.appendChild(document.createElement('p')).textContent = linha;
    }
  }
});
