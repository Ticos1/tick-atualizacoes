// Roda antes da página, em toda conta. Só age nas páginas em que o Tampermonkey rodava o script (/app*).
const { contextBridge, ipcRenderer, webFrame } = require('electron');

if (location.protocol === 'https:' && location.hostname === 'pokeidle.io' && location.pathname.startsWith('/app')) {
  const ponte = {
    http: (pedido) => ipcRenderer.invoke('tick:http', pedido),
    menu: (lista) => ipcRenderer.send('tick:menu', lista),
    aoClicarMenu: (fn) => ipcRenderer.on('tick:menu-click', (_ev, id) => fn(id)),
    status: (dados) => ipcRenderer.send('tick:status', dados),
    nocaute: () => ipcRenderer.send('tick:nocaute'),
    sessao: (s) => ipcRenderer.send('tick:sessao', s),
  };
  // Síncrono de propósito: o login precisa estar no lugar antes de o jogo procurar por ele.
  contextBridge.executeInMainWorld({
    func: (copia) => {
      if (!copia || localStorage.getItem('sessao')) return;
      localStorage.setItem('sessao', copia);
      localStorage.setItem('nick', JSON.parse(copia).nick);
      sessionStorage.setItem('tick.restaurada', '1');
    },
    args: [ipcRenderer.sendSync('tick:copia')],
  });
  // A ponte fica numa global só até o script pegá-la: ele a apaga antes de qualquer código do jogo rodar.
  contextBridge.executeInMainWorld({
    func: (api) => { Object.defineProperty(window, '__tickGM', { value: api, configurable: true }); },
    args: [ponte],
  });
  webFrame.executeJavaScript(ipcRenderer.sendSync('tick:userscript'));
}
