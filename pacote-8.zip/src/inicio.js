// Ponto de entrada. No Tick da casa, só abre o main.js. Na edição para amigos, escolhe entre o código do zip e o
// atualizado, e um erro no código atualizado nunca impede o Tick de abrir com o do zip.
const fs = require('node:fs');
const path = require('node:path');

const base = path.join(__dirname, '..');

function abrir() {
  if (!fs.existsSync(path.join(base, 'amigo.json'))) return require('./main');
  const atualizador = require('./atualizador');
  const argDados = process.argv.find((a) => a.startsWith('--dados='));
  const dados = argDados
    ? argDados.slice('--dados='.length)
    : path.join(process.env.LOCALAPPDATA ?? path.join(process.env.USERPROFILE ?? '', 'AppData', 'Local'), 'Tick');
  let pasta = base;
  try { pasta = atualizador.escolherCodigo(dados, base); } catch { /* sem conseguir escolher, usa o do zip */ }
  if (pasta === base) return require('./main');
  try {
    return require(path.join(pasta, 'src', 'main.js'));
  } catch (e) {
    console.error(e);
    try { atualizador.marcarRuim(dados, atualizador.versaoDe(pasta)); } catch { /* na próxima, as tentativas resolvem */ }
    return require('./main');
  }
}

abrir();
