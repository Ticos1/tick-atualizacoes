const $ = (id) => document.getElementById(id);
const el = (tag, props = {}, ...filhos) => {
  const e = Object.assign(document.createElement(tag), props);
  e.append(...filhos);
  return e;
};
const celula = (...filhos) => el('td', {}, ...filhos);

const mudar = async (chave, n, valor) => pintar(await window.tick.definir(chave, n, valor));

function caixa(marcada, rotulo, aoMudar, desabilitada = false) {
  const c = el('input', { type: 'checkbox', checked: marcada, disabled: desabilitada });
  c.setAttribute('aria-label', rotulo);
  c.addEventListener('change', () => { c.disabled = true; aoMudar(c.checked); });
  return c;
}

const memoriaTexto = (mb) => (mb == null ? '—' : `${mb} MB`);

function linhaConta(c, larguras, cfg) {
  const nome = el('input', { type: 'text', value: c.apelido, maxLength: 24, placeholder: c.nome });
  nome.setAttribute('aria-label', `Apelido da ${c.nome}`);
  nome.addEventListener('change', () => mudar('nome', c.n, nome.value));

  const zoom = el('input', { type: 'range', min: cfg.zoomMin, max: cfg.zoomMax, step: 0.1, value: c.zoom });
  zoom.setAttribute('aria-label', `Zoom da ${c.nome}`);
  const zoomTexto = el('span', { textContent: ` ${Math.round(c.zoom * 100)}%` });
  zoom.addEventListener('input', () => { zoomTexto.textContent = ` ${Math.round(zoom.value * 100)}%`; });
  zoom.addEventListener('change', () => mudar('zoom', c.n, Number(zoom.value)));

  const largura = el('select');
  largura.setAttribute('aria-label', `Largura da ${c.nome}`);
  for (const [rotulo, peso] of larguras) largura.append(el('option', { value: String(peso), textContent: rotulo, selected: peso === c.peso }));
  largura.addEventListener('change', () => mudar('peso', c.n, Number(largura.value)));

  const memoria = el('td', { className: 'num', textContent: memoriaTexto(c.memoria) });
  memoria.dataset.memoria = c.n;

  return el(
    'tr', {},
    el('td', { className: 'nome' }, el('span', { className: `ponto ${c.situacao}`, title: c.situacao }), nome),
    celula(caixa(c.ligada, `${c.nome} ligada`, (v) => mudar('ligada', c.n, v))),
    celula(caixa(!c.mudo, `Som da ${c.nome}`, (v) => mudar('mudo', c.n, !v))),
    el('td', { className: 'num' }, zoom, zoomTexto),
    celula(largura),
    memoria,
  );
}

function pintar(cfg) {
  $('contas').replaceChildren(...cfg.contas.map((c) => linhaConta(c, cfg.larguras, cfg)));
  $('adicionar').hidden = !cfg.podeAdicionar;

  $('ext-cabeca').replaceChildren(el('tr', {}, el('th', { textContent: 'Extensão' }), ...cfg.contas.map((c) => el('th', { textContent: c.nome }))));
  $('ext-corpo').replaceChildren(...cfg.extensoes.map((x) => el(
    'tr', {},
    el('td', { textContent: `${x.nome} ${x.versao ?? ''}` }),
    ...cfg.contas.map((c) => celula(caixa(x.ativas[c.n], `${x.nome} na ${c.nome}`, (v) => mudar('extensao', c.n, [x.id, v])))),
  )));

  $('modo').replaceChildren(...cfg.modos.map(([valor, rotulo]) => el('option', { value: valor, textContent: rotulo, selected: valor === cfg.geral.modo })));
  $('comWindows').checked = cfg.geral.comWindows;
  $('xSai').checked = cfg.geral.xSai;
  for (const c of document.querySelectorAll('[data-aviso]')) c.checked = cfg.avisos[c.dataset.aviso] !== false;

  const v = cfg.versoes;
  $('versoes').textContent = `Tick ${v.tick} · Auto Compra ${v.script} (${v.origemScript}) · Electron ${v.electron} · Chromium ${v.chromium}`;
  $('cofre').textContent = cfg.cofre ? 'Logins guardados com a criptografia do Windows.' : 'A criptografia do Windows não está disponível: os logins não serão lembrados.';
  $('erros').replaceChildren(...(cfg.erros.length
    ? cfg.erros.map((t) => el('li', { textContent: t }))
    : [el('li', { textContent: 'Nenhum erro registrado.' })]));
}

$('adicionar').addEventListener('click', () => mudar('adicionar'));
$('modo').addEventListener('change', () => mudar('modo', null, $('modo').value));
$('comWindows').addEventListener('change', () => mudar('comWindows', null, $('comWindows').checked));
$('xSai').addEventListener('change', () => mudar('xSai', null, $('xSai').checked));
for (const c of document.querySelectorAll('[data-aviso]')) c.addEventListener('change', () => mudar('aviso', c.dataset.aviso, c.checked));
$('abrir-registro').addEventListener('click', () => window.tick.definir('abrir-registro'));
$('abrir-dados').addEventListener('click', () => window.tick.definir('abrir-dados'));

window.tick.config().then(pintar);
// Só a memória muda sozinha: redesenhar tudo tiraria o foco de quem está digitando.
setInterval(async () => {
  const memoria = await window.tick.memoria();
  for (const td of document.querySelectorAll('[data-memoria]')) td.textContent = memoriaTexto(memoria[td.dataset.memoria]);
}, 5_000);
