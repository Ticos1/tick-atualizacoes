// Atualização da edição para amigos. Só instala o que foi assinado com a chave que fica no PC de quem publica:
// nem quem invadir o repositório consegue entregar código para as contas de quem usa.
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { lerZip } = require('./crx');

const CHAVE_PUBLICA = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA+esF5ygntFvn1ZQl1J1v857jIeaQ1e+Vtgi4jJtzgBw=
-----END PUBLIC KEY-----`;
const BASE = process.env.TICK_ATUALIZACAO_URL || 'https://raw.githubusercontent.com/Ticos1/tick-atualizacoes/main';
const TAMANHO_MAX = 30 * 1024 * 1024;

const pastaDe = (dados) => path.join(dados, 'atualizacao');
const lerJson = (arquivo, padrao) => { try { return JSON.parse(fs.readFileSync(arquivo, 'utf8')); } catch { return padrao; } };

function gravarJson(arquivo, valor) {
  fs.mkdirSync(path.dirname(arquivo), { recursive: true });
  fs.writeFileSync(`${arquivo}.tmp`, JSON.stringify(valor));
  fs.renameSync(`${arquivo}.tmp`, arquivo);
}

/** A versão de uma pasta de código. 0: não é uma pasta válida. */
function versaoDe(pasta) {
  const v = lerJson(path.join(pasta, 'amigo.json'), null)?.versao;
  return Number.isInteger(v) && v > 0 ? v : 0;
}

/** Só devolve o manifesto se a assinatura bater. Tudo o que vem depois confia nele. */
function validarManifesto(bytes, assinatura, chave = CHAVE_PUBLICA) {
  if (!crypto.verify(null, bytes, chave, assinatura)) throw new Error('assinatura inválida');
  const m = JSON.parse(bytes.toString('utf8'));
  if (!Number.isInteger(m.versao) || m.versao < 1) throw new Error('versão inválida no manifesto');
  if (!/^[0-9a-f]{64}$/.test(m.sha256)) throw new Error('hash inválido no manifesto');
  if (!/^pacote-\d+\.zip$/.test(m.arquivo)) throw new Error('arquivo inválido no manifesto');
  if (!Number.isInteger(m.tamanho) || m.tamanho < 1 || m.tamanho > TAMANHO_MAX) throw new Error('tamanho inválido no manifesto');
  return m;
}

/** Confere o pacote e só troca a pasta no fim: uma falha no meio deixa o código anterior intacto. */
function instalar(zip, manifesto, dados) {
  const hash = crypto.createHash('sha256').update(zip).digest('hex');
  if (hash !== manifesto.sha256) throw new Error('o pacote não confere com o manifesto');
  const arquivos = lerZip(zip);
  const nomes = new Set(arquivos.map((a) => a.partes.join('/')));
  for (const obrigatorio of ['amigo.json', 'src/main.js', 'src/inicio.js', 'vendor/pokeidle-autocompra.user.js']) {
    if (!nomes.has(obrigatorio)) throw new Error(`faltou ${obrigatorio} no pacote`);
  }
  const raiz = pastaDe(dados);
  const tmp = path.join(raiz, 'baixando');
  const atual = path.join(raiz, 'atual');
  const velha = path.join(raiz, 'velha');
  fs.rmSync(tmp, { recursive: true, force: true });
  for (const a of arquivos) {
    const alvo = path.join(tmp, ...a.partes);
    fs.mkdirSync(path.dirname(alvo), { recursive: true });
    fs.writeFileSync(alvo, a.dados);
  }
  if (versaoDe(tmp) !== manifesto.versao) throw new Error('a versão do pacote não bate com o manifesto');
  fs.rmSync(velha, { recursive: true, force: true });
  if (fs.existsSync(atual)) fs.renameSync(atual, velha);
  fs.renameSync(tmp, atual);
  fs.rmSync(velha, { recursive: true, force: true });
  return atual;
}

/** Procura uma versão nova. Devolve a pasta instalada, ou null se não houver nada a fazer. */
async function conferir({ dados, versaoEmUso, buscar = fetch, chave = CHAVE_PUBLICA }) {
  const pegar = async (nome) => {
    const r = await buscar(`${BASE}/${nome}`, { cache: 'no-store', signal: AbortSignal.timeout(60_000) });
    if (!r.ok) throw new Error(`${nome}: HTTP ${r.status}`);
    return Buffer.from(await r.arrayBuffer());
  };
  const manifesto = validarManifesto(await pegar('versao.json'), await pegar('versao.json.sig'), chave);
  const instalada = versaoDe(path.join(pastaDe(dados), 'atual'));
  if (manifesto.versao <= Math.max(versaoEmUso, instalada)) return null;
  if (lerJson(path.join(pastaDe(dados), 'ruins.json'), []).includes(manifesto.versao)) return null;
  return { versao: manifesto.versao, pasta: instalar(await pegar(manifesto.arquivo), manifesto, dados) };
}

/**
 * Qual código abrir: o do zip ou o atualizado. Uma versão nova tem 2 chances de abrir a janela. Se não
 * conseguir, é marcada como ruim e o Tick volta ao código do zip, sem depender de ninguém.
 */
function escolherCodigo(dados, base) {
  const raiz = pastaDe(dados);
  const atual = path.join(raiz, 'atual');
  const versao = versaoDe(atual);
  if (versao <= versaoDe(base)) return base;
  const ruins = lerJson(path.join(raiz, 'ruins.json'), []);
  if (ruins.includes(versao)) return base;
  if (lerJson(path.join(raiz, 'boa.json'), null)?.versao === versao) return atual;
  const tentativas = lerJson(path.join(raiz, 'tentativas.json'), null);
  const feitas = tentativas?.versao === versao ? tentativas.n : 0;
  if (feitas >= 2) {
    marcarRuim(dados, versao);
    return base;
  }
  gravarJson(path.join(raiz, 'tentativas.json'), { versao, n: feitas + 1 });
  return atual;
}

function marcarRuim(dados, versao) {
  const arquivo = path.join(pastaDe(dados), 'ruins.json');
  const ruins = lerJson(arquivo, []);
  if (!ruins.includes(versao)) gravarJson(arquivo, [...ruins, versao]);
}

/** A janela abriu: esta versão funciona neste PC. */
function confirmar(dados, versao) {
  if (versao > 0) gravarJson(path.join(pastaDe(dados), 'boa.json'), { versao });
}

/** O texto de novidades desta versão, se esta pessoa ainda não viu. Anota que viu. */
function novidadesParaMostrar(dados, codigo, versao) {
  const arquivo = path.join(pastaDe(dados), 'novidades-vistas.json');
  const vista = lerJson(arquivo, null)?.versao;
  if (vista === versao) return null;
  gravarJson(arquivo, { versao });
  try { return fs.readFileSync(path.join(codigo, 'novidades.txt'), 'utf8').trim() || null; } catch { return null; }
}

module.exports = { novidadesParaMostrar, versaoDe, validarManifesto, instalar, conferir, escolherCodigo, marcarRuim, confirmar };
