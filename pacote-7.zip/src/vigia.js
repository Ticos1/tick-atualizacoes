// O vigia do Tick: um processo separado, sem janela, que reabre o app se ele fechar sem passar pela saída normal.
//
// O Tick grava uma marca em dados/ ao abrir e a apaga ao sair. Se o processo acabou e a marca ficou, ele
// caiu. Quem sai por "Sair do Tick" ou desliga o PC não é reaberto. Rodar com ELECTRON_RUN_AS_NODE=1.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const CHECAGEM_MS = 2_000;
const ESPERA_MS = 15_000; // o Windows encerra o vigia antes disso quando o PC está desligando
const LIMITE = 3;
const JANELA_MS = 10 * 60_000;

/** Reabre até `LIMITE` vezes na janela: um Tick que cai ao abrir não pode ficar voltando para sempre. */
function podeReabrir(historico, agora, limite = LIMITE, janela = JANELA_MS) {
  const recentes = (Array.isArray(historico) ? historico : []).filter((t) => Number.isFinite(t) && agora - t < janela);
  return { pode: recentes.length < limite, recentes };
}

const estaVivo = (pid) => {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return e.code === 'EPERM';
  }
};

const marcaEDele = (cfg) => {
  try {
    return fs.readFileSync(cfg.marca, 'utf8').trim() === String(cfg.pid);
  } catch {
    return false;
  }
};

function anotar(cfg, txt) {
  try {
    fs.mkdirSync(path.dirname(cfg.registro), { recursive: true });
    fs.appendFileSync(cfg.registro, `${new Date().toISOString()} ${txt}\n`);
  } catch { /* sem registro, o vigia segue */ }
}

function reabrir(cfg) {
  let historico = [];
  try { historico = JSON.parse(fs.readFileSync(cfg.historico, 'utf8')); } catch { /* primeira vez */ }
  const agora = Date.now();
  const { pode, recentes } = podeReabrir(historico, agora, cfg.limite, cfg.janelaMs);
  if (!pode) {
    anotar(cfg, `[erro] vigia: o Tick caiu ${recentes.length} vezes em pouco tempo. Não vou reabrir de novo.`);
    return;
  }
  fs.writeFileSync(cfg.historico, JSON.stringify([...recentes, agora]));
  const env = { ...process.env };
  delete env.ELECTRON_RUN_AS_NODE;
  anotar(cfg, `[erro] vigia: o Tick fechou sem passar pela saída normal. Reabrindo (${recentes.length + 1} de ${cfg.limite ?? LIMITE}).`);
  const filho = spawn(cfg.exe, cfg.args ?? [], { detached: true, stdio: 'ignore', env, cwd: path.dirname(cfg.exe) });
  filho.on('error', (e) => anotar(cfg, `[erro] vigia: não consegui reabrir: ${e.message}`));
  filho.unref();
}

function rodar(cfg) {
  const relogio = setInterval(() => {
    if (estaVivo(cfg.pid)) return;
    clearInterval(relogio);
    if (!marcaEDele(cfg)) return; // saída normal, ou outro Tick já abriu
    setTimeout(() => {
      if (marcaEDele(cfg)) reabrir(cfg);
    }, cfg.esperaMs ?? ESPERA_MS);
  }, cfg.checagemMs ?? CHECAGEM_MS);
}

if (require.main === module) rodar(JSON.parse(process.argv[2]));

module.exports = { podeReabrir };
