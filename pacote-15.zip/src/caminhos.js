// A janela "Caminhos": pede os números à conta, simula os caminhos (caminhos-calc.js) e mostra XP, shiny e gemas.
/* global caminhosCalc */
const $ = (id) => document.getElementById(id);
const semPrefixo = (e) => String(e?.message ?? e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');
const CHAVE_HORAS = 'tick.caminhos.horas';
const METRICAS = { xp: 'XP', shinies: 'shiny', gemas: 'gemas' };

const dadosDe = new Map(); // conta → os números lidos dela
let metrica = 'xp';
let dias = 7;

function curto(v) {
  if (!Number.isFinite(v)) return '—';
  const a = Math.abs(v);
  const f = (x, s) => `${x.toLocaleString('pt-BR', { maximumFractionDigits: x < 10 ? 2 : 1 })} ${s}`;
  if (a >= 1e12) return f(v / 1e12, 'tri');
  if (a >= 1e9) return f(v / 1e9, 'bi');
  if (a >= 1e6) return f(v / 1e6, 'mi');
  if (a >= 1e4) return f(v / 1e3, 'mil');
  return v.toLocaleString('pt-BR', { maximumFractionDigits: a < 10 ? 2 : 0 });
}
const multTxt = (m) => `×${Number(m).toLocaleString('pt-BR', { maximumFractionDigits: 2 })}`;
const shinyTxt = (v) => (v > 0 ? `≈${v.toLocaleString('pt-BR', { maximumFractionDigits: v < 1 ? 2 : 1 })}` : '0');

function horasPorDia() {
  const v = Math.round(Number($('horas').value));
  return Number.isFinite(v) ? Math.min(24, Math.max(1, v)) : 24;
}

const el = (tag, cls, texto) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (texto != null) e.textContent = texto;
  return e;
};

function numero(rotulo, valor, sub, destaque) {
  const d = el('div', `num${destaque ? ' destaque' : ''}`);
  const b = el('b', null, valor);
  if (sub) b.append(el('small', null, sub));
  d.append(el('span', null, rotulo), b);
  return d;
}

/** O melhor caminho disponível numa métrica (o de maior valor). */
const melhorEm = (lista, m) => lista.filter((c) => !c.indisponivel).reduce((a, c) => (!a || c[m] > a[m] ? c : a), null);

const simular = (d) => caminhosCalc.simularCaminhos(d, { dias, horasPorDia: horasPorDia() });
const proximo = (d) => caminhosCalc.proximoDegrauDaConta(d.conta, d.degraus, d.xp[0]?.xpH ?? 0);

function pintarAvisos(d) {
  const avisos = [];
  const liberado = caminhosCalc.degrauDoNivel(d.degraus, d.conta.nivel);
  const atual = d.degraus.find((x) => x.tier === d.degrauAtual);
  if (liberado && atual && liberado.tier > atual.tier) {
    avisos.push(['bom', `Dá para subir de Outland agora: você está no ${atual.rotulo} (${multTxt(atual.mult)}) e o nível ${d.conta.nivel} já libera o ${liberado.rotulo} (${multTxt(liberado.mult)}).`]);
  }
  const p = proximo(d);
  if (p) {
    const h = horasPorDia();
    const tempo = p.horas == null ? 'sem XP/h lido' : p.horas < 1 ? `${Math.max(1, Math.round(p.horas * 60))} min de jogo` : `${curto(p.horas)} h de jogo${p.horas > h ? `, ≈${(p.horas / h).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} dias com ${h} h por dia` : ''}`;
    avisos.push(['', `Próximo degrau: ${p.degrau.rotulo} (${multTxt(p.degrau.mult)}) no nível ${p.degrau.nivel.toLocaleString('pt-BR')}. Faltam ${curto(p.xp)} de XP: ${tempo} na ${d.xp[0]?.nome ?? 'melhor hunt de XP'}.`]);
  } else if (liberado) {
    avisos.push(['bom', `Você já liberou o último degrau (${liberado.rotulo}).`]);
  }
  if (d.lureAte > Date.now()) avisos.push(['', `Shiny Secret Lure ativo até ${new Date(d.lureAte).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}: a chance de shiny dobra só até lá, e a conta não conta com ele depois.`]);
  if (d.caminho?.seguir && !d.melhorHunt) avisos.push(['', 'Você está seguindo um caminho, mas a Melhor hunt desta conta está desligada: ligue-a no painel da Auto Compra (aba Hunt) para a conta trocar de hunt.']);
  $('avisos').replaceChildren(...avisos.map(([cls, t]) => el('div', `aviso ${cls}`, t)));
  $('avisos').hidden = !avisos.length;
}

function cartao(c, d, melhor, n) {
  const card = el('article', `cartao${c.indisponivel ? ' fora' : ''}${melhor === c ? ' melhor' : ''}`);
  card.append(el('h3', null, c.nome));
  if (melhor === c) card.append(el('span', 'selo', `melhor em ${METRICAS[metrica]}`));
  if (c.indisponivel) {
    card.append(el('p', 'motivo', `Não dá para calcular: ${c.indisponivel}.`));
  } else {
    const nums = el('div', 'numeros');
    nums.append(
      numero('XP', curto(c.xp), `termina no nível ${c.nivelFinal.toLocaleString('pt-BR')}${c.degrauFinal ? `, no ${c.degrauFinal}` : ''}`, metrica === 'xp'),
      numero('Shiny', shinyTxt(c.shinies), c.shinies > 0 ? `entre ${c.faixaShinies[0]} e ${c.faixaShinies[1]}` : 'na Outland não há shiny', metrica === 'shinies'),
      numero('Gemas', curto(c.gemas), c.gemas > 0 ? `entre ${curto(c.faixaGemas[0])} e ${curto(c.faixaGemas[1])}` : 'sem drop com preço', metrica === 'gemas'),
    );
    card.append(nums);
    const etapas = el('ul', 'etapas');
    for (const e of c.etapas.slice(0, 4)) etapas.append(el('li', null, `${e.desdeHora ? `a partir de ${curto(e.desdeHora)} h (nível ${e.nivel.toLocaleString('pt-BR')})` : 'agora'}: ${e.rotulo}`));
    card.append(etapas);
  }
  // Seguir o caminho: uma chave por cartão, só uma ligada. Começa desligada.
  const seguindo = !!d.caminho?.seguir && d.caminho.id === c.id;
  const rotulo = el('label', 'seguir');
  const chave = document.createElement('input');
  chave.type = 'checkbox';
  chave.checked = seguindo;
  chave.disabled = !!c.indisponivel && !seguindo;
  chave.setAttribute('aria-label', `Seguir o caminho: ${c.nome}`);
  chave.addEventListener('change', async () => {
    chave.disabled = true;
    try {
      const ate = c.id === 'upar-voltar' ? proximo(d)?.degrau.nivel ?? null : null;
      const sit = chave.checked ? await window.tick.caminhosSeguir(n, c.id, ate) : await window.tick.caminhosParar(n);
      d.caminho = sit;
      d.melhorHunt = sit.melhorHunt;
      $('status').className = 'fraco';
      $('status').textContent = chave.checked
        ? `Seguindo "${c.nome}".${sit.melhorHunt ? ' A Melhor hunt vai levar a conta para lá.' : ' Ligue a Melhor hunt desta conta para ela trocar de hunt.'}`
        : 'Parou de seguir o caminho. A Melhor hunt continua do jeito que estava.';
    } catch (e) {
      $('status').className = 'erro';
      $('status').textContent = `Não deu: ${semPrefixo(e)}.`;
    }
    pintar();
  });
  rotulo.append(chave, document.createTextNode(seguindo ? 'Seguindo este caminho' : 'Seguir este caminho'));
  card.append(rotulo);
  return card;
}

function pintar() {
  const n = Number($('conta').value);
  const d = dadosDe.get(n);
  $('comparacao-periodo').textContent = `${dias} dias, ${horasPorDia()} h por dia`;
  if (dadosDe.size > 1) pintarComparacao();
  if (!d) { $('cartoes').hidden = true; $('avisos').hidden = true; return; }
  const lista = simular(d);
  const melhor = melhorEm(lista, metrica);
  pintarAvisos(d);
  $('cartoes').replaceChildren(...lista.map((c) => cartao(c, d, melhor, n)));
  $('cartoes').hidden = false;
  $('opcoes').hidden = false;
  const semPreco = [...new Set(lista.flatMap((c) => c.semPreco))];
  if (semPreco.length) {
    $('avisos').hidden = false;
    $('avisos').append(el('div', 'aviso', `Sem venda recente no Market, fora da conta das gemas: ${semPreco.slice(0, 8).join(', ')}${semPreco.length > 8 ? ` e mais ${semPreco.length - 8}` : ''}.`));
  }
}

function pintarComparacao() {
  const nomes = new Map([...$('conta').options].map((o) => [Number(o.value), o.textContent]));
  $('comparacao-corpo').replaceChildren(...[...dadosDe].map(([n, d]) => {
    const lista = simular(d);
    const celula = (m, txt) => {
      const td = el('td');
      const b = melhorEm(lista, m);
      td.append(el('span', null, b ? txt(b) : '—'));
      if (b) td.append(el('small', null, b.nome));
      return td;
    };
    const p = proximo(d);
    const tr = el('tr');
    tr.append(
      el('td', null, nomes.get(n) ?? `Conta ${n}`),
      celula('xp', (b) => `${curto(b.xp)} XP`),
      celula('shinies', (b) => `${shinyTxt(b.shinies)} shiny`),
      celula('gemas', (b) => `${curto(b.gemas)} gemas`),
      el('td', null, p ? `${p.degrau.rotulo} em ${p.horas == null ? '?' : `${curto(p.horas)} h`}` : 'último degrau'),
    );
    return tr;
  }));
  $('comparacao').hidden = false;
}

async function analisar(n) {
  $('status').className = 'fraco';
  $('status').textContent = 'Lendo o ranking da /hunt e o preço dos drops no Market… (até uns 30 segundos)';
  const d = await window.tick.caminhosDados(n);
  dadosDe.set(n, d);
  const hora = new Date(d.em).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  $('status').textContent = `Números lidos às ${hora}: ${d.xp.length} hunts de XP e ${d.outland.length} da Outland, ${Object.keys(d.precos).length} drops consultados no Market.`;
  return d;
}

function travar(sim) {
  for (const id of ['analisar', 'comparar', 'conta', 'horas']) $(id).disabled = sim;
}

$('analisar').addEventListener('click', async () => {
  travar(true);
  try {
    await analisar(Number($('conta').value));
    pintar();
  } catch (e) {
    $('status').className = 'erro';
    $('status').textContent = `Não deu: ${semPrefixo(e)}.`;
  } finally { travar(false); }
});

$('comparar').addEventListener('click', async () => {
  travar(true);
  const contas = [...$('conta').options].map((o) => Number(o.value));
  const falhas = [];
  for (const n of contas) {
    try { await analisar(n); } catch (e) { falhas.push(`${$('conta').querySelector(`option[value="${n}"]`)?.textContent}: ${semPrefixo(e)}`); }
  }
  travar(false);
  pintar();
  pintarComparacao();
  if (falhas.length) { $('status').className = 'erro'; $('status').textContent = `Não deu em: ${falhas.join(' · ')}.`; }
  else $('status').textContent = `${contas.length} contas analisadas.`;
});

for (const b of document.querySelectorAll('[data-metrica]')) {
  b.addEventListener('click', () => {
    metrica = b.dataset.metrica;
    for (const x of document.querySelectorAll('[data-metrica]')) x.classList.toggle('on', x === b);
    pintar();
  });
}
for (const b of document.querySelectorAll('[data-dias]')) {
  b.addEventListener('click', () => {
    dias = Number(b.dataset.dias);
    for (const x of document.querySelectorAll('[data-dias]')) x.classList.toggle('on', x === b);
    pintar();
  });
}
$('horas').addEventListener('change', () => {
  $('horas').value = String(horasPorDia());
  try { localStorage.setItem(CHAVE_HORAS, $('horas').value); } catch { /* vale até fechar */ }
  pintar();
});
$('conta').addEventListener('change', pintar);

(async () => {
  try { const h = localStorage.getItem(CHAVE_HORAS); if (h) $('horas').value = h; } catch { /* começa em 24 */ }
  const lista = await window.tick.caminhosContas();
  const pedida = new URLSearchParams(location.search).get('n');
  $('conta').replaceChildren(...lista.map((c) => {
    const o = document.createElement('option');
    o.value = String(c.n);
    o.textContent = c.nome;
    o.selected = String(c.n) === pedida;
    return o;
  }));
  if (!lista.length) {
    travar(true);
    $('horas').disabled = false;
    $('status').textContent = 'Nenhuma conta conectada agora.';
  }
  $('comparar').hidden = lista.length < 2;
})();
