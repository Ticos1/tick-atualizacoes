// @ts-check
// Os caminhos da Outland: ficar no degrau, subir sempre, upar até o próximo degrau e voltar, ou só upar.
// Simula hora a hora os próximos dias com os números da conta (XP/h, abates/h, drops, preços do Market e chance
// de shiny) e devolve XP, shinies e gemas de cada caminho. Puro: roda na janela "Caminhos" e nos testes.
(function (raiz) {
  'use strict';

  /**
   * @typedef {{ tier: number, nivel: number, mult: number, rotulo?: string }} Degrau
   * @typedef {{ name: string, chance: number, minCount?: number, maxCount?: number }} Drop
   * @typedef {{ preco: number, min?: number, max?: number } | null} Preco
   * @typedef {{ slug: string, nome: string, xpH: number, abatesH: number, area?: string,
   *   drops?: Record<string, number>, shinyH?: number }} HuntDoCaminho
   * @typedef {{ nivel: number, xp: number, xpNivel: number, xpProximo: number }} XpDaConta
   */

  /** A chance do catálogo é em 1/100.000. A quantidade sai entre o mínimo e o máximo. */
  const CHANCE_TOTAL = 100_000;

  /**
   * O XP de um nível cresce com o quadrado dele (≈ 49,79 × nível², nas contas medidas). A constante sai da
   * própria conta: a faixa do nível atual dividida pelo nível ao quadrado.
   * @param {XpDaConta} c
   */
  const constanteXp = (c) => Math.max(1, c.xpProximo - c.xpNivel) / Math.max(1, c.nivel) ** 2;

  /** O XP de um nível inteiro (do começo dele ao próximo). */
  const xpDoNivel = (k, constante) => constante * k * k;

  /**
   * Quanto XP falta para chegar ao nível `alvo`.
   * @param {XpDaConta} c
   * @param {number} alvo
   */
  function xpAteNivel(c, alvo) {
    if (!(alvo > c.nivel)) return 0;
    const constante = constanteXp(c);
    let falta = Math.max(0, c.xpProximo - c.xp);
    for (let k = c.nivel + 1; k < alvo; k++) falta += xpDoNivel(k, constante);
    return falta;
  }

  /**
   * O nível e o XP dentro dele depois de ganhar `ganho` XP.
   * @param {{ nivel: number, dentro: number }} pos
   * @param {number} ganho
   * @param {number} constante
   */
  function subirNivel(pos, ganho, constante) {
    let { nivel, dentro } = pos;
    dentro += ganho;
    // Teto de segurança: XP absurdo (dado errado) não pode travar a janela.
    for (let i = 0; i < 1_000_000 && dentro >= xpDoNivel(nivel, constante); i++) {
      dentro -= xpDoNivel(nivel, constante);
      nivel++;
    }
    return { nivel, dentro };
  }

  /**
   * O maior degrau que o nível libera, ou null se nenhum.
   * @param {Degrau[]} degraus
   * @param {number} nivel
   */
  function degrauDoNivel(degraus, nivel) {
    let melhor = null;
    for (const d of degraus) if (nivel >= d.nivel && (!melhor || d.tier > melhor.tier)) melhor = d;
    return melhor;
  }

  /** O próximo degrau acima de `tier`, ou null. */
  const proximoDegrau = (degraus, tier) => [...degraus].sort((a, b) => a.tier - b.tier).find((d) => d.tier > tier) ?? null;

  /**
   * Quantos de cada item caem, em média, por abate na hunt. `especies`: o sorteio de espécies dela (pontos);
   * `mult`: o multiplicador de drop do degrau (só na Outland), aplicado na chance, sem passar de 100%.
   * @param {{ pokeId: number, pontos: number }[]} especies
   * @param {(pokeId: number) => Drop[]} lootDe
   * @param {number} mult
   * @returns {Record<string, number>}
   */
  function dropsPorAbate(especies, lootDe, mult = 1) {
    /** @type {Record<string, number>} */
    const media = {};
    const total = especies.reduce((t, e) => t + (Number(e.pontos) || 0), 0) || 1;
    for (const e of especies) {
      const peso = (Number(e.pontos) || 0) / total;
      for (const l of lootDe(e.pokeId) ?? []) {
        const p = Math.min(1, (Number(l.chance) || 0) / CHANCE_TOTAL * mult);
        if (!(p > 0)) continue;
        const qtd = ((Number(l.minCount) || 1) + (Number(l.maxCount) || Number(l.minCount) || 1)) / 2;
        media[l.name] = (media[l.name] ?? 0) + peso * p * qtd;
      }
    }
    return media;
  }

  /**
   * Gemas por abate: os drops vezes o preço do Market. Também a faixa (preços do 1º ao 3º quartil) e quanto
   * dos drops ficou sem preço (que não entram na conta).
   * @param {Record<string, number>} drops
   * @param {Record<string, Preco>} precos
   */
  function gemasPorAbate(drops, precos) {
    let valor = 0;
    let min = 0;
    let max = 0;
    const semPreco = [];
    for (const [nome, qtd] of Object.entries(drops)) {
      const p = precos[nome];
      if (!p || !(p.preco > 0)) { semPreco.push(nome); continue; }
      valor += qtd * p.preco;
      min += qtd * (p.min ?? p.preco);
      max += qtd * (p.max ?? p.preco);
    }
    return { valor, min, max, semPreco };
  }

  /** Faixa de uma contagem rara (shiny): de 10% a 90% de uma Poisson com média `m`, aproximada. */
  function faixaPoisson(m) {
    if (!(m > 0)) return [0, 0];
    const dp = Math.sqrt(m);
    return [Math.max(0, Math.floor(m - 1.28 * dp)), Math.ceil(m + 1.28 * dp)];
  }

  const CAMINHOS = {
    ficar: 'Ficar no degrau da Outland',
    subir: 'Outland, sempre no maior degrau',
    'upar-voltar': 'Upar até o próximo degrau e voltar',
    upar: 'Só upar',
  };

  /**
   * Simula os caminhos por `dias` dias jogando `horasPorDia` horas por dia.
   * `dados.outland`: as hunts da Outland, com XP/h, abates/h e as espécies; `dados.xp`: as fora da Outland.
   * @param {{
   *   conta: XpDaConta, degraus: Degrau[], degrauAtual: number,
   *   outland: (HuntDoCaminho & { especies: { pokeId: number, pontos: number }[] })[],
   *   xp: (HuntDoCaminho & { especies?: { pokeId: number, pontos: number }[] })[],
   *   loot: Record<number, Drop[]>, precos: Record<string, Preco>,
   * }} dados
   * @param {{ dias: number, horasPorDia: number }} opcoes
   */
  function simularCaminhos(dados, { dias, horasPorDia }) {
    const horas = Math.max(0, dias * Math.min(24, Math.max(0, horasPorDia)));
    const constante = constanteXp(dados.conta);
    const lootDe = (id) => dados.loot[id] ?? [];
    const degraus = [...(dados.degraus ?? [])].sort((a, b) => a.tier - b.tier);
    const degrauPorTier = (tier) => degraus.find((d) => d.tier === tier) ?? null;

    /** A melhor hunt da Outland no degrau (mais gemas/h), com o que ela rende por hora. */
    const melhorOutland = (mult) => {
      let melhor = null;
      for (const h of dados.outland ?? []) {
        const g = gemasPorAbate(dropsPorAbate(h.especies ?? [], lootDe, mult), dados.precos);
        const r = { hunt: h, xpH: h.xpH, gemasH: g.valor * h.abatesH, minH: g.min * h.abatesH, maxH: g.max * h.abatesH, semPreco: g.semPreco, shinyH: 0 };
        if (!melhor || r.gemasH > melhor.gemasH || (r.gemasH === melhor.gemasH && r.xpH > melhor.xpH)) melhor = r;
      }
      return melhor;
    };
    /** A melhor hunt de XP (fora da Outland), com o shiny e os drops dela. */
    const huntXp = [...(dados.xp ?? [])].sort((a, b) => b.xpH - a.xpH)[0] ?? null;
    const rendaXp = huntXp && (() => {
      const g = gemasPorAbate(huntXp.especies ? dropsPorAbate(huntXp.especies, lootDe, 1) : (huntXp.drops ?? {}), dados.precos);
      return { hunt: huntXp, xpH: huntXp.xpH, gemasH: g.valor * huntXp.abatesH, minH: g.min * huntXp.abatesH, maxH: g.max * huntXp.abatesH, semPreco: g.semPreco, shinyH: huntXp.shinyH ?? 0 };
    })();

    const liberadoNoInicio = degrauDoNivel(degraus, dados.conta.nivel);
    const atual = degrauPorTier(dados.degrauAtual) ?? liberadoNoInicio;
    const alvoUpar = proximoDegrau(degraus, liberadoNoInicio?.tier ?? 0);

    /** Onde a conta está numa hora do caminho, pelo nível dela naquela hora. */
    const regra = {
      ficar: () => (atual ? { tipo: 'outland', degrau: atual } : null),
      subir: (nivel) => {
        const d = degrauDoNivel(degraus, nivel);
        return d ? { tipo: 'outland', degrau: d } : null;
      },
      'upar-voltar': (nivel) => {
        if (alvoUpar && nivel < alvoUpar.nivel) return { tipo: 'xp' };
        const d = degrauDoNivel(degraus, nivel);
        return d ? { tipo: 'outland', degrau: d } : null;
      },
      upar: () => ({ tipo: 'xp' }),
    };

    const cacheOutland = new Map();
    const rendaDe = (lugar) => {
      if (!lugar) return null;
      if (lugar.tipo === 'xp') return rendaXp;
      if (!cacheOutland.has(lugar.degrau.tier)) cacheOutland.set(lugar.degrau.tier, melhorOutland(lugar.degrau.mult));
      return cacheOutland.get(lugar.degrau.tier);
    };

    return Object.entries(CAMINHOS).map(([id, nome]) => {
      let pos = { nivel: dados.conta.nivel, dentro: Math.max(0, dados.conta.xp - dados.conta.xpNivel) };
      const total = { xp: 0, gemas: 0, gemasMin: 0, gemasMax: 0, shinies: 0 };
      const etapas = [];
      const semPreco = new Set();
      let indisponivel = null;
      if ((id !== 'upar') && !atual) indisponivel = 'a conta ainda não liberou a Outland';
      if (id === 'upar' && !rendaXp) indisponivel = 'não li nenhuma hunt de XP';
      if (id === 'upar-voltar' && !alvoUpar) indisponivel = 'já está no último degrau';
      if (id !== 'upar' && !indisponivel && !(dados.outland ?? []).length) indisponivel = 'não li nenhuma hunt da Outland';
      if (!indisponivel) {
        for (let h = 0; h < horas; h++) {
          const dt = Math.min(1, horas - h);
          const lugar = regra[id](pos.nivel);
          const r = rendaDe(lugar);
          if (!r) { indisponivel = 'sem dados para uma parte do caminho'; break; }
          const rotulo = lugar.tipo === 'xp' ? `${r.hunt.nome} (XP)` : `${r.hunt.nome} · ${lugar.degrau.rotulo ?? `degrau ${lugar.degrau.tier}`}`;
          const ultima = etapas[etapas.length - 1];
          if (!ultima || ultima.rotulo !== rotulo) etapas.push({ rotulo, desdeHora: h, nivel: pos.nivel });
          total.xp += r.xpH * dt;
          total.gemas += r.gemasH * dt;
          total.gemasMin += r.minH * dt;
          total.gemasMax += r.maxH * dt;
          total.shinies += r.shinyH * dt;
          for (const n of r.semPreco) semPreco.add(n);
          pos = subirNivel(pos, r.xpH * dt, constante);
        }
      }
      return {
        id, nome, indisponivel,
        xp: total.xp,
        nivelFinal: pos.nivel,
        degrauFinal: indisponivel ? null : (regra[id](pos.nivel)?.degrau?.rotulo ?? null),
        gemas: total.gemas,
        faixaGemas: [total.gemasMin, total.gemasMax],
        shinies: total.shinies,
        faixaShinies: faixaPoisson(total.shinies),
        etapas,
        semPreco: [...semPreco],
      };
    });
  }

  /**
   * Quanto falta para o próximo degrau: o XP e as horas de jogo na melhor hunt de XP.
   * @param {XpDaConta} conta
   * @param {Degrau[]} degraus
   * @param {number} xpH
   */
  function proximoDegrauDaConta(conta, degraus, xpH) {
    const liberado = degrauDoNivel(degraus, conta.nivel);
    const prox = proximoDegrau(degraus, liberado?.tier ?? 0);
    if (!prox) return null;
    const xp = xpAteNivel(conta, prox.nivel);
    return { degrau: prox, xp, horas: xpH > 0 ? xp / xpH : null };
  }

  const api = { CAMINHOS, constanteXp, xpAteNivel, subirNivel, degrauDoNivel, proximoDegrau, dropsPorAbate, gemasPorAbate, faixaPoisson, simularCaminhos, proximoDegrauDaConta };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else raiz.caminhosCalc = api;
})(globalThis);
