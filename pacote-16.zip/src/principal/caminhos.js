// @ts-check
// A janela "Caminhos": Outland × Shiny × Upar. Os números vêm da ponte do script, na página da conta
// (window.__tickCaminhos); a simulação é feita na própria janela (caminhos-calc.js). Aqui só se abre a janela e se
// repassam os pedidos, com os valores conferidos.
const { BrowserWindow, ipcMain } = require('electron');
const path = require('node:path');
const { ctx, usar } = require('./contexto');
const { ICONE, PASTA_SRC } = require('./constantes');

const { registrarErro, anotar, nomeDe, ordenadas } = usar('registrarErro', 'anotar', 'nomeDe', 'ordenadas');

const CAMINHOS = new Set(['ficar', 'subir', 'upar-voltar', 'upar']);

/** @type {import('electron').BrowserWindow | null} */
let janela = null;

function abrirCaminhos() {
  if (janela && !janela.isDestroyed()) { janela.show(); return janela.focus(); }
  const preferida = ctx.focada?.status.ws === 'conectada' ? ctx.focada : ordenadas().find((c) => c.status.ws === 'conectada');
  janela = new BrowserWindow({
    width: 980, height: 760, minWidth: 620, minHeight: 460, title: 'Caminhos: Outland × Shiny × Upar', autoHideMenuBar: true, icon: ICONE, backgroundColor: '#171a2b',
    webPreferences: { preload: path.join(PASTA_SRC, 'preload-ui.js') },
  });
  janela.on('closed', () => { janela = null; });
  janela.loadFile(path.join(PASTA_SRC, 'caminhos.html'), { query: { n: String(preferida?.n ?? '') } }).catch((e) => registrarErro('janela Caminhos', e));
  anotar('caminhos: janela aberta');
}

/** Uma chamada à ponte dos caminhos na página da conta. Só os nomes e valores conferidos aqui chegam lá. */
function naPonteDosCaminhos(n, chamada) {
  const conta = ctx.contas.find((c) => c.n === Number(n));
  if (!conta || conta.status.ws !== 'conectada') return Promise.reject(new Error('essa conta não está conectada'));
  return conta.view.webContents.executeJavaScript(
    `window.__tickCaminhos ? Promise.resolve().then(() => window.__tickCaminhos.${chamada}) : Promise.reject(new Error('o script de Auto Compra ainda não carregou nesta conta'))`,
    true,
  );
}

ipcMain.handle('tick:caminhos-contas', () => ordenadas()
  .filter((c) => c.status.ws === 'conectada')
  .map((c) => ({ n: c.n, nome: nomeDe(c) })));
ipcMain.handle('tick:caminhos-dados', (_ev, n) => naPonteDosCaminhos(n, 'dados()'));
ipcMain.handle('tick:caminhos-situacao', (_ev, n) => naPonteDosCaminhos(n, 'situacao()'));
ipcMain.handle('tick:caminhos-parar', (_ev, n) => {
  anotar(`caminhos: conta ${n} parou de seguir`);
  return naPonteDosCaminhos(n, 'parar()');
});
ipcMain.handle('tick:caminhos-seguir', (_ev, n, id, ate) => {
  if (!CAMINHOS.has(id)) throw new Error('caminho desconhecido');
  const nivel = Number.isInteger(ate) && ate > 0 ? ate : null;
  anotar(`caminhos: conta ${n} seguindo "${id}"`);
  return naPonteDosCaminhos(n, `seguir(${JSON.stringify(id)}, ${JSON.stringify(nivel)})`);
});

module.exports = { abrirCaminhos };
